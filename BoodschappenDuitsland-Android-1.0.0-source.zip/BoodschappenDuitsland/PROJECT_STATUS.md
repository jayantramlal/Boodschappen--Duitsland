# Projectstatus 1.0.0

Deze broncode is opgezet als eerste buildbare Android-baseline met GitHub Actions.

## Gereed
- Volledige Android projectstructuur
- Compose UI: Home, lijst, prijzen, aanbiedingen, winkels, instellingen, scanresultaat
- Licht/donker
- NL + DE gezamenlijke prijsvergelijking
- Normale en aanbiedingsprijzen
- Eenheidsprijzen
- Boodschappenlijst en winkelstrategie
- Barcode-scanner
- SQLite-opslag en prijshistorie
- Handmatige product/winkel/prijsinvoer
- Unit tests prijsengine
- GitHub Actions: tests, lint, APK build
- Vaste development signing key voor updatebare test-APK's
- Optionele release-signing workflow

## Bewust nog niet als 'live' gepresenteerd
Live supermarktprijzen. Daarvoor moet per winkel een toegestane en betrouwbare gegevensbron/API worden aangesloten. De `PriceSource`-laag is hiervoor voorbereid.

## Buildvalidatie
Deze chatomgeving bevat geen Android SDK/Gradle-installatie en heeft geen externe Maven-netwerktoegang. De Android-build zelf moet daarom door de meegeleverde GitHub Actions workflow worden uitgevoerd. De kern-prijsengine is lokaal syntactisch gecompileerd met Kotlin en heeft afzonderlijke unit tests in het project.
