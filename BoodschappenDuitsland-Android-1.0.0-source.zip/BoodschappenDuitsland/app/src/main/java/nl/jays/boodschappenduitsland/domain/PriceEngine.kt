package nl.jays.boodschappenduitsland.domain

import kotlin.math.roundToInt

object PriceEngine {
    fun effectivePrice(entry: PriceEntry, nowMillis: Long = System.currentTimeMillis()): Pair<Int, Boolean> {
        val activeOffer = entry.offerPriceCents != null &&
            entry.offerPriceCents > 0 &&
            entry.offerPriceCents < entry.regularPriceCents &&
            entry.offerUntilMillis != null &&
            entry.offerUntilMillis >= nowMillis
        return if (activeOffer) entry.offerPriceCents!! to true else entry.regularPriceCents to false
    }

    fun priceForProduct(
        product: Product,
        entry: PriceEntry,
        store: Store,
        nowMillis: Long = System.currentTimeMillis()
    ): ProductPrice {
        val (effective, isOffer) = effectivePrice(entry, nowMillis)
        val unit = unitPrice(product, effective)
        return ProductPrice(
            product = product,
            store = store,
            entry = entry,
            effectivePriceCents = effective,
            isOffer = isOffer,
            unitPriceCents = unit.first,
            unitLabel = unit.second
        )
    }

    fun bestPrice(
        product: Product,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): ProductPrice? {
        val storesById = stores.associateBy { it.id }
        return prices.asSequence()
            .filter { it.productId == product.id }
            .mapNotNull { entry ->
                val store = storesById[entry.storeId] ?: return@mapNotNull null
                if (!store.enabled) return@mapNotNull null
                if (filter == CountryFilter.NL && store.country != Country.NL) return@mapNotNull null
                if (filter == CountryFilter.DE && store.country != Country.DE) return@mapNotNull null
                priceForProduct(product, entry, store, nowMillis)
            }
            .minByOrNull { it.effectivePriceCents }
    }

    fun rankedPrices(
        product: Product,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): List<ProductPrice> {
        val storesById = stores.associateBy { it.id }
        return prices.asSequence()
            .filter { it.productId == product.id }
            .mapNotNull { entry ->
                val store = storesById[entry.storeId] ?: return@mapNotNull null
                if (!store.enabled) return@mapNotNull null
                if (filter == CountryFilter.NL && store.country != Country.NL) return@mapNotNull null
                if (filter == CountryFilter.DE && store.country != Country.DE) return@mapNotNull null
                priceForProduct(product, entry, store, nowMillis)
            }
            .sortedBy { it.effectivePriceCents }
            .toList()
    }

    fun listTotal(
        items: List<ShoppingListItem>,
        products: List<Product>,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): Int {
        val productsById = products.associateBy { it.id }
        return items.sumOf { item ->
            val product = productsById[item.productId] ?: return@sumOf 0
            val best = bestPrice(product, prices, stores, filter, nowMillis)
            (best?.effectivePriceCents ?: 0) * item.quantity
        }
    }

    fun mostExpensiveComparableTotal(
        items: List<ShoppingListItem>,
        products: List<Product>,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): Int {
        val productsById = products.associateBy { it.id }
        val storesById = stores.associateBy { it.id }
        return items.sumOf { item ->
            val product = productsById[item.productId] ?: return@sumOf 0
            val max = prices.asSequence()
                .filter { it.productId == product.id }
                .mapNotNull { entry ->
                    val store = storesById[entry.storeId] ?: return@mapNotNull null
                    if (!store.enabled) return@mapNotNull null
                    if (filter == CountryFilter.NL && store.country != Country.NL) return@mapNotNull null
                    if (filter == CountryFilter.DE && store.country != Country.DE) return@mapNotNull null
                    effectivePrice(entry, nowMillis).first
                }
                .maxOrNull() ?: 0
            max * item.quantity
        }
    }

    fun bestSingleStorePlan(
        items: List<ShoppingListItem>,
        products: List<Product>,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): StorePlan? {
        if (items.isEmpty()) return null
        val knownProductIds = products.map { it.id }.toSet()
        val productIds = items.map { it.productId }.filter { it in knownProductIds }.toSet()
        if (productIds.isEmpty()) return null
        val qty = items.associate { it.productId to it.quantity }
        val allowedStores = stores.filter { store ->
            store.enabled && when (filter) {
                CountryFilter.ALL -> true
                CountryFilter.NL -> store.country == Country.NL
                CountryFilter.DE -> store.country == Country.DE
            }
        }
        val plans = allowedStores.map { store ->
            val byProduct = prices.filter { it.storeId == store.id && it.productId in productIds }.associateBy { it.productId }
            val covered = productIds.count { byProduct.containsKey(it) }
            val total = productIds.sumOf { pid ->
                val entry = byProduct[pid] ?: return@sumOf 0
                effectivePrice(entry, nowMillis).first * (qty[pid] ?: 1)
            }
            StorePlan(store, total, covered, productIds.size)
        }
        return plans.sortedWith(compareByDescending<StorePlan> { it.coveredItems }.thenBy { it.totalCents }).firstOrNull()
    }

    private fun unitPrice(product: Product, cents: Int): Pair<Int?, String?> {
        if (product.sizeValue <= 0.0) return null to null
        return when (product.sizeUnit.lowercase()) {
            "ml" -> ((cents / product.sizeValue) * 1000.0).roundToInt() to "per liter"
            "l", "liter" -> (cents / product.sizeValue).roundToInt() to "per liter"
            "g" -> ((cents / product.sizeValue) * 1000.0).roundToInt() to "per kg"
            "kg" -> (cents / product.sizeValue).roundToInt() to "per kg"
            "st", "stuks" -> (cents / product.sizeValue).roundToInt() to "per stuk"
            else -> null to null
        }
    }
}

fun Int.asEuro(): String {
    val sign = if (this < 0) "-" else ""
    val abs = kotlin.math.abs(this)
    return "$sign€ ${abs / 100},${(abs % 100).toString().padStart(2, '0')}"
}
