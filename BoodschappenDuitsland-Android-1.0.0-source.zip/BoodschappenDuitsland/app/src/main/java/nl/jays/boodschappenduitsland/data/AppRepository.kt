package nl.jays.boodschappenduitsland.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import nl.jays.boodschappenduitsland.domain.*
import java.util.Calendar

class AppRepository(private val context: Context) {
    private val dbHelper = AppDatabase(context)

    @Synchronized
    fun loadSnapshot(): AppSnapshot {
        val db = dbHelper.readableDatabase
        return AppSnapshot(
            stores = queryStores(db.query("stores", null, null, null, null, null, "country, name")),
            products = queryProducts(db.query("products", null, null, null, null, null, "category, name")),
            prices = queryPrices(db.query("prices", null, null, null, null, null, null)),
            shoppingList = queryShoppingList(db.query("shopping_list", null, null, null, null, null, null)),
            history = queryHistory(db.query("price_history", null, null, null, null, null, "captured_at_millis"))
        )
    }

    @Synchronized
    fun findProductByEan(ean: String): Product? {
        val db = dbHelper.readableDatabase
        val c = db.query("products", null, "ean=?", arrayOf(ean), null, null, null, "1")
        return c.use { if (it.moveToFirst()) productFromCursor(it) else null }
    }

    @Synchronized
    fun ensureProductForBarcode(ean: String): Product {
        findProductByEan(ean)?.let { return it }
        val id = dbHelper.writableDatabase.insertOrThrow("products", null, ContentValues().apply {
            put("ean", ean)
            put("name", "Onbekend product")
            put("brand", "EAN $ean")
            put("size_value", 1.0)
            put("size_unit", "st")
            put("category", "Nog in te delen")
        })
        return Product(id, ean, "Onbekend product", "EAN $ean", 1.0, "st", "Nog in te delen")
    }

    @Synchronized
    fun addProduct(name: String, brand: String, ean: String?, sizeValue: Double, sizeUnit: String, category: String): Long {
        return dbHelper.writableDatabase.insertOrThrow("products", null, ContentValues().apply {
            if (ean.isNullOrBlank()) putNull("ean") else put("ean", ean.trim())
            put("name", name.trim())
            put("brand", brand.trim())
            put("size_value", sizeValue)
            put("size_unit", sizeUnit.trim())
            put("category", category.trim())
        })
    }

    @Synchronized
    fun updateProduct(product: Product) {
        dbHelper.writableDatabase.update("products", ContentValues().apply {
            if (product.ean.isNullOrBlank()) putNull("ean") else put("ean", product.ean)
            put("name", product.name)
            put("brand", product.brand)
            put("size_value", product.sizeValue)
            put("size_unit", product.sizeUnit)
            put("category", product.category)
        }, "id=?", arrayOf(product.id.toString()))
    }

    @Synchronized
    fun addStore(name: String, country: Country): Long {
        return dbHelper.writableDatabase.insertOrThrow("stores", null, ContentValues().apply {
            put("name", name.trim())
            put("country", country.name)
            put("enabled", 1)
        })
    }

    @Synchronized
    fun setStoreEnabled(storeId: Long, enabled: Boolean) {
        dbHelper.writableDatabase.update("stores", ContentValues().apply {
            put("enabled", if (enabled) 1 else 0)
        }, "id=?", arrayOf(storeId.toString()))
    }

    @Synchronized
    fun upsertPrice(productId: Long, storeId: Long, regularCents: Int, offerCents: Int?, offerDays: Int?) {
        val now = System.currentTimeMillis()
        val offerUntil = if (offerCents != null) {
            Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, (offerDays ?: 7).coerceAtLeast(1)) }.timeInMillis
        } else null
        val values = ContentValues().apply {
            put("product_id", productId)
            put("store_id", storeId)
            put("regular_price_cents", regularCents)
            if (offerCents == null) putNull("offer_price_cents") else put("offer_price_cents", offerCents)
            if (offerUntil == null) putNull("offer_until_millis") else put("offer_until_millis", offerUntil)
            put("updated_at_millis", now)
        }
        val updated = dbHelper.writableDatabase.update("prices", values, "product_id=? AND store_id=?", arrayOf(productId.toString(), storeId.toString()))
        if (updated == 0) dbHelper.writableDatabase.insertOrThrow("prices", null, values)
        val effective = offerCents ?: regularCents
        dbHelper.writableDatabase.insertOrThrow("price_history", null, ContentValues().apply {
            put("product_id", productId)
            put("store_id", storeId)
            put("price_cents", effective)
            put("captured_at_millis", now)
        })
    }

    @Synchronized
    fun addToList(productId: Long, quantity: Int = 1) {
        val db = dbHelper.writableDatabase
        val c = db.query("shopping_list", arrayOf("quantity"), "product_id=?", arrayOf(productId.toString()), null, null, null)
        val existing = c.use { if (it.moveToFirst()) it.getInt(0) else null }
        if (existing == null) {
            db.insertOrThrow("shopping_list", null, ContentValues().apply {
                put("product_id", productId)
                put("quantity", quantity.coerceAtLeast(1))
                put("checked", 0)
            })
        } else {
            setListQuantity(productId, existing + quantity)
        }
    }

    @Synchronized
    fun setListQuantity(productId: Long, quantity: Int) {
        val db = dbHelper.writableDatabase
        if (quantity <= 0) {
            db.delete("shopping_list", "product_id=?", arrayOf(productId.toString()))
        } else {
            db.update("shopping_list", ContentValues().apply { put("quantity", quantity) }, "product_id=?", arrayOf(productId.toString()))
        }
    }

    @Synchronized
    fun setListChecked(productId: Long, checked: Boolean) {
        dbHelper.writableDatabase.update("shopping_list", ContentValues().apply {
            put("checked", if (checked) 1 else 0)
        }, "product_id=?", arrayOf(productId.toString()))
    }

    @Synchronized
    fun clearChecked() {
        dbHelper.writableDatabase.delete("shopping_list", "checked=1", null)
    }

    @Synchronized
    fun resetDemoData() {
        dbHelper.close()
        context.deleteDatabase(AppDatabase.DB_NAME)
        AppDatabase(context).writableDatabase.close()
    }

    private fun queryStores(c: Cursor): List<Store> = c.use {
        buildList { while (it.moveToNext()) add(Store(it.long("id"), it.string("name"), Country.valueOf(it.string("country")), it.int("enabled") == 1)) }
    }

    private fun queryProducts(c: Cursor): List<Product> = c.use {
        buildList { while (it.moveToNext()) add(productFromCursor(it)) }
    }

    private fun queryPrices(c: Cursor): List<PriceEntry> = c.use {
        buildList {
            while (it.moveToNext()) add(PriceEntry(
                id = it.long("id"),
                productId = it.long("product_id"),
                storeId = it.long("store_id"),
                regularPriceCents = it.int("regular_price_cents"),
                offerPriceCents = it.nullableInt("offer_price_cents"),
                offerUntilMillis = it.nullableLong("offer_until_millis"),
                updatedAtMillis = it.long("updated_at_millis")
            ))
        }
    }

    private fun queryShoppingList(c: Cursor): List<ShoppingListItem> = c.use {
        buildList { while (it.moveToNext()) add(ShoppingListItem(it.long("product_id"), it.int("quantity"), it.int("checked") == 1)) }
    }

    private fun queryHistory(c: Cursor): List<PriceHistoryPoint> = c.use {
        buildList { while (it.moveToNext()) add(PriceHistoryPoint(it.long("product_id"), it.long("store_id"), it.int("price_cents"), it.long("captured_at_millis"))) }
    }

    private fun productFromCursor(c: Cursor) = Product(
        id = c.long("id"),
        ean = c.nullableString("ean"),
        name = c.string("name"),
        brand = c.string("brand"),
        sizeValue = c.double("size_value"),
        sizeUnit = c.string("size_unit"),
        category = c.string("category")
    )

    private fun Cursor.index(name: String) = getColumnIndexOrThrow(name)
    private fun Cursor.string(name: String) = getString(index(name))
    private fun Cursor.nullableString(name: String) = index(name).let { if (isNull(it)) null else getString(it) }
    private fun Cursor.int(name: String) = getInt(index(name))
    private fun Cursor.nullableInt(name: String) = index(name).let { if (isNull(it)) null else getInt(it) }
    private fun Cursor.long(name: String) = getLong(index(name))
    private fun Cursor.nullableLong(name: String) = index(name).let { if (isNull(it)) null else getLong(it) }
    private fun Cursor.double(name: String) = getDouble(index(name))
}
