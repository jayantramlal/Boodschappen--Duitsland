# Boodschappen Duitsland — Android 1.0.0

Native Android-app in Kotlin + Jetpack Compose voor prijsvergelijking tussen Nederlandse en Duitse supermarkten/drogisterijen.

## Wat zit er al in
- Nederland en Duitsland in één prijsvergelijking; standaard wint simpelweg de laagste prijs.
- Optionele NL/DE-filters.
- Normale prijs + aanbiedingsprijs + einddatum.
- Eenheidsprijs per liter/kg/stuk waar mogelijk.
- Boodschappenlijst met aantallen en afvinken.
- Strategie `Maximale besparing` of `Alles bij één winkel`.
- Barcode-scanner via Google Code Scanner (EAN/UPC/Code128).
- Onbekende barcode wordt lokaal aangemaakt en kan daarna worden ingevuld.
- Producten en winkels handmatig toevoegen.
- Winkels aan/uit zetten.
- Prijzen handmatig toevoegen/wijzigen.
- Prijshistorie bij wijzigingen.
- Aanbiedingsoverzicht.
- Licht/donker thema.
- Lokale SQLite-opslag; geen account vereist.
- Unit tests voor de kern-prijslogica.
- GitHub Actions bouwt automatisch een APK.

## Belangrijk over prijsdata
De meegeleverde prijzen zijn **demo-/testdata**. Live supermarktprijzen vragen per winkel een betrouwbare bron/API. De code heeft hiervoor al een `PriceSource`-contract zodat dit later modulair aangesloten kan worden.

## GitHub -> APK
1. Maak een lege GitHub repository.
2. Upload/push de inhoud van deze map naar de repository.
3. Open GitHub → **Actions** → **Android APK**.
4. Kies **Run workflow** of push naar `main`.
5. Na tests + lint + build staat onder **Artifacts**: `Boodschappen-Duitsland-1.0.0-dev-apk`.
6. Download het artifact en installeer de APK op Android.

De development APK gebruikt bewust de meegeleverde `app/debug.jks` zodat builds van GitHub Actions dezelfde testsignatuur houden en een volgende dev-APK over de vorige geïnstalleerd kan worden. Deze sleutel is **niet bedoeld voor Play Store/productie**.

## Productie-release ondertekenen
Gebruik één permanente release-keystore en bewaar die buiten Git. Het script `scripts/generate-release-keystore.sh` helpt bij het maken ervan. Voeg daarna GitHub Secrets toe:
- `RELEASE_KEYSTORE_BASE64`
- `RELEASE_STORE_PASSWORD`
- `RELEASE_KEY_ALIAS`
- `RELEASE_KEY_PASSWORD`

Start vervolgens de workflow **Signed Release APK**.

## Build stack
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- compileSdk 37 / targetSdk 36 / minSdk 23
- Jetpack Compose BOM 2026.08.00
- Activity Compose 1.13.0
- Lifecycle 2.11.0
- Google Code Scanner 16.1.0

## Package
Development: `nl.jays.boodschappenduitsland.dev`  
Release: `nl.jays.boodschappenduitsland`
