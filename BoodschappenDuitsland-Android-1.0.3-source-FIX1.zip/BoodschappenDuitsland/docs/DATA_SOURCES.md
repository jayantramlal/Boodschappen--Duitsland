# Live prijsbronnen

Versie 1.0.0 bevat lokale, bewerkbare demo-/testdata. Er worden nog geen prijzen voorgedaan als live supermarktdata.

Live bronnen worden per winkel geïmplementeerd achter `PriceSource`. Een provider moet minimaal leveren:
- EAN/productidentificatie
- winkelnaam/land
- normale prijs
- eventuele aanbieding
- geldigheidsdatum
- brontijdstip

Daarna worden de brongegevens opgeslagen in dezelfde neutrale tabellen. De UI en prijsengine hoeven daardoor niet per winkel aangepast te worden.

Voor productie moeten per winkel de juridische en technische voorwaarden van de gekozen bron/API worden gecontroleerd. Scraping hoort niet stilzwijgend als permanente databron te worden gebruikt als de websitevoorwaarden dit niet toestaan.

## Versie 1.0.3 - supermarktbestanden en aanbiedingen

De app ondersteunt per supermarkt een los JSON-importbestand met `schema_version: 1` en `database_type: supermarket_catalog`.
Een import werkt producten/prijzen bij zonder de volledige lokale database te vervangen. Producten worden primair gekoppeld op EAN of bron-ID; bestaande gebruikersgegevens worden zo veel mogelijk behouden.

De Aanbiedingen-pagina groepeert actieve aanbiedingen per winkel. De refresh-knop gebruikt in 1.0.3 één live bron: Albert Heijn Bonus. Deze koppeling gebruikt een niet-officieel/ongedocumenteerd mobiel endpoint en kan daarom door Albert Heijn wijzigen. Bij een fout blijft de laatst bekende lokale aanbiedingenset behouden.

Zie `examples/Albert_Heijn_proefdatabase_v1.json` voor het importformaat.
