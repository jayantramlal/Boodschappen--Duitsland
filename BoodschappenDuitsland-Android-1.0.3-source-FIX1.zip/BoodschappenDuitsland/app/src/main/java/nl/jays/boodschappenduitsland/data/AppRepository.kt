package nl.jays.boodschappenduitsland.data

import android.content.ContentValues
import android.content.Context
import android.database.Cursor
import android.database.sqlite.SQLiteDatabase
import android.net.Uri
import nl.jays.boodschappenduitsland.domain.*
import java.util.Calendar
import java.util.Locale
import kotlin.math.abs

class AppRepository(private val context: Context) {
    private val dbHelper = AppDatabase(context)
    private val backupManager = BackupManager(context, dbHelper)
    private val catalogParser = SupermarketCatalogParser(context)

    @Synchronized
    fun loadSnapshot(): AppSnapshot {
        val db = dbHelper.readableDatabase
        clearExpiredOffers(db, System.currentTimeMillis())
        return AppSnapshot(
            stores = queryStores(db.query("stores", null, null, null, null, null, "country, name")),
            products = queryProducts(db.query("products", null, null, null, null, null, "category, name")),
            prices = queryPrices(db.query("prices", null, null, null, null, null, null)),
            shoppingList = queryShoppingList(db.query("shopping_list", null, null, null, null, null, null)),
            history = queryHistory(db.query("price_history", null, null, null, null, null, "captured_at_millis"))
        )
    }

    @Synchronized
    fun findProductByEan(ean: String): Product? {
        val db = dbHelper.readableDatabase
        val c = db.query("products", null, "ean=?", arrayOf(ean), null, null, null, "1")
        return c.use { if (it.moveToFirst()) productFromCursor(it) else null }
    }

    @Synchronized
    fun ensureProductForBarcode(ean: String): Product {
        findProductByEan(ean)?.let { return it }
        val id = dbHelper.writableDatabase.insertOrThrow("products", null, ContentValues().apply {
            put("ean", ean)
            put("name", "Onbekend product")
            put("brand", "EAN $ean")
            put("size_value", 1.0)
            put("size_unit", "st")
            put("category", "Nog in te delen")
        })
        return Product(id, ean, "Onbekend product", "EAN $ean", 1.0, "st", "Nog in te delen")
    }

    @Synchronized
    fun addProduct(name: String, brand: String, ean: String?, sizeValue: Double, sizeUnit: String, category: String): Long {
        return dbHelper.writableDatabase.insertOrThrow("products", null, ContentValues().apply {
            if (ean.isNullOrBlank()) putNull("ean") else put("ean", ean.trim())
            put("name", name.trim())
            put("brand", brand.trim())
            put("size_value", sizeValue)
            put("size_unit", sizeUnit.trim())
            put("category", category.trim())
        })
    }

    @Synchronized
    fun updateProduct(product: Product) {
        dbHelper.writableDatabase.update("products", ContentValues().apply {
            if (product.ean.isNullOrBlank()) putNull("ean") else put("ean", product.ean)
            put("name", product.name)
            put("brand", product.brand)
            put("size_value", product.sizeValue)
            put("size_unit", product.sizeUnit)
            put("category", product.category)
        }, "id=?", arrayOf(product.id.toString()))
    }

    @Synchronized
    fun addStore(name: String, country: Country): Long {
        return dbHelper.writableDatabase.insertOrThrow("stores", null, ContentValues().apply {
            put("name", name.trim())
            put("country", country.name)
            put("enabled", 1)
        })
    }

    @Synchronized
    fun setStoreEnabled(storeId: Long, enabled: Boolean) {
        dbHelper.writableDatabase.update("stores", ContentValues().apply {
            put("enabled", if (enabled) 1 else 0)
        }, "id=?", arrayOf(storeId.toString()))
    }

    @Synchronized
    fun upsertPrice(productId: Long, storeId: Long, regularCents: Int, offerCents: Int?, offerDays: Int?) {
        require(PriceRules.isValidRegularPrice(regularCents)) { "Ongeldige normale prijs" }

        val validOffer = PriceRules.validOfferCents(regularCents, offerCents)
        require(offerCents == null || validOffer != null) {
            "Aanbiedingsprijs moet hoger dan € 0,00 en lager dan de normale prijs zijn"
        }

        val now = System.currentTimeMillis()
        val offerUntil = if (validOffer != null) {
            Calendar.getInstance().apply {
                add(Calendar.DAY_OF_YEAR, PriceRules.normalizeOfferDays(offerDays))
            }.timeInMillis
        } else null

        val values = ContentValues().apply {
            put("product_id", productId)
            put("store_id", storeId)
            put("regular_price_cents", regularCents)
            if (validOffer == null) putNull("offer_price_cents") else put("offer_price_cents", validOffer)
            if (offerUntil == null) putNull("offer_until_millis") else put("offer_until_millis", offerUntil)
            put("updated_at_millis", now)
            put("source", "MANUAL")
            putNull("offer_label")
            putNull("offer_type")
            putNull("offer_start_millis")
        }

        val db = dbHelper.writableDatabase
        db.beginTransaction()
        try {
            val oldEffective = currentEffectivePrice(db, productId, storeId, now)
            val updated = db.update("prices", values, "product_id=? AND store_id=?", arrayOf(productId.toString(), storeId.toString()))
            if (updated == 0) db.insertOrThrow("prices", null, values)
            val effective = validOffer ?: regularCents
            if (oldEffective != effective) insertHistory(db, productId, storeId, effective, now)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    @Synchronized
    fun importSupermarketCatalog(uri: Uri): CatalogImportResult = applyExternalCatalog(catalogParser.parse(uri))

    @Synchronized
    fun refreshOffers(): OfferRefreshResult {
        // 1.0.3 starts with one real live source. The architecture is intentionally
        // source-agnostic so Jumbo/Lidl/Kaufland/etc. can be added independently.
        val catalogs = listOf(AlbertHeijnOfferSource().fetch())
        var processed = 0
        var offers = 0
        val names = mutableListOf<String>()
        catalogs.forEach { catalog ->
            val result = applyExternalCatalog(catalog)
            processed += result.productsProcessed
            offers += result.activeOffers
            names += result.storeName
        }
        return OfferRefreshResult(catalogs.size, processed, offers, names.distinct())
    }

    @Synchronized
    fun lastOfferRefreshMillis(): Long? {
        val db = dbHelper.readableDatabase
        return db.rawQuery("SELECT MAX(last_success_millis) FROM source_syncs WHERE source_id=?", arrayOf(AlbertHeijnOfferSource.SOURCE_ID)).use {
            if (it.moveToFirst() && !it.isNull(0)) it.getLong(0) else null
        }
    }

    private fun applyExternalCatalog(catalog: ExternalCatalog): CatalogImportResult {
        require(catalog.products.size <= 150_000) { "Te veel producten in één gegevensbron" }
        val now = System.currentTimeMillis()
        val db = dbHelper.writableDatabase
        var created = 0
        var priceUpdates = 0
        var activeOffers = 0

        db.beginTransaction()
        try {
            val storeId = ensureStore(db, catalog.storeName, catalog.country)
            clearExpiredOffers(db, now)

            catalog.products.forEach { external ->
                require(PriceRules.isValidRegularPrice(external.regularPriceCents)) { "Ongeldige prijs voor ${external.name}" }
                val sourceProductId = stableSourceProductId(external)
                val mappedId = findMappedProductId(db, storeId, catalog.sourceId, sourceProductId)
                val eanId = external.ean?.takeIf { it.isNotBlank() }?.let { findProductIdByEan(db, it) }
                val fallbackId = if (mappedId == null && eanId == null) findProductByMetadata(db, external) else null
                val productId = mappedId ?: eanId ?: fallbackId ?: insertExternalProduct(db, external).also { created++ }

                // Only replace descriptive data for a product already controlled by this
                // source or a barcode placeholder. User-maintained metadata is preserved.
                if (mappedId != null || isPlaceholderProduct(db, productId)) {
                    updateExternalProduct(db, productId, external)
                }

                db.insertWithOnConflict("product_sources", null, ContentValues().apply {
                    put("store_id", storeId)
                    put("product_id", productId)
                    put("source_id", catalog.sourceId)
                    put("source_product_id", sourceProductId)
                    put("last_seen_millis", now)
                }, SQLiteDatabase.CONFLICT_REPLACE)

                val validOffer = PriceRules.validOfferCents(external.regularPriceCents, external.offerPriceCents)
                    ?.takeIf { external.offerUntilMillis == null || external.offerUntilMillis >= now }
                if (validOffer != null) activeOffers++

                val oldEffective = currentEffectivePrice(db, productId, storeId, now)
                val values = ContentValues().apply {
                    put("product_id", productId)
                    put("store_id", storeId)
                    put("regular_price_cents", external.regularPriceCents)
                    if (validOffer == null) putNull("offer_price_cents") else put("offer_price_cents", validOffer)
                    if (validOffer == null || external.offerUntilMillis == null) putNull("offer_until_millis") else put("offer_until_millis", external.offerUntilMillis)
                    put("updated_at_millis", now)
                    put("source", catalog.sourceId)
                    if (validOffer == null) putNull("offer_label") else if (external.offerLabel.isNullOrBlank()) putNull("offer_label") else put("offer_label", external.offerLabel)
                    if (validOffer == null) putNull("offer_type") else if (external.offerType.isNullOrBlank()) putNull("offer_type") else put("offer_type", external.offerType)
                    if (validOffer == null || external.offerStartMillis == null) putNull("offer_start_millis") else put("offer_start_millis", external.offerStartMillis)
                }
                val updated = db.update("prices", values, "product_id=? AND store_id=?", arrayOf(productId.toString(), storeId.toString()))
                if (updated == 0) db.insertOrThrow("prices", null, values)
                priceUpdates++

                val newEffective = validOffer ?: external.regularPriceCents
                if (oldEffective != newEffective) insertHistory(db, productId, storeId, newEffective, now)
            }

            if (catalog.fullSnapshot) {
                // Products that disappeared from a live offer feed keep their normal price,
                // but no stale promotion may remain visible.
                db.execSQL(
                    """
                    UPDATE prices
                    SET offer_price_cents=NULL, offer_until_millis=NULL, offer_label=NULL,
                        offer_type=NULL, offer_start_millis=NULL, updated_at_millis=?
                    WHERE store_id=? AND source=? AND product_id IN (
                        SELECT product_id FROM product_sources
                        WHERE store_id=? AND source_id=? AND last_seen_millis < ?
                    )
                    """.trimIndent(),
                    arrayOf<Any?>(now, storeId, catalog.sourceId, storeId, catalog.sourceId, now)
                )
            }

            db.insertWithOnConflict("source_syncs", null, ContentValues().apply {
                put("source_id", catalog.sourceId)
                put("store_id", storeId)
                put("last_success_millis", now)
                put("item_count", catalog.products.size)
            }, SQLiteDatabase.CONFLICT_REPLACE)

            db.setTransactionSuccessful()
            return CatalogImportResult(catalog.storeName, catalog.products.size, created, priceUpdates, activeOffers)
        } finally {
            db.endTransaction()
        }
    }

    private fun stableSourceProductId(product: ExternalProduct): String {
        product.sourceProductId?.trim()?.takeIf { it.isNotBlank() }?.let { return it }
        product.ean?.trim()?.takeIf { it.isNotBlank() }?.let { return "ean:$it" }
        return listOf(
            normalize(product.name), normalize(product.brand),
            String.format(Locale.US, "%.3f", product.sizeValue), normalize(product.sizeUnit)
        ).joinToString("|")
    }

    private fun ensureStore(db: SQLiteDatabase, name: String, country: Country): Long {
        db.rawQuery(
            "SELECT id FROM stores WHERE LOWER(TRIM(name))=? AND country=? LIMIT 1",
            arrayOf(normalize(name), country.name)
        ).use { if (it.moveToFirst()) return it.getLong(0) }
        return db.insertOrThrow("stores", null, ContentValues().apply {
            put("name", name.trim())
            put("country", country.name)
            put("enabled", 1)
        })
    }

    private fun findMappedProductId(db: SQLiteDatabase, storeId: Long, sourceId: String, sourceProductId: String): Long? =
        db.rawQuery(
            "SELECT product_id FROM product_sources WHERE store_id=? AND source_id=? AND source_product_id=? LIMIT 1",
            arrayOf(storeId.toString(), sourceId, sourceProductId)
        ).use { if (it.moveToFirst()) it.getLong(0) else null }

    private fun findProductIdByEan(db: SQLiteDatabase, ean: String): Long? =
        db.rawQuery("SELECT id FROM products WHERE ean=? LIMIT 1", arrayOf(ean.trim())).use {
            if (it.moveToFirst()) it.getLong(0) else null
        }

    private fun findProductByMetadata(db: SQLiteDatabase, p: ExternalProduct): Long? {
        db.rawQuery(
            "SELECT id,size_value,size_unit FROM products WHERE LOWER(TRIM(name))=? AND LOWER(TRIM(brand))=? LIMIT 20",
            arrayOf(normalize(p.name), normalize(p.brand))
        ).use { c ->
            while (c.moveToNext()) {
                val sameUnit = normalize(c.getString(2)) == normalize(p.sizeUnit)
                val sameSize = abs(c.getDouble(1) - p.sizeValue) < 0.001
                if (sameUnit && sameSize) return c.getLong(0)
            }
        }
        return null
    }

    private fun insertExternalProduct(db: SQLiteDatabase, p: ExternalProduct): Long =
        db.insertOrThrow("products", null, ContentValues().apply {
            if (p.ean.isNullOrBlank()) putNull("ean") else put("ean", p.ean.trim())
            put("name", p.name.trim())
            put("brand", p.brand.trim())
            put("size_value", p.sizeValue.coerceAtLeast(0.0))
            put("size_unit", p.sizeUnit.trim())
            put("category", p.category.trim().ifBlank { "Overig" })
        })

    private fun updateExternalProduct(db: SQLiteDatabase, productId: Long, p: ExternalProduct) {
        db.update("products", ContentValues().apply {
            if (!p.ean.isNullOrBlank()) put("ean", p.ean.trim())
            put("name", p.name.trim())
            put("brand", p.brand.trim())
            put("size_value", p.sizeValue.coerceAtLeast(0.0))
            put("size_unit", p.sizeUnit.trim())
            put("category", p.category.trim().ifBlank { "Overig" })
        }, "id=?", arrayOf(productId.toString()))
    }

    private fun isPlaceholderProduct(db: SQLiteDatabase, productId: Long): Boolean =
        db.rawQuery("SELECT name FROM products WHERE id=?", arrayOf(productId.toString())).use {
            it.moveToFirst() && it.getString(0) == "Onbekend product"
        }

    private fun currentEffectivePrice(db: SQLiteDatabase, productId: Long, storeId: Long, now: Long): Int? =
        db.rawQuery(
            "SELECT regular_price_cents,offer_price_cents,offer_until_millis FROM prices WHERE product_id=? AND store_id=? LIMIT 1",
            arrayOf(productId.toString(), storeId.toString())
        ).use { c ->
            if (!c.moveToFirst()) null else {
                val regular = c.getInt(0)
                val offer = if (c.isNull(1)) null else c.getInt(1)
                val until = if (c.isNull(2)) null else c.getLong(2)
                if (offer != null && PriceRules.isValidOffer(regular, offer) && (until == null || until >= now)) offer else regular
            }
        }

    private fun insertHistory(db: SQLiteDatabase, productId: Long, storeId: Long, cents: Int, now: Long) {
        db.insertOrThrow("price_history", null, ContentValues().apply {
            put("product_id", productId)
            put("store_id", storeId)
            put("price_cents", cents)
            put("captured_at_millis", now)
        })
    }

    private fun clearExpiredOffers(db: SQLiteDatabase, now: Long) {
        db.execSQL(
            "UPDATE prices SET offer_price_cents=NULL, offer_until_millis=NULL, offer_label=NULL, offer_type=NULL, offer_start_millis=NULL " +
                "WHERE offer_until_millis IS NOT NULL AND offer_until_millis < ?",
            arrayOf(now)
        )
    }

    private fun normalize(value: String): String = value.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")

    @Synchronized
    fun addToList(productId: Long, quantity: Int = 1) {
        val db = dbHelper.writableDatabase
        val c = db.query("shopping_list", arrayOf("quantity"), "product_id=?", arrayOf(productId.toString()), null, null, null)
        val existing = c.use { if (it.moveToFirst()) it.getInt(0) else null }
        if (existing == null) {
            db.insertOrThrow("shopping_list", null, ContentValues().apply {
                put("product_id", productId)
                put("quantity", quantity.coerceIn(1, PriceRules.MAX_QUANTITY))
                put("checked", 0)
            })
        } else setListQuantity(productId, (existing + quantity).coerceAtMost(PriceRules.MAX_QUANTITY))
    }

    @Synchronized
    fun setListQuantity(productId: Long, quantity: Int) {
        val db = dbHelper.writableDatabase
        if (quantity <= 0) db.delete("shopping_list", "product_id=?", arrayOf(productId.toString()))
        else db.update("shopping_list", ContentValues().apply { put("quantity", quantity.coerceAtMost(PriceRules.MAX_QUANTITY)) }, "product_id=?", arrayOf(productId.toString()))
    }

    @Synchronized
    fun setListChecked(productId: Long, checked: Boolean) {
        dbHelper.writableDatabase.update("shopping_list", ContentValues().apply { put("checked", if (checked) 1 else 0) }, "product_id=?", arrayOf(productId.toString()))
    }

    @Synchronized fun clearChecked() { dbHelper.writableDatabase.delete("shopping_list", "checked=1", null) }
    @Synchronized fun exportBackup(uri: Uri) { backupManager.exportTo(uri) }
    @Synchronized fun importBackup(uri: Uri): BackupManager.ImportResult = backupManager.importFrom(uri)

    @Synchronized
    fun resetDemoData() {
        dbHelper.close()
        context.deleteDatabase(AppDatabase.DB_NAME)
        AppDatabase(context).writableDatabase.close()
    }

    private fun queryStores(c: Cursor): List<Store> = c.use {
        buildList { while (it.moveToNext()) add(Store(it.long("id"), it.string("name"), Country.valueOf(it.string("country")), it.int("enabled") == 1)) }
    }
    private fun queryProducts(c: Cursor): List<Product> = c.use { buildList { while (it.moveToNext()) add(productFromCursor(it)) } }
    private fun queryPrices(c: Cursor): List<PriceEntry> = c.use {
        buildList {
            while (it.moveToNext()) add(PriceEntry(
                id = it.long("id"), productId = it.long("product_id"), storeId = it.long("store_id"),
                regularPriceCents = it.int("regular_price_cents"), offerPriceCents = it.nullableInt("offer_price_cents"),
                offerUntilMillis = it.nullableLong("offer_until_millis"), updatedAtMillis = it.long("updated_at_millis"),
                source = it.nullableString("source") ?: "MANUAL", offerLabel = it.nullableString("offer_label"),
                offerType = it.nullableString("offer_type"), offerStartMillis = it.nullableLong("offer_start_millis")
            ))
        }
    }
    private fun queryShoppingList(c: Cursor): List<ShoppingListItem> = c.use { buildList { while (it.moveToNext()) add(ShoppingListItem(it.long("product_id"), it.int("quantity"), it.int("checked") == 1)) } }
    private fun queryHistory(c: Cursor): List<PriceHistoryPoint> = c.use { buildList { while (it.moveToNext()) add(PriceHistoryPoint(it.long("product_id"), it.long("store_id"), it.int("price_cents"), it.long("captured_at_millis"))) } }

    private fun productFromCursor(c: Cursor) = Product(c.long("id"), c.nullableString("ean"), c.string("name"), c.string("brand"), c.double("size_value"), c.string("size_unit"), c.string("category"))
    private fun Cursor.index(name: String) = getColumnIndexOrThrow(name)
    private fun Cursor.string(name: String) = getString(index(name))
    private fun Cursor.nullableString(name: String) = index(name).let { if (isNull(it)) null else getString(it) }
    private fun Cursor.int(name: String) = getInt(index(name))
    private fun Cursor.nullableInt(name: String) = index(name).let { if (isNull(it)) null else getInt(it) }
    private fun Cursor.long(name: String) = getLong(index(name))
    private fun Cursor.nullableLong(name: String) = index(name).let { if (isNull(it)) null else getLong(it) }
    private fun Cursor.double(name: String) = getDouble(index(name))
}
