package nl.jays.boodschappenduitsland.data

import android.content.ContentValues
import android.content.Context
import android.net.Uri
import nl.jays.boodschappenduitsland.domain.Country
import nl.jays.boodschappenduitsland.domain.PriceRules
import org.json.JSONArray
import org.json.JSONObject
import java.io.BufferedReader
import java.io.OutputStreamWriter

class BackupManager(
    private val context: Context,
    private val dbHelper: AppDatabase
) {
    data class ImportResult(val darkMode: Boolean)

    fun exportTo(uri: Uri) {
        val db = dbHelper.readableDatabase
        val prefs = context.getSharedPreferences("settings", 0)

        val root = JSONObject().apply {
            put("format", BACKUP_FORMAT)
            put("formatVersion", BACKUP_FORMAT_VERSION)
            put("databaseVersion", AppDatabase.DB_VERSION)
            put("createdAtMillis", System.currentTimeMillis())
            put("settings", JSONObject().apply { put("darkMode", prefs.getBoolean("dark_mode", false)) })
            put("stores", queryArray(db.rawQuery("SELECT id,name,country,enabled FROM stores ORDER BY id", null)) { c ->
                JSONObject().apply {
                    put("id", c.getLong(0)); put("name", c.getString(1)); put("country", c.getString(2)); put("enabled", c.getInt(3) == 1)
                }
            })
            put("products", queryArray(db.rawQuery("SELECT id,ean,name,brand,size_value,size_unit,category FROM products ORDER BY id", null)) { c ->
                JSONObject().apply {
                    put("id", c.getLong(0)); put("ean", if (c.isNull(1)) JSONObject.NULL else c.getString(1)); put("name", c.getString(2))
                    put("brand", c.getString(3)); put("sizeValue", c.getDouble(4)); put("sizeUnit", c.getString(5)); put("category", c.getString(6))
                }
            })
            put("prices", queryArray(db.rawQuery(
                "SELECT id,product_id,store_id,regular_price_cents,offer_price_cents,offer_until_millis," +
                    "updated_at_millis,source,offer_label,offer_type,offer_start_millis FROM prices ORDER BY id", null
            )) { c ->
                JSONObject().apply {
                    put("id", c.getLong(0)); put("productId", c.getLong(1)); put("storeId", c.getLong(2)); put("regularPriceCents", c.getInt(3))
                    put("offerPriceCents", if (c.isNull(4)) JSONObject.NULL else c.getInt(4)); put("offerUntilMillis", if (c.isNull(5)) JSONObject.NULL else c.getLong(5))
                    put("updatedAtMillis", c.getLong(6)); put("source", c.getString(7)); put("offerLabel", if (c.isNull(8)) JSONObject.NULL else c.getString(8))
                    put("offerType", if (c.isNull(9)) JSONObject.NULL else c.getString(9)); put("offerStartMillis", if (c.isNull(10)) JSONObject.NULL else c.getLong(10))
                }
            })
            put("shoppingList", queryArray(db.rawQuery("SELECT product_id,quantity,checked FROM shopping_list ORDER BY product_id", null)) { c ->
                JSONObject().apply { put("productId", c.getLong(0)); put("quantity", c.getInt(1)); put("checked", c.getInt(2) == 1) }
            })
            put("priceHistory", queryArray(db.rawQuery("SELECT product_id,store_id,price_cents,captured_at_millis FROM price_history ORDER BY id", null)) { c ->
                JSONObject().apply { put("productId", c.getLong(0)); put("storeId", c.getLong(1)); put("priceCents", c.getInt(2)); put("capturedAtMillis", c.getLong(3)) }
            })
            put("productSources", queryArray(db.rawQuery(
                "SELECT store_id,product_id,source_id,source_product_id,last_seen_millis FROM product_sources ORDER BY store_id,source_id,source_product_id", null
            )) { c ->
                JSONObject().apply {
                    put("storeId", c.getLong(0)); put("productId", c.getLong(1)); put("sourceId", c.getString(2)); put("sourceProductId", c.getString(3)); put("lastSeenMillis", c.getLong(4))
                }
            })
            put("sourceSyncs", queryArray(db.rawQuery(
                "SELECT source_id,store_id,last_success_millis,item_count FROM source_syncs ORDER BY source_id", null
            )) { c ->
                JSONObject().apply { put("sourceId", c.getString(0)); put("storeId", c.getLong(1)); put("lastSuccessMillis", c.getLong(2)); put("itemCount", c.getInt(3)) }
            })
        }

        val output = context.contentResolver.openOutputStream(uri, "wt") ?: error("Back-upbestand kan niet worden geopend")
        output.use { stream -> OutputStreamWriter(stream, Charsets.UTF_8).use { writer -> writer.write(root.toString(2)); writer.flush() } }
    }

    fun importFrom(uri: Uri): ImportResult {
        val input = context.contentResolver.openInputStream(uri) ?: error("Back-upbestand kan niet worden geopend")
        val text = input.use { stream ->
            BufferedReader(stream.reader(Charsets.UTF_8)).use { reader ->
                val content = reader.readText()
                require(content.toByteArray(Charsets.UTF_8).size <= MAX_BACKUP_BYTES) { "Back-upbestand is te groot" }
                content
            }
        }

        val root = JSONObject(text)
        require(root.optString("format") == BACKUP_FORMAT) { "Dit is geen geldige Boodschappen Duitsland-back-up" }
        val formatVersion = root.optInt("formatVersion", -1)
        require(formatVersion in MIN_SUPPORTED_BACKUP_VERSION..BACKUP_FORMAT_VERSION) { "Niet-ondersteunde back-upversie" }
        val backupDatabaseVersion = root.optInt("databaseVersion", -1)
        require(backupDatabaseVersion in 1..AppDatabase.DB_VERSION) { "Back-up is gemaakt met een nieuwere, niet-ondersteunde databaseversie" }

        val stores = root.getJSONArray("stores")
        val products = root.getJSONArray("products")
        val prices = root.getJSONArray("prices")
        val shoppingList = root.getJSONArray("shoppingList")
        val history = root.getJSONArray("priceHistory")
        val productSources = root.optJSONArray("productSources") ?: JSONArray()
        val sourceSyncs = root.optJSONArray("sourceSyncs") ?: JSONArray()
        val darkMode = (root.optJSONObject("settings") ?: JSONObject()).optBoolean("darkMode", false)

        validateBackup(stores, products, prices, shoppingList, history, productSources, sourceSyncs)

        val db = dbHelper.writableDatabase
        db.beginTransaction()
        try {
            db.delete("source_syncs", null, null)
            db.delete("product_sources", null, null)
            db.delete("price_history", null, null)
            db.delete("shopping_list", null, null)
            db.delete("prices", null, null)
            db.delete("products", null, null)
            db.delete("stores", null, null)

            for (i in 0 until stores.length()) {
                val item = stores.getJSONObject(i)
                db.insertOrThrow("stores", null, ContentValues().apply {
                    put("id", item.getLong("id")); put("name", item.getString("name")); put("country", item.getString("country")); put("enabled", if (item.optBoolean("enabled", true)) 1 else 0)
                })
            }
            for (i in 0 until products.length()) {
                val item = products.getJSONObject(i)
                db.insertOrThrow("products", null, ContentValues().apply {
                    put("id", item.getLong("id")); if (item.isNull("ean")) putNull("ean") else put("ean", item.getString("ean")); put("name", item.getString("name"))
                    put("brand", item.optString("brand", "")); put("size_value", item.getDouble("sizeValue")); put("size_unit", item.optString("sizeUnit", "")); put("category", item.optString("category", ""))
                })
            }
            for (i in 0 until prices.length()) {
                val item = prices.getJSONObject(i)
                db.insertOrThrow("prices", null, ContentValues().apply {
                    put("id", item.getLong("id")); put("product_id", item.getLong("productId")); put("store_id", item.getLong("storeId")); put("regular_price_cents", item.getInt("regularPriceCents"))
                    if (item.isNull("offerPriceCents")) putNull("offer_price_cents") else put("offer_price_cents", item.getInt("offerPriceCents"))
                    if (item.isNull("offerUntilMillis")) putNull("offer_until_millis") else put("offer_until_millis", item.getLong("offerUntilMillis"))
                    put("updated_at_millis", item.getLong("updatedAtMillis")); put("source", item.optString("source", "MANUAL").ifBlank { "MANUAL" })
                    if (!item.has("offerLabel") || item.isNull("offerLabel")) putNull("offer_label") else put("offer_label", item.getString("offerLabel"))
                    if (!item.has("offerType") || item.isNull("offerType")) putNull("offer_type") else put("offer_type", item.getString("offerType"))
                    if (!item.has("offerStartMillis") || item.isNull("offerStartMillis")) putNull("offer_start_millis") else put("offer_start_millis", item.getLong("offerStartMillis"))
                })
            }
            for (i in 0 until shoppingList.length()) {
                val item = shoppingList.getJSONObject(i)
                db.insertOrThrow("shopping_list", null, ContentValues().apply { put("product_id", item.getLong("productId")); put("quantity", item.getInt("quantity")); put("checked", if (item.optBoolean("checked", false)) 1 else 0) })
            }
            for (i in 0 until history.length()) {
                val item = history.getJSONObject(i)
                db.insertOrThrow("price_history", null, ContentValues().apply { put("product_id", item.getLong("productId")); put("store_id", item.getLong("storeId")); put("price_cents", item.getInt("priceCents")); put("captured_at_millis", item.getLong("capturedAtMillis")) })
            }
            for (i in 0 until productSources.length()) {
                val item = productSources.getJSONObject(i)
                db.insertOrThrow("product_sources", null, ContentValues().apply {
                    put("store_id", item.getLong("storeId")); put("product_id", item.getLong("productId")); put("source_id", item.getString("sourceId")); put("source_product_id", item.getString("sourceProductId")); put("last_seen_millis", item.getLong("lastSeenMillis"))
                })
            }
            for (i in 0 until sourceSyncs.length()) {
                val item = sourceSyncs.getJSONObject(i)
                db.insertOrThrow("source_syncs", null, ContentValues().apply {
                    put("source_id", item.getString("sourceId")); put("store_id", item.getLong("storeId")); put("last_success_millis", item.getLong("lastSuccessMillis")); put("item_count", item.optInt("itemCount", 0))
                })
            }
            db.setTransactionSuccessful()
        } finally { db.endTransaction() }

        context.getSharedPreferences("settings", 0).edit().putBoolean("dark_mode", darkMode).commit()
        return ImportResult(darkMode)
    }

    private fun validateBackup(
        stores: JSONArray,
        products: JSONArray,
        prices: JSONArray,
        shoppingList: JSONArray,
        history: JSONArray,
        productSources: JSONArray,
        sourceSyncs: JSONArray
    ) {
        val storeIds = mutableSetOf<Long>()
        val productIds = mutableSetOf<Long>()
        val eans = mutableSetOf<String>()
        val pricePairs = mutableSetOf<Pair<Long, Long>>()
        val sourceKeys = mutableSetOf<Triple<Long, String, String>>()
        val syncIds = mutableSetOf<String>()

        for (i in 0 until stores.length()) {
            val item = stores.getJSONObject(i); val id = item.getLong("id")
            require(id > 0 && storeIds.add(id)) { "Ongeldige of dubbele winkel-ID in back-up" }
            require(item.getString("name").isNotBlank()) { "Winkelnaam ontbreekt in back-up" }; Country.valueOf(item.getString("country"))
        }
        for (i in 0 until products.length()) {
            val item = products.getJSONObject(i); val id = item.getLong("id")
            require(id > 0 && productIds.add(id)) { "Ongeldige of dubbele product-ID in back-up" }
            require(item.getString("name").isNotBlank()) { "Productnaam ontbreekt in back-up" }
            require(item.getDouble("sizeValue").isFinite() && item.getDouble("sizeValue") >= 0.0) { "Ongeldige productinhoud in back-up" }
            if (!item.isNull("ean")) { val ean = item.getString("ean"); require(ean.isNotBlank() && eans.add(ean)) { "Dubbele of lege EAN in back-up" } }
        }
        for (i in 0 until prices.length()) {
            val item = prices.getJSONObject(i); val productId = item.getLong("productId"); val storeId = item.getLong("storeId"); val regular = item.getInt("regularPriceCents")
            val offer = if (item.isNull("offerPriceCents")) null else item.getInt("offerPriceCents")
            require(productId in productIds && storeId in storeIds) { "Prijs verwijst naar onbekend product of winkel" }
            require(pricePairs.add(productId to storeId)) { "Dubbele prijsregel in back-up" }; require(PriceRules.isValidRegularPrice(regular)) { "Ongeldige normale prijs in back-up" }
            if (offer != null) { require(PriceRules.isValidOffer(regular, offer)) { "Ongeldige aanbiedingsprijs in back-up" }; require(!item.isNull("offerUntilMillis") && item.getLong("offerUntilMillis") > 0) { "Aanbieding zonder geldige einddatum in back-up" } }
        }
        for (i in 0 until shoppingList.length()) { val item = shoppingList.getJSONObject(i); require(item.getLong("productId") in productIds) { "Boodschappenlijst verwijst naar onbekend product" }; require(item.getInt("quantity") in 1..PriceRules.MAX_QUANTITY) { "Ongeldig aantal in boodschappenlijst" } }
        for (i in 0 until history.length()) { val item = history.getJSONObject(i); require(item.getLong("productId") in productIds && item.getLong("storeId") in storeIds) { "Prijshistorie verwijst naar onbekend product of winkel" }; require(PriceRules.isValidRegularPrice(item.getInt("priceCents"))) { "Ongeldige prijs in prijshistorie" }; require(item.getLong("capturedAtMillis") > 0) { "Ongeldige datum in prijshistorie" } }
        for (i in 0 until productSources.length()) {
            val item = productSources.getJSONObject(i); val storeId = item.getLong("storeId"); val productId = item.getLong("productId"); val sourceId = item.getString("sourceId"); val sourceProductId = item.getString("sourceProductId")
            require(storeId in storeIds && productId in productIds) { "Productbron verwijst naar onbekend product of winkel" }
            require(sourceId.isNotBlank() && sourceProductId.isNotBlank() && sourceKeys.add(Triple(storeId, sourceId, sourceProductId))) { "Ongeldige of dubbele productbron in back-up" }
            require(item.getLong("lastSeenMillis") > 0) { "Ongeldige productbrondatum in back-up" }
        }
        for (i in 0 until sourceSyncs.length()) {
            val item = sourceSyncs.getJSONObject(i); val sourceId = item.getString("sourceId")
            require(sourceId.isNotBlank() && syncIds.add(sourceId)) { "Ongeldige of dubbele synchronisatiebron in back-up" }
            require(item.getLong("storeId") in storeIds && item.getLong("lastSuccessMillis") > 0) { "Ongeldige synchronisatie in back-up" }
        }
    }

    private inline fun queryArray(cursor: android.database.Cursor, mapper: (android.database.Cursor) -> JSONObject): JSONArray = cursor.use {
        JSONArray().apply { while (it.moveToNext()) put(mapper(it)) }
    }

    companion object {
        private const val BACKUP_FORMAT = "nl.jays.boodschappenduitsland.backup"
        private const val MIN_SUPPORTED_BACKUP_VERSION = 1
        private const val BACKUP_FORMAT_VERSION = 2
        private const val MAX_BACKUP_BYTES = 100 * 1024 * 1024
    }
}
