package nl.jays.boodschappenduitsland.data

import nl.jays.boodschappenduitsland.domain.Country
import nl.jays.boodschappenduitsland.domain.PriceRules
import org.json.JSONObject
import java.net.HttpURLConnection
import java.net.URL
import java.net.URLEncoder
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

/**
 * Live Albert Heijn Bonus reader.
 *
 * AH does not publish a stable public API contract for these endpoints. The
 * implementation therefore fails closed: a network/parser error leaves the
 * last known local offers untouched.
 */
class AlbertHeijnOfferSource {
    fun fetch(): ExternalCatalog {
        val token = anonymousToken()
        val metadata = getJson("/mobile-services/bonuspage/v3/metadata", token)
        val period = selectCurrentPeriod(metadata)
        val categories = period.categories.distinct()
        require(categories.isNotEmpty()) { "Albert Heijn gaf geen Bonus-categorieën terug" }

        val deduped = LinkedHashMap<String, ExternalProduct>()
        categories.forEach { category ->
            val encodedCategory = URLEncoder.encode(category, "UTF-8")
            val path = "/mobile-services/bonuspage/v2/section" +
                "?application=AHWEBSHOP" +
                "&date=${today()}" +
                "&promotionType=NATIONAL" +
                "&category=$encodedCategory"
            val section = getJson(path, token)
            collectSection(section, period.startMillis, period.endMillis).forEach { product ->
                val key = product.sourceProductId?.let { "id:$it" }
                    ?: "name:${normalize(product.name)}:${normalize(product.brand)}:${product.regularPriceCents}"
                deduped[key] = product
            }
        }

        return ExternalCatalog(
            sourceId = SOURCE_ID,
            storeKey = "albert_heijn_nl",
            storeName = "Albert Heijn",
            country = Country.NL,
            fullSnapshot = true,
            products = deduped.values.toList()
        )
    }

    private fun anonymousToken(): String {
        val connection = (URL("$BASE_URL/mobile-auth/v1/auth/token/anonymous").openConnection() as HttpURLConnection).apply {
            requestMethod = "POST"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            doOutput = true
            setCommonHeaders(this, null)
        }
        try {
            val body = "{\"clientId\":\"$CLIENT_ID\"}"
            connection.outputStream.use { it.write(body.toByteArray(Charsets.UTF_8)) }
            val json = readResponse(connection)
            return JSONObject(json).getString("access_token").also {
                require(it.isNotBlank()) { "Albert Heijn gaf geen toegangstoken terug" }
            }
        } finally {
            connection.disconnect()
        }
    }

    private fun getJson(path: String, token: String): JSONObject {
        val connection = (URL(BASE_URL + path).openConnection() as HttpURLConnection).apply {
            requestMethod = "GET"
            connectTimeout = CONNECT_TIMEOUT_MS
            readTimeout = READ_TIMEOUT_MS
            setCommonHeaders(this, token)
        }
        return try {
            JSONObject(readResponse(connection))
        } finally {
            connection.disconnect()
        }
    }

    private fun setCommonHeaders(connection: HttpURLConnection, token: String?) {
        connection.setRequestProperty("User-Agent", USER_AGENT)
        connection.setRequestProperty("x-client-name", CLIENT_ID)
        connection.setRequestProperty("x-client-version", CLIENT_VERSION)
        connection.setRequestProperty("x-application", "AHWEBSHOP")
        connection.setRequestProperty("Accept", "application/json")
        connection.setRequestProperty("Content-Type", "application/json")
        if (!token.isNullOrBlank()) connection.setRequestProperty("Authorization", "Bearer $token")
    }

    private fun readResponse(connection: HttpURLConnection): String {
        val code = connection.responseCode
        val stream = if (code in 200..299) connection.inputStream else connection.errorStream
        val body = stream?.bufferedReader(Charsets.UTF_8)?.use { it.readText() }.orEmpty()
        if (code !in 200..299) {
            val detail = runCatching { JSONObject(body).optString("message") }.getOrNull().orEmpty()
            error("Albert Heijn vernieuwen mislukt (HTTP $code)${if (detail.isBlank()) "" else ": $detail"}")
        }
        require(body.toByteArray(Charsets.UTF_8).size <= MAX_RESPONSE_BYTES) { "Albert Heijn antwoord is te groot" }
        return body
    }

    private data class BonusPeriod(
        val startMillis: Long,
        val endMillis: Long,
        val categories: List<String>
    )

    private fun selectCurrentPeriod(metadata: JSONObject): BonusPeriod {
        val periods = metadata.getJSONArray("periods")
        require(periods.length() > 0) { "Albert Heijn gaf geen Bonus-periode terug" }
        val today = today()
        var selectedIndex = 0
        for (i in 0 until periods.length()) {
            val p = periods.getJSONObject(i)
            val start = p.optString("bonusStartDate")
            val end = p.optString("bonusEndDate")
            if (start.isNotBlank() && end.isNotBlank() && today >= start && today <= end) {
                selectedIndex = i
                break
            }
        }
        val selected = periods.getJSONObject(selectedIndex)
        val startDate = selected.getString("bonusStartDate")
        val endDate = selected.getString("bonusEndDate")
        val categories = mutableListOf<String>()
        val tabs = selected.optJSONArray("tabs")
        if (tabs != null) {
            for (i in 0 until tabs.length()) {
                val list = tabs.getJSONObject(i).optJSONArray("urlMetadataList") ?: continue
                for (j in 0 until list.length()) {
                    val item = list.getJSONObject(j)
                    if (item.optString("bonusType") == "NATIONAL") {
                        item.optString("description").trim().takeIf { it.isNotBlank() }?.let(categories::add)
                    }
                }
            }
        }
        return BonusPeriod(
            startMillis = parseDate(startDate, false),
            endMillis = parseDate(endDate, true),
            categories = categories
        )
    }

    private fun collectSection(root: JSONObject, startMillis: Long, endMillis: Long): List<ExternalProduct> {
        val results = mutableListOf<ExternalProduct>()
        val items = root.optJSONArray("bonusGroupOrProducts") ?: return results
        for (i in 0 until items.length()) {
            val item = items.getJSONObject(i)
            item.optJSONObject("product")?.let { product ->
                parseProduct(product, null, null, startMillis, endMillis)?.let(results::add)
            }
            item.optJSONObject("bonusGroup")?.let { group ->
                val label = group.optString("discountDescription").trim().takeIf { it.isNotBlank() }
                val category = group.optString("category").trim().takeIf { it.isNotBlank() }
                val products = group.optJSONArray("products")
                if (products != null && products.length() > 0) {
                    for (j in 0 until products.length()) {
                        parseProduct(products.getJSONObject(j), label, category, startMillis, endMillis)?.let(results::add)
                    }
                } else {
                    parseGroup(group, startMillis, endMillis)?.let(results::add)
                }
            }
        }
        return results
    }

    private fun parseProduct(
        item: JSONObject,
        groupLabel: String?,
        groupCategory: String?,
        startMillis: Long,
        endMillis: Long
    ): ExternalProduct? {
        val name = item.optString("title").trim()
        if (name.isBlank()) return null
        val current = moneyToCentsOrNull(item.optDouble("currentPrice", Double.NaN))
        val was = moneyToCentsOrNull(item.optDouble("priceBeforeBonus", Double.NaN))
        val regular = (was ?: current)?.takeIf(PriceRules::isValidRegularPrice) ?: return null
        val label = item.optString("bonusMechanism").trim().takeIf { it.isNotBlank() } ?: groupLabel
        val offer = PromotionCalculator.effectiveOfferCents(
            regularPriceCents = regular,
            explicitCurrentPriceCents = current,
            type = inferType(label),
            label = label
        )
        if (offer == null) return null
        val id = item.optInt("webshopId", 0).takeIf { it > 0 }
            ?: item.optInt("hqId", 0).takeIf { it > 0 }
        val (sizeValue, sizeUnit) = parseUnitSize(item.optString("salesUnitSize", "1 st"))
        return ExternalProduct(
            sourceProductId = id?.toString(),
            ean = null,
            name = name,
            brand = item.optString("brand").trim(),
            category = item.optString("mainCategory").trim().ifBlank { groupCategory ?: "Aanbiedingen" },
            sizeValue = sizeValue,
            sizeUnit = sizeUnit,
            regularPriceCents = regular,
            offerPriceCents = offer,
            offerStartMillis = startMillis,
            offerUntilMillis = endMillis,
            offerLabel = label ?: "Bonus",
            offerType = inferType(label)
        )
    }

    private fun parseGroup(group: JSONObject, startMillis: Long, endMillis: Long): ExternalProduct? {
        val name = group.optString("segmentDescription").trim()
        if (name.isBlank()) return null
        val regular = moneyToCentsOrNull(group.optDouble("exampleFromPrice", Double.NaN)) ?: return null
        val current = moneyToCentsOrNull(group.optDouble("exampleForPrice", Double.NaN))
        val label = group.optString("discountDescription").trim().takeIf { it.isNotBlank() }
        val offer = PromotionCalculator.effectiveOfferCents(regular, current, inferType(label), label) ?: return null
        return ExternalProduct(
            sourceProductId = group.optString("id").trim().takeIf { it.isNotBlank() }?.let { "group:$it" },
            ean = null,
            name = name,
            brand = "",
            category = group.optString("category").trim().ifBlank { "Aanbiedingen" },
            sizeValue = 1.0,
            sizeUnit = "actie",
            regularPriceCents = regular,
            offerPriceCents = offer,
            offerStartMillis = startMillis,
            offerUntilMillis = endMillis,
            offerLabel = label ?: "Bonus",
            offerType = inferType(label)
        )
    }

    private fun inferType(label: String?): String? {
        val value = label.orEmpty().lowercase(Locale.ROOT)
        return when {
            Regex("\\d+\\s*\\+\\s*\\d+\\s*gratis").containsMatchIn(value) -> "buy_x_get_y_free"
            Regex("\\d+\\s+voor\\s+").containsMatchIn(value) -> "bundle_price"
            "%" in value -> "percentage_discount"
            value.isNotBlank() -> "promotion"
            else -> null
        }
    }

    private fun moneyToCentsOrNull(value: Double): Int? {
        if (!value.isFinite() || value <= 0.0) return null
        return (value * 100.0).roundToInt().takeIf(PriceRules::isValidRegularPrice)
    }

    private fun parseUnitSize(raw: String): Pair<Double, String> {
        val text = raw.trim().lowercase(Locale.ROOT)
        val multi = Regex("([0-9]+)\\s*[x×]\\s*([0-9]+(?:[.,][0-9]+)?)\\s*([a-z]+)").find(text)
        if (multi != null) {
            val count = multi.groupValues[1].toDoubleOrNull() ?: 1.0
            val each = multi.groupValues[2].replace(',', '.').toDoubleOrNull() ?: 1.0
            return count * each to normalizeUnit(multi.groupValues[3])
        }
        val single = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*([a-z]+)").find(text)
        if (single != null) {
            return (single.groupValues[1].replace(',', '.').toDoubleOrNull() ?: 1.0) to normalizeUnit(single.groupValues[2])
        }
        return 1.0 to "st"
    }

    private fun normalizeUnit(unit: String): String = when (unit) {
        "stuk", "stuks", "st" -> "st"
        "liter", "liters", "ltr", "l" -> "l"
        "milliliter", "milliliters", "ml" -> "ml"
        "centiliter", "centiliters", "cl" -> "cl"
        "kilogram", "kilograms", "kg" -> "kg"
        "gram", "grams", "g" -> "g"
        else -> unit
    }

    private fun parseDate(value: String, endOfDay: Boolean): Long {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
        val date = requireNotNull(format.parse(value)) { "Ongeldige Bonus-datum" }
        return Calendar.getInstance().apply {
            time = date
            if (endOfDay) {
                set(Calendar.HOUR_OF_DAY, 23); set(Calendar.MINUTE, 59); set(Calendar.SECOND, 59); set(Calendar.MILLISECOND, 999)
            } else {
                set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0); set(Calendar.SECOND, 0); set(Calendar.MILLISECOND, 0)
            }
        }.timeInMillis
    }

    private fun today(): String = SimpleDateFormat("yyyy-MM-dd", Locale.US).format(System.currentTimeMillis())
    private fun normalize(value: String) = value.trim().lowercase(Locale.ROOT).replace(Regex("\\s+"), " ")

    companion object {
        const val SOURCE_ID = "AH_LIVE_BONUS"
        private const val BASE_URL = "https://api.ah.nl"
        private const val USER_AGENT = "Appie/9.28 (iPhone17,3; iPhone; CPU OS 26_1 like Mac OS X)"
        private const val CLIENT_ID = "appie-ios"
        private const val CLIENT_VERSION = "9.28"
        private const val CONNECT_TIMEOUT_MS = 15_000
        private const val READ_TIMEOUT_MS = 30_000
        private const val MAX_RESPONSE_BYTES = 15 * 1024 * 1024
    }
}
