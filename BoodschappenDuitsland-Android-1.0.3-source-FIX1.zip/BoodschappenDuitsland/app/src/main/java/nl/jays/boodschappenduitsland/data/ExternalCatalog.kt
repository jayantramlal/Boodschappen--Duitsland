package nl.jays.boodschappenduitsland.data

import nl.jays.boodschappenduitsland.domain.Country
import nl.jays.boodschappenduitsland.domain.PriceRules
import kotlin.math.roundToInt

data class ExternalCatalog(
    val sourceId: String,
    val storeKey: String,
    val storeName: String,
    val country: Country,
    val fullSnapshot: Boolean,
    val products: List<ExternalProduct>
)

data class ExternalProduct(
    val sourceProductId: String?,
    val ean: String?,
    val name: String,
    val brand: String,
    val category: String,
    val sizeValue: Double,
    val sizeUnit: String,
    val regularPriceCents: Int,
    val offerPriceCents: Int?,
    val offerStartMillis: Long?,
    val offerUntilMillis: Long?,
    val offerLabel: String?,
    val offerType: String?
)

data class CatalogImportResult(
    val storeName: String,
    val productsProcessed: Int,
    val productsCreated: Int,
    val pricesUpdated: Int,
    val activeOffers: Int
)

data class OfferRefreshResult(
    val sourcesUpdated: Int,
    val productsProcessed: Int,
    val activeOffers: Int,
    val sourceNames: List<String>
)

/**
 * Converts promotions such as 1+1 gratis, 2+1 gratis and 2 voor 3,00 into a
 * comparable effective unit price while keeping the original promotion label.
 */
object PromotionCalculator {
    fun effectiveOfferCents(
        regularPriceCents: Int,
        explicitCurrentPriceCents: Int?,
        type: String?,
        label: String?,
        discountPercent: Double? = null,
        quantity: Int? = null,
        bundlePriceCents: Int? = null
    ): Int? {
        if (!PriceRules.isValidRegularPrice(regularPriceCents)) return null

        explicitCurrentPriceCents
            ?.takeIf { PriceRules.isValidOffer(regularPriceCents, it) }
            ?.let { return it }

        val normalizedType = type.orEmpty().trim().lowercase()
        val normalizedLabel = label.orEmpty().trim().lowercase()

        if (normalizedType == "percentage_discount" && discountPercent != null && discountPercent > 0.0) {
            val cents = (regularPriceCents * (100.0 - discountPercent) / 100.0).roundToInt()
            return cents.takeIf { PriceRules.isValidOffer(regularPriceCents, it) }
        }

        if (normalizedType == "bundle_price" && quantity != null && quantity > 0 && bundlePriceCents != null) {
            val cents = (bundlePriceCents.toDouble() / quantity.toDouble()).roundToInt()
            return cents.takeIf { PriceRules.isValidOffer(regularPriceCents, it) }
        }

        val freeMatch = Regex("(\\d+)\\s*\\+\\s*(\\d+)\\s*gratis").find(normalizedLabel)
        if (normalizedType == "buy_x_get_y_free" || freeMatch != null) {
            val match = freeMatch ?: return null
            val paid = match.groupValues[1].toIntOrNull() ?: return null
            val free = match.groupValues[2].toIntOrNull() ?: return null
            if (paid <= 0 || free <= 0) return null
            val cents = (regularPriceCents.toDouble() * paid / (paid + free)).roundToInt()
            return cents.takeIf { PriceRules.isValidOffer(regularPriceCents, it) }
        }

        val bundleMatch = Regex("(\\d+)\\s+voor\\s+[€]?\\s*([0-9]+(?:[.,][0-9]{1,2})?)").find(normalizedLabel)
        if (bundleMatch != null) {
            val qty = bundleMatch.groupValues[1].toIntOrNull() ?: return null
            val total = bundleMatch.groupValues[2].replace(',', '.').toDoubleOrNull() ?: return null
            if (qty <= 0 || total <= 0.0) return null
            val cents = ((total * 100.0) / qty).roundToInt()
            return cents.takeIf { PriceRules.isValidOffer(regularPriceCents, it) }
        }

        val percentMatch = Regex("([0-9]{1,2}(?:[.,][0-9]+)?)\\s*%\\s*(?:korting)?").find(normalizedLabel)
        if (percentMatch != null) {
            val percent = percentMatch.groupValues[1].replace(',', '.').toDoubleOrNull() ?: return null
            val cents = (regularPriceCents * (100.0 - percent) / 100.0).roundToInt()
            return cents.takeIf { PriceRules.isValidOffer(regularPriceCents, it) }
        }

        return null
    }
}
