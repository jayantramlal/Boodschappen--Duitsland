package nl.jays.boodschappenduitsland.data

import android.content.Context
import android.net.Uri
import nl.jays.boodschappenduitsland.domain.Country
import nl.jays.boodschappenduitsland.domain.PriceRules
import org.json.JSONObject
import java.io.BufferedReader
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.math.roundToInt

class SupermarketCatalogParser(private val context: Context) {
    fun parse(uri: Uri): ExternalCatalog {
        val input = context.contentResolver.openInputStream(uri)
            ?: error("Supermarktbestand kan niet worden geopend")

        val text = input.use { stream ->
            BufferedReader(stream.reader(Charsets.UTF_8)).use { reader ->
                val content = reader.readText()
                require(content.toByteArray(Charsets.UTF_8).size <= MAX_FILE_BYTES) {
                    "Supermarktbestand is te groot"
                }
                content
            }
        }

        val root = JSONObject(text)
        require(root.optInt("schema_version", -1) == 1) { "Niet-ondersteunde supermarktbestand-versie" }
        require(root.optString("database_type") == "supermarket_catalog") {
            "Dit is geen geldig supermarkt-productbestand"
        }

        val supermarket = root.getJSONObject("supermarket")
        val storeKey = supermarket.getString("id").trim()
        val storeName = supermarket.getString("name").trim()
        require(storeKey.isNotBlank() && storeName.isNotBlank()) { "Winkelgegevens ontbreken" }
        require(supermarket.optString("currency", "EUR").equals("EUR", ignoreCase = true)) {
            "Alleen prijzen in euro worden ondersteund"
        }
        val country = when (supermarket.optString("country", "NL").uppercase(Locale.ROOT)) {
            "NL" -> Country.NL
            "DE" -> Country.DE
            else -> error("Alleen Nederland en Duitsland worden ondersteund")
        }

        val productsJson = root.getJSONArray("products")
        require(productsJson.length() <= MAX_PRODUCTS) { "Te veel producten in één importbestand" }
        val products = ArrayList<ExternalProduct>(productsJson.length())

        for (i in 0 until productsJson.length()) {
            val item = productsJson.getJSONObject(i)
            val name = item.getString("name").trim()
            require(name.isNotBlank()) { "Productnaam ontbreekt bij product ${i + 1}" }

            val regularCents = moneyToCents(item.getDouble("regular_price"))
            require(PriceRules.isValidRegularPrice(regularCents)) {
                "Ongeldige normale prijs bij $name"
            }

            val currentCents = item.optDoubleOrNull("current_price")?.let(::moneyToCents)
            val offer = item.optJSONObject("offer")
            val active = offer?.optBoolean("active", false) == true
            val label = offer?.optString("label", "")?.trim()?.takeIf { it.isNotBlank() }
            val type = offer?.optString("type", "")?.trim()?.takeIf { it.isNotBlank() }
            val discountPercent = offer?.optDoubleOrNull("discount_percent")
            val quantity = offer?.optIntOrNull("quantity")
            val bundlePrice = offer?.optDoubleOrNull("bundle_price")?.let(::moneyToCents)

            val offerCents = if (active) {
                PromotionCalculator.effectiveOfferCents(
                    regularPriceCents = regularCents,
                    explicitCurrentPriceCents = currentCents,
                    type = type,
                    label = label,
                    discountPercent = discountPercent,
                    quantity = quantity,
                    bundlePriceCents = bundlePrice
                )
            } else null

            val (sizeValue, sizeUnit) = parseUnitSize(item.optString("unit_size", "1 st"))
            products += ExternalProduct(
                sourceProductId = item.optNullableString("source_id"),
                ean = item.optNullableString("ean"),
                name = name,
                brand = item.optString("brand", "").trim(),
                category = item.optString("category", "Overig").trim().ifBlank { "Overig" },
                sizeValue = sizeValue,
                sizeUnit = sizeUnit,
                regularPriceCents = regularCents,
                offerPriceCents = offerCents,
                offerStartMillis = offer?.optNullableString("start_date")?.let { parseDate(it, endOfDay = false) },
                offerUntilMillis = offer?.optNullableString("end_date")?.let { parseDate(it, endOfDay = true) },
                offerLabel = label,
                offerType = type
            )
        }

        val policy = root.optJSONObject("import_policy")
        val fullSnapshot = policy?.optString("on_missing_product", "keep")
            ?.equals("remove", ignoreCase = true) == true

        return ExternalCatalog(
            sourceId = "CATALOG:$storeKey",
            storeKey = storeKey,
            storeName = storeName,
            country = country,
            fullSnapshot = fullSnapshot,
            products = products
        )
    }

    private fun moneyToCents(value: Double): Int {
        require(value.isFinite() && value > 0.0) { "Ongeldige prijs" }
        val cents = (value * 100.0).roundToInt()
        require(PriceRules.isValidRegularPrice(cents)) { "Prijs buiten ondersteund bereik" }
        return cents
    }

    private fun parseUnitSize(raw: String): Pair<Double, String> {
        val text = raw.trim().lowercase(Locale.ROOT)
        val multi = Regex("([0-9]+)\\s*[x×]\\s*([0-9]+(?:[.,][0-9]+)?)\\s*([a-z]+)").find(text)
        if (multi != null) {
            val count = multi.groupValues[1].toDoubleOrNull() ?: 1.0
            val each = multi.groupValues[2].replace(',', '.').toDoubleOrNull() ?: 1.0
            return (count * each) to normalizeUnit(multi.groupValues[3])
        }

        val single = Regex("([0-9]+(?:[.,][0-9]+)?)\\s*([a-z]+)").find(text)
        if (single != null) {
            val value = single.groupValues[1].replace(',', '.').toDoubleOrNull() ?: 1.0
            return value to normalizeUnit(single.groupValues[2])
        }
        return 1.0 to "st"
    }

    private fun normalizeUnit(unit: String): String = when (unit.lowercase(Locale.ROOT)) {
        "stuk", "stuks", "st" -> "st"
        "liter", "liters", "ltr", "l" -> "l"
        "milliliter", "milliliters", "ml" -> "ml"
        "centiliter", "centiliters", "cl" -> "cl"
        "kilogram", "kilograms", "kg" -> "kg"
        "gram", "grams", "g" -> "g"
        else -> unit
    }

    private fun parseDate(value: String, endOfDay: Boolean): Long {
        val format = SimpleDateFormat("yyyy-MM-dd", Locale.US).apply { isLenient = false }
        val date = requireNotNull(format.parse(value)) { "Ongeldige datum: $value" }
        return Calendar.getInstance().apply {
            time = date
            if (endOfDay) {
                set(Calendar.HOUR_OF_DAY, 23)
                set(Calendar.MINUTE, 59)
                set(Calendar.SECOND, 59)
                set(Calendar.MILLISECOND, 999)
            } else {
                set(Calendar.HOUR_OF_DAY, 0)
                set(Calendar.MINUTE, 0)
                set(Calendar.SECOND, 0)
                set(Calendar.MILLISECOND, 0)
            }
        }.timeInMillis
    }

    private fun JSONObject.optNullableString(key: String): String? {
        if (!has(key) || isNull(key)) return null
        return optString(key, "").trim().takeIf { it.isNotBlank() }
    }

    private fun JSONObject.optDoubleOrNull(key: String): Double? {
        if (!has(key) || isNull(key)) return null
        return optDouble(key, Double.NaN).takeIf { it.isFinite() }
    }

    private fun JSONObject.optIntOrNull(key: String): Int? {
        if (!has(key) || isNull(key)) return null
        return optInt(key, Int.MIN_VALUE).takeIf { it != Int.MIN_VALUE }
    }

    companion object {
        private const val MAX_FILE_BYTES = 100 * 1024 * 1024
        private const val MAX_PRODUCTS = 150_000
    }
}
