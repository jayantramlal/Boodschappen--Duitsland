package nl.jays.boodschappenduitsland.data

import org.junit.Assert.assertEquals
import org.junit.Test

class PromotionCalculatorTest {
    @Test fun onePlusOneIsHalfPricePerUnit() {
        assertEquals(150, PromotionCalculator.effectiveOfferCents(300, null, "buy_x_get_y_free", "1+1 gratis"))
    }

    @Test fun twoPlusOneUsesTwoThirdsPerUnit() {
        assertEquals(200, PromotionCalculator.effectiveOfferCents(300, null, "buy_x_get_y_free", "2+1 gratis"))
    }

    @Test fun bundlePriceIsConvertedPerUnit() {
        assertEquals(150, PromotionCalculator.effectiveOfferCents(200, null, "bundle_price", "2 voor 3,00", quantity = 2, bundlePriceCents = 300))
    }

    @Test fun percentageDiscountIsConverted() {
        assertEquals(300, PromotionCalculator.effectiveOfferCents(500, null, "percentage_discount", "40% korting", discountPercent = 40.0))
    }
}
