#!/usr/bin/env bash
set -euo pipefail
OUT=${1:-release.jks}
keytool -genkeypair -v \
  -keystore "$OUT" \
  -alias boodschappen \
  -keyalg RSA -keysize 4096 -validity 10000
printf '\nKeystore created: %s\n' "$OUT"
printf 'Store it safely. Do NOT commit it to Git.\n'
printf 'For GitHub secret RELEASE_KEYSTORE_BASE64 run:\n  base64 -w 0 %s\n' "$OUT"
