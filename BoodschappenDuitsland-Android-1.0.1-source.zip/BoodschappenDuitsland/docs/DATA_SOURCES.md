# Live prijsbronnen

Versie 1.0.0 bevat lokale, bewerkbare demo-/testdata. Er worden nog geen prijzen voorgedaan als live supermarktdata.

Live bronnen worden per winkel geïmplementeerd achter `PriceSource`. Een provider moet minimaal leveren:
- EAN/productidentificatie
- winkelnaam/land
- normale prijs
- eventuele aanbieding
- geldigheidsdatum
- brontijdstip

Daarna worden de brongegevens opgeslagen in dezelfde neutrale tabellen. De UI en prijsengine hoeven daardoor niet per winkel aangepast te worden.

Voor productie moeten per winkel de juridische en technische voorwaarden van de gekozen bron/API worden gecontroleerd. Scraping hoort niet stilzwijgend als permanente databron te worden gebruikt als de websitevoorwaarden dit niet toestaan.
