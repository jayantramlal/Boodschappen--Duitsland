# Architectuur

## Doel
De app vergelijkt prijzen uit Nederland en Duitsland in één gezamenlijke prijsengine. Land is metadata, geen scheiding in de berekening.

## Lagen
- `domain/`: neutrale modellen en `PriceEngine`; geen Android/winkel-specifieke logica.
- `data/`: SQLite-opslag, repository en contracten voor toekomstige live prijsbronnen.
- `ui/`: Jetpack Compose schermen + ViewModel.
- `PriceSource`: uitbreidingspunt voor AH, Jumbo, dm, Rossmann, Kaufland enz.

## Prijsregels
1. Geldige aanbieding gaat vóór normale prijs.
2. Uitgelopen aanbieding wordt automatisch genegeerd.
3. Alleen geactiveerde winkels doen mee.
4. NL/DE-filter is optioneel; standaard `Alles` vergelijkt beide landen samen.
5. Prijs per eenheid wordt genormaliseerd naar liter, kg of stuk waar mogelijk.
6. De boodschappenlijst kan kiezen tussen absolute minimumprijs en één-winkelstrategie.

## Data-integriteit
- SQLite foreign keys staan aan.
- `(product_id, store_id)` is uniek in actuele prijzen.
- Iedere handmatige prijswijziging schrijft een geschiedenisrecord.
- Android cloud backup staat uit om onverwachte herstel/mixproblemen te vermijden.
