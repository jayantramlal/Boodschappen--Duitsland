plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.plugin.compose")
}

fun readSigningEnv(file: File): Map<String, String> {
    if (!file.isFile) return emptyMap()
    return file.readLines()
        .map { it.trim() }
        .filter { it.isNotEmpty() && !it.startsWith("#") && it.contains("=") }
        .associate { line ->
            val index = line.indexOf('=')
            val key = line.substring(0, index).trim()
            val value = line.substring(index + 1).trim()
            key to value
        }
}

val releaseSigning = readSigningEnv(file("signing.env"))
val releaseKeystore = file("release.jks")
val hasReleaseSigning = releaseKeystore.isFile &&
    releaseSigning["RELEASE_STORE_PASSWORD"].orEmpty().isNotEmpty() &&
    releaseSigning["RELEASE_KEY_ALIAS"].orEmpty().isNotEmpty() &&
    releaseSigning["RELEASE_KEY_PASSWORD"].orEmpty().isNotEmpty()

android {
    namespace = "nl.jays.boodschappenduitsland"
    compileSdk = 37

    defaultConfig {
        applicationId = "nl.jays.boodschappenduitsland"
        minSdk = 23
        targetSdk = 36
        versionCode = 10001
        versionName = "1.0.1"

        testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
    }

    signingConfigs {
        create("sharedDebug") {
            storeFile = file("debug.jks")
            storePassword = "android"
            keyAlias = "androiddebugkey"
            keyPassword = "android"
        }

        if (hasReleaseSigning) {
            create("releaseCi") {
                storeFile = releaseKeystore
                storePassword = releaseSigning.getValue("RELEASE_STORE_PASSWORD")
                keyAlias = releaseSigning.getValue("RELEASE_KEY_ALIAS")
                keyPassword = releaseSigning.getValue("RELEASE_KEY_PASSWORD")
            }
        }
    }

    buildTypes {
        debug {
            signingConfig = signingConfigs.getByName("sharedDebug")
            applicationIdSuffix = ".dev"
            versionNameSuffix = "-dev"
        }
        release {
            isDebuggable = false
            signingConfig = signingConfigs.findByName("releaseCi")
            isMinifyEnabled = true
            isShrinkResources = true
            proguardFiles(
                getDefaultProguardFile("proguard-android-optimize.txt"),
                "proguard-rules.pro"
            )
        }
    }

    buildFeatures {
        compose = true
        buildConfig = true
    }

    packaging {
        resources.excludes += setOf("/META-INF/{AL2.0,LGPL2.1}")
    }
}

dependencies {
    val composeBom = platform("androidx.compose:compose-bom:2026.08.00")
    implementation(composeBom)
    androidTestImplementation(composeBom)

    implementation("androidx.activity:activity-compose:1.13.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-compose:2.11.0")
    implementation("androidx.lifecycle:lifecycle-viewmodel-ktx:2.11.0")
    implementation("androidx.compose.ui:ui")
    implementation("androidx.compose.ui:ui-tooling-preview")
    implementation("androidx.compose.foundation:foundation")
    implementation("androidx.compose.material3:material3")
    implementation("androidx.compose.material:material-icons-extended")
    implementation("com.google.android.gms:play-services-code-scanner:16.1.0")

    debugImplementation("androidx.compose.ui:ui-tooling")
    debugImplementation("androidx.compose.ui:ui-test-manifest")

    testImplementation("junit:junit:4.13.2")
}
