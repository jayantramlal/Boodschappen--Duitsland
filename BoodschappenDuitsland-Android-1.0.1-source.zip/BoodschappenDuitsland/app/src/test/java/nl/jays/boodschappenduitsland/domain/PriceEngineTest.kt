package nl.jays.boodschappenduitsland.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertTrue
import org.junit.Test

class PriceEngineTest {
    private val product = Product(1, "123", "Shampoo", "Merk", 250.0, "ml", "Verzorging")
    private val nl = Store(1, "Jumbo", Country.NL, true)
    private val de = Store(2, "dm", Country.DE, true)

    @Test
    fun `active offer wins over regular price`() {
        val now = 1_000_000L
        val entry = PriceEntry(1, 1, 1, 299, 199, now + 1000, now)
        val result = PriceEngine.effectivePrice(entry, now)
        assertEquals(199, result.first)
        assertTrue(result.second)
    }

    @Test
    fun `offer higher than regular price is never selected`() {
        val now = 1_000_000L
        val entry = PriceEntry(1, 1, 1, 199, 249, now + 1000, now)
        val result = PriceEngine.effectivePrice(entry, now)
        assertEquals(199, result.first)
        assertFalse(result.second)
    }

    @Test
    fun `expired offer is ignored`() {
        val now = 1_000_000L
        val entry = PriceEntry(1, 1, 1, 299, 199, now - 1, now)
        val result = PriceEngine.effectivePrice(entry, now)
        assertEquals(299, result.first)
        assertFalse(result.second)
    }

    @Test
    fun `cheapest store ignores country boundary`() {
        val prices = listOf(
            PriceEntry(1, 1, 1, 189, null, null, 0),
            PriceEntry(2, 1, 2, 249, null, null, 0)
        )
        val best = PriceEngine.bestPrice(product, prices, listOf(nl, de), CountryFilter.ALL, 0)
        assertEquals("Jumbo", best?.store?.name)
        assertEquals(189, best?.effectivePriceCents)
    }

    @Test
    fun `country filter can be applied explicitly`() {
        val prices = listOf(
            PriceEntry(1, 1, 1, 189, null, null, 0),
            PriceEntry(2, 1, 2, 149, null, null, 0)
        )
        val bestNl = PriceEngine.bestPrice(product, prices, listOf(nl, de), CountryFilter.NL, 0)
        assertEquals("Jumbo", bestNl?.store?.name)
    }

    @Test
    fun `unit price normalizes milliliters to liter`() {
        val entry = PriceEntry(1, 1, 1, 250, null, null, 0)
        val price = PriceEngine.priceForProduct(product, entry, nl, 0)
        assertEquals(1000, price.unitPriceCents)
        assertEquals("per liter", price.unitLabel)
    }

    @Test
    fun `disabled store never wins`() {
        val disabledCheap = de.copy(enabled = false)
        val prices = listOf(
            PriceEntry(1, 1, 1, 189, null, null, 0),
            PriceEntry(2, 1, 2, 99, null, null, 0)
        )
        val best = PriceEngine.bestPrice(product, prices, listOf(nl, disabledCheap), CountryFilter.ALL, 0)
        assertEquals("Jumbo", best?.store?.name)
    }
}
