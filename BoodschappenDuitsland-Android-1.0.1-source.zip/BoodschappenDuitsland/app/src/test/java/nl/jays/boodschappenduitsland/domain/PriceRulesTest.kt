package nl.jays.boodschappenduitsland.domain

import org.junit.Assert.assertEquals
import org.junit.Assert.assertFalse
import org.junit.Assert.assertNull
import org.junit.Assert.assertTrue
import org.junit.Test

class PriceRulesTest {
    @Test
    fun `valid offer must be positive and lower than regular price`() {
        assertTrue(PriceRules.isValidOffer(400, 350))
        assertFalse(PriceRules.isValidOffer(400, 400))
        assertFalse(PriceRules.isValidOffer(400, 500))
        assertFalse(PriceRules.isValidOffer(400, -1))
        assertFalse(PriceRules.isValidOffer(400, 0))
    }

    @Test
    fun `euro parser handles comma and dot`() {
        assertEquals(1234, PriceRules.parseEuroToCents("12,34"))
        assertEquals(1234, PriceRules.parseEuroToCents("€ 12.34"))
    }

    @Test
    fun `euro parser rejects negative and overflowing values`() {
        assertNull(PriceRules.parseEuroToCents("-1,00"))
        assertNull(PriceRules.parseEuroToCents("999999999999,99"))
        assertNull(PriceRules.parseEuroToCents("100000,00"))
    }
}
