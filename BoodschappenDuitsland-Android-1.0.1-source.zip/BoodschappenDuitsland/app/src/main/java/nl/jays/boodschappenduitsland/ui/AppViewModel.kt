package nl.jays.boodschappenduitsland.ui

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import nl.jays.boodschappenduitsland.data.AppRepository
import nl.jays.boodschappenduitsland.domain.*


data class UiState(
    val loading: Boolean = true,
    val stores: List<Store> = emptyList(),
    val products: List<Product> = emptyList(),
    val prices: List<PriceEntry> = emptyList(),
    val shoppingList: List<ShoppingListItem> = emptyList(),
    val history: List<PriceHistoryPoint> = emptyList(),
    val darkMode: Boolean = false,
    val countryFilter: CountryFilter = CountryFilter.ALL,
    val strategy: ShoppingStrategy = ShoppingStrategy.MAX_SAVINGS,
    val selectedProductId: Long? = null,
    val scannedEan: String? = null,
    val message: String? = null
)

class AppViewModel(application: Application) : AndroidViewModel(application) {
    private val repo = AppRepository(application.applicationContext)
    private val prefs = application.getSharedPreferences("settings", 0)
    private val _state = MutableStateFlow(
        UiState(darkMode = prefs.getBoolean("dark_mode", false))
    )
    val state: StateFlow<UiState> = _state.asStateFlow()

    init { refresh() }

    fun refresh() {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { repo.loadSnapshot() }
                .onSuccess { snapshot -> applySnapshot(snapshot, message = null) }
                .onFailure { error ->
                    _state.value = _state.value.copy(
                        loading = false,
                        message = error.message ?: "Onbekende fout"
                    )
                }
        }
    }

    fun setDarkMode(enabled: Boolean) {
        prefs.edit().putBoolean("dark_mode", enabled).apply()
        _state.value = _state.value.copy(darkMode = enabled)
    }

    fun setCountryFilter(filter: CountryFilter) {
        _state.value = _state.value.copy(countryFilter = filter)
    }

    fun setStrategy(strategy: ShoppingStrategy) {
        _state.value = _state.value.copy(strategy = strategy)
    }

    fun selectProduct(productId: Long) {
        _state.value = _state.value.copy(selectedProductId = productId, scannedEan = null)
    }

    fun onBarcodeScanned(ean: String) {
        _state.value = _state.value.copy(loading = true, scannedEan = ean)
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val product = repo.ensureProductForBarcode(ean)
                product to repo.loadSnapshot()
            }.onSuccess { (product, snapshot) ->
                _state.value = _state.value.copy(
                    loading = false,
                    stores = snapshot.stores,
                    products = snapshot.products,
                    prices = snapshot.prices,
                    shoppingList = snapshot.shoppingList,
                    history = snapshot.history,
                    selectedProductId = product.id,
                    scannedEan = ean,
                    message = if (product.name == "Onbekend product") {
                        "Barcode herkend. Vul product- en prijsgegevens aan."
                    } else null
                )
            }.onFailure { error ->
                _state.value = _state.value.copy(
                    loading = false,
                    message = error.message ?: "Barcode verwerken mislukt"
                )
            }
        }
    }

    fun addToList(productId: Long, quantity: Int = 1) = mutate { repo.addToList(productId, quantity) }
    fun setListQuantity(productId: Long, quantity: Int) = mutate { repo.setListQuantity(productId, quantity) }
    fun setListChecked(productId: Long, checked: Boolean) = mutate { repo.setListChecked(productId, checked) }
    fun clearChecked() = mutate { repo.clearChecked() }
    fun setStoreEnabled(storeId: Long, enabled: Boolean) = mutate { repo.setStoreEnabled(storeId, enabled) }

    fun addStore(name: String, country: Country) {
        if (name.isBlank()) return
        mutate { repo.addStore(name, country) }
    }

    fun addProduct(name: String, brand: String, ean: String?, size: String, unit: String, category: String) {
        val sizeValue = size.replace(',', '.').toDoubleOrNull() ?: 1.0
        if (name.isBlank()) return
        mutate {
            repo.addProduct(
                name,
                brand,
                ean,
                sizeValue,
                unit.ifBlank { "st" },
                category.ifBlank { "Overig" }
            )
        }
    }

    fun updateProduct(product: Product) = mutate { repo.updateProduct(product) }

    fun upsertPrice(productId: Long, storeId: Long, regular: String, offer: String, offerDays: String) {
        val regularCents = PriceRules.parseEuroToCents(regular)
        if (regularCents == null) {
            showMessage("Voer een geldige normale prijs in van € 0,01 t/m € 99.999,99.")
            return
        }

        val offerCents = if (offer.isBlank()) {
            null
        } else {
            PriceRules.parseEuroToCents(offer) ?: run {
                showMessage("De aanbiedingsprijs is ongeldig of te hoog.")
                return
            }
        }

        if (offerCents != null && !PriceRules.isValidOffer(regularCents, offerCents)) {
            showMessage("Een aanbieding moet hoger dan € 0,00 en lager dan de normale prijs zijn.")
            return
        }

        val days = if (offerCents == null) {
            null
        } else if (offerDays.isBlank()) {
            7
        } else {
            offerDays.toIntOrNull()?.takeIf { it in 1..PriceRules.MAX_OFFER_DAYS } ?: run {
                showMessage("Geldigheidsduur moet tussen 1 en ${PriceRules.MAX_OFFER_DAYS} dagen liggen.")
                return
            }
        }

        mutate { repo.upsertPrice(productId, storeId, regularCents, offerCents, days) }
    }

    fun exportBackup(uri: Uri) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching { repo.exportBackup(uri) }
                .onSuccess { showMessage("Back-up succesvol opgeslagen.") }
                .onFailure { error -> showMessage(error.message ?: "Back-up maken mislukt.") }
        }
    }

    fun importBackup(uri: Uri) {
        _state.value = _state.value.copy(loading = true)
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                val result = repo.importBackup(uri)
                result to repo.loadSnapshot()
            }.onSuccess { (result, snapshot) ->
                _state.value = _state.value.copy(
                    loading = false,
                    stores = snapshot.stores,
                    products = snapshot.products,
                    prices = snapshot.prices,
                    shoppingList = snapshot.shoppingList,
                    history = snapshot.history,
                    darkMode = result.darkMode,
                    selectedProductId = null,
                    scannedEan = null,
                    message = "Back-up succesvol teruggezet."
                )
            }.onFailure { error ->
                _state.value = _state.value.copy(
                    loading = false,
                    message = error.message ?: "Back-up terugzetten mislukt."
                )
            }
        }
    }

    fun resetDemoData() = mutate { repo.resetDemoData() }

    fun consumeMessage() {
        _state.value = _state.value.copy(message = null)
    }

    private fun mutate(block: () -> Unit) {
        viewModelScope.launch(Dispatchers.IO) {
            runCatching {
                block()
                repo.loadSnapshot()
            }.onSuccess { snapshot ->
                applySnapshot(snapshot, message = null)
            }.onFailure { error ->
                _state.value = _state.value.copy(
                    loading = false,
                    message = error.message ?: "Opslaan mislukt"
                )
            }
        }
    }

    private fun applySnapshot(snapshot: AppSnapshot, message: String?) {
        _state.value = _state.value.copy(
            loading = false,
            stores = snapshot.stores,
            products = snapshot.products,
            prices = snapshot.prices,
            shoppingList = snapshot.shoppingList,
            history = snapshot.history,
            message = message
        )
    }

    private fun showMessage(message: String) {
        _state.value = _state.value.copy(message = message)
    }
}
