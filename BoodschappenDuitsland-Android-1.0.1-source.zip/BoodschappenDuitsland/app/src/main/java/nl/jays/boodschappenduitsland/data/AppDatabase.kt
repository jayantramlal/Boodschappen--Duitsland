package nl.jays.boodschappenduitsland.data

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper
import nl.jays.boodschappenduitsland.domain.*
import java.util.Calendar

class AppDatabase(context: Context) : SQLiteOpenHelper(context, DB_NAME, null, DB_VERSION) {
    override fun onCreate(db: SQLiteDatabase) {
        db.execSQL("""
            CREATE TABLE stores(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                name TEXT NOT NULL,
                country TEXT NOT NULL,
                enabled INTEGER NOT NULL DEFAULT 1
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE products(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                ean TEXT UNIQUE,
                name TEXT NOT NULL,
                brand TEXT NOT NULL DEFAULT '',
                size_value REAL NOT NULL DEFAULT 0,
                size_unit TEXT NOT NULL DEFAULT '',
                category TEXT NOT NULL DEFAULT ''
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE prices(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                store_id INTEGER NOT NULL,
                regular_price_cents INTEGER NOT NULL,
                offer_price_cents INTEGER,
                offer_until_millis INTEGER,
                updated_at_millis INTEGER NOT NULL,
                source TEXT NOT NULL DEFAULT 'MANUAL',
                UNIQUE(product_id, store_id),
                FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,
                FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE shopping_list(
                product_id INTEGER PRIMARY KEY,
                quantity INTEGER NOT NULL DEFAULT 1,
                checked INTEGER NOT NULL DEFAULT 0,
                FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE
            )
        """.trimIndent())
        db.execSQL("""
            CREATE TABLE price_history(
                id INTEGER PRIMARY KEY AUTOINCREMENT,
                product_id INTEGER NOT NULL,
                store_id INTEGER NOT NULL,
                price_cents INTEGER NOT NULL,
                captured_at_millis INTEGER NOT NULL,
                FOREIGN KEY(product_id) REFERENCES products(id) ON DELETE CASCADE,
                FOREIGN KEY(store_id) REFERENCES stores(id) ON DELETE CASCADE
            )
        """.trimIndent())
        db.execSQL("CREATE INDEX idx_prices_product ON prices(product_id)")
        db.execSQL("CREATE INDEX idx_history_product ON price_history(product_id)")
        db.execSQL("CREATE INDEX idx_history_product_store_time ON price_history(product_id, store_id, captured_at_millis)")
        seed(db)
    }

    override fun onConfigure(db: SQLiteDatabase) {
        super.onConfigure(db)
        db.setForeignKeyConstraintsEnabled(true)
    }

    override fun onUpgrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        var version = oldVersion

        if (version == 1) {
            migrate1To2(db)
            version = 2
        }

        if (version != newVersion) {
            throw IllegalStateException(
                "Geen veilige database-migratie beschikbaar van versie $version naar $newVersion"
            )
        }
    }

    override fun onDowngrade(db: SQLiteDatabase, oldVersion: Int, newVersion: Int) {
        throw IllegalStateException(
            "Database-downgrade van versie $oldVersion naar $newVersion wordt niet ondersteund"
        )
    }

    private fun migrate1To2(db: SQLiteDatabase) {
        // Verwijder historiepunten die door de v1-bug uit een aantoonbaar ongeldige
        // aanbieding zijn ontstaan, voordat de aanbieding zelf wordt opgeschoond.
        db.execSQL(
            """
            DELETE FROM price_history
            WHERE id IN (
                SELECT h.id
                FROM price_history h
                JOIN prices p
                  ON p.product_id = h.product_id
                 AND p.store_id = h.store_id
                WHERE p.offer_price_cents IS NOT NULL
                  AND (p.offer_price_cents <= 0 OR p.offer_price_cents >= p.regular_price_cents)
                  AND h.price_cents = p.offer_price_cents
            )
            """.trimIndent()
        )

        db.execSQL(
            "UPDATE prices SET offer_price_cents=NULL, offer_until_millis=NULL " +
                "WHERE offer_price_cents IS NOT NULL " +
                "AND (offer_price_cents <= 0 OR offer_price_cents >= regular_price_cents)"
        )

        // Oude extreme/corrupte waarden uit v1 mogen niet blijven doorlekken.
        db.execSQL(
            "DELETE FROM price_history WHERE price_cents <= 0 OR price_cents > ${PriceRules.MAX_PRICE_CENTS}"
        )
        db.execSQL(
            "DELETE FROM prices WHERE regular_price_cents <= 0 OR regular_price_cents > ${PriceRules.MAX_PRICE_CENTS}"
        )

        db.execSQL(
            "ALTER TABLE prices ADD COLUMN source TEXT NOT NULL DEFAULT 'MANUAL'"
        )
        db.execSQL(
            "CREATE INDEX IF NOT EXISTS idx_history_product_store_time " +
                "ON price_history(product_id, store_id, captured_at_millis)"
        )
    }

    private fun seed(db: SQLiteDatabase) {
        db.beginTransaction()
        try {
            val jumbo = insertStore(db, "Jumbo", Country.NL)
            val ah = insertStore(db, "Albert Heijn", Country.NL)
            val kruidvat = insertStore(db, "Kruidvat", Country.NL)
            val lidlNl = insertStore(db, "Lidl NL", Country.NL)
            val dm = insertStore(db, "dm", Country.DE)
            val rossmann = insertStore(db, "Rossmann", Country.DE)
            val kaufland = insertStore(db, "Kaufland", Country.DE)
            val edeka = insertStore(db, "Edeka", Country.DE)

            val shampoo = insertProduct(db, "8006540703181", "Shampoo", "Head & Shoulders Classic Clean", 250.0, "ml", "Persoonlijke verzorging")
            val detergent = insertProduct(db, null, "Wasmiddel", "Persil Color", 20.0, "st", "Huishouden")
            val coffee = insertProduct(db, null, "Koffie", "Douwe Egberts Roodmerk", 500.0, "g", "Koffie & thee")
            val bags = insertProduct(db, null, "Vuilniszakken", "Profissimo", 20.0, "st", "Huishouden")
            val toothpaste = insertProduct(db, null, "Tandpasta", "Colgate Total", 75.0, "ml", "Persoonlijke verzorging")
            val showerGel = insertProduct(db, null, "Douchegel", "Nivea Men Sport", 250.0, "ml", "Persoonlijke verzorging")
            val soap = insertProduct(db, null, "Handzeep", "Dove", 250.0, "ml", "Persoonlijke verzorging")
            val cola = insertProduct(db, null, "Cola", "Coca-Cola", 1.5, "l", "Dranken")

            val offerUntil = Calendar.getInstance().apply { add(Calendar.DAY_OF_YEAR, 7) }.timeInMillis
            val now = System.currentTimeMillis()

            insertPrice(db, shampoo, jumbo, 249, 189, offerUntil, now)
            insertPrice(db, shampoo, ah, 269, 239, offerUntil, now)
            insertPrice(db, shampoo, dm, 249, null, null, now)
            insertPrice(db, shampoo, rossmann, 279, null, null, now)
            insertPrice(db, shampoo, kaufland, 299, 259, offerUntil, now)
            insertPrice(db, shampoo, edeka, 329, null, null, now)

            insertPrice(db, detergent, jumbo, 599, null, null, now)
            insertPrice(db, detergent, ah, 649, 549, offerUntil, now)
            insertPrice(db, detergent, dm, 445, null, null, now)
            insertPrice(db, detergent, kaufland, 495, null, null, now)
            insertPrice(db, detergent, edeka, 529, null, null, now)

            insertPrice(db, coffee, jumbo, 549, 499, offerUntil, now)
            insertPrice(db, coffee, ah, 579, null, null, now)
            insertPrice(db, coffee, kaufland, 549, null, null, now)
            insertPrice(db, coffee, edeka, 569, null, null, now)

            insertPrice(db, bags, kruidvat, 399, null, null, now)
            insertPrice(db, bags, dm, 249, null, null, now)
            insertPrice(db, bags, rossmann, 299, 269, offerUntil, now)
            insertPrice(db, bags, kaufland, 279, null, null, now)

            insertPrice(db, toothpaste, jumbo, 299, null, null, now)
            insertPrice(db, toothpaste, kruidvat, 249, null, null, now)
            insertPrice(db, toothpaste, dm, 219, null, null, now)
            insertPrice(db, toothpaste, kaufland, 199, null, null, now)

            insertPrice(db, showerGel, jumbo, 349, null, null, now)
            insertPrice(db, showerGel, kruidvat, 329, null, null, now)
            insertPrice(db, showerGel, dm, 299, null, null, now)
            insertPrice(db, showerGel, rossmann, 309, null, null, now)

            insertPrice(db, soap, jumbo, 279, null, null, now)
            insertPrice(db, soap, ah, 289, null, null, now)
            insertPrice(db, soap, dm, 189, null, null, now)
            insertPrice(db, soap, rossmann, 199, null, null, now)

            insertPrice(db, cola, jumbo, 269, 229, offerUntil, now)
            insertPrice(db, cola, ah, 279, null, null, now)
            insertPrice(db, cola, lidlNl, 239, null, null, now)
            insertPrice(db, cola, kaufland, 199, null, null, now)
            insertPrice(db, cola, edeka, 219, null, null, now)

            addToList(db, shampoo, 1)
            addToList(db, detergent, 1)
            addToList(db, coffee, 1)
            addToList(db, bags, 2)
            addToList(db, toothpaste, 2)
            addToList(db, showerGel, 1)

            seedHistory(db, shampoo, jumbo, listOf(309, 279, 249, 229, 189), now)
            seedHistory(db, shampoo, dm, listOf(279, 269, 259, 249, 249), now)
            seedHistory(db, detergent, dm, listOf(499, 479, 459, 445), now)
            seedHistory(db, coffee, jumbo, listOf(599, 579, 549, 499), now)
            db.setTransactionSuccessful()
        } finally {
            db.endTransaction()
        }
    }

    private fun insertStore(db: SQLiteDatabase, name: String, country: Country): Long {
        return db.insertOrThrow("stores", null, ContentValues().apply {
            put("name", name)
            put("country", country.name)
            put("enabled", 1)
        })
    }

    private fun insertProduct(db: SQLiteDatabase, ean: String?, name: String, brand: String, size: Double, unit: String, category: String): Long {
        return db.insertOrThrow("products", null, ContentValues().apply {
            if (ean == null) putNull("ean") else put("ean", ean)
            put("name", name)
            put("brand", brand)
            put("size_value", size)
            put("size_unit", unit)
            put("category", category)
        })
    }

    private fun insertPrice(db: SQLiteDatabase, product: Long, store: Long, regular: Int, offer: Int?, offerUntil: Long?, now: Long) {
        db.insertOrThrow("prices", null, ContentValues().apply {
            put("product_id", product)
            put("store_id", store)
            put("regular_price_cents", regular)
            if (offer == null) putNull("offer_price_cents") else put("offer_price_cents", offer)
            if (offerUntil == null) putNull("offer_until_millis") else put("offer_until_millis", offerUntil)
            put("updated_at_millis", now)
        })
    }

    private fun addToList(db: SQLiteDatabase, product: Long, qty: Int) {
        db.insertOrThrow("shopping_list", null, ContentValues().apply {
            put("product_id", product)
            put("quantity", qty)
            put("checked", 0)
        })
    }

    private fun seedHistory(db: SQLiteDatabase, product: Long, store: Long, values: List<Int>, now: Long) {
        values.forEachIndexed { index, cents ->
            val ageDays = (values.size - 1 - index) * 30L
            db.insertOrThrow("price_history", null, ContentValues().apply {
                put("product_id", product)
                put("store_id", store)
                put("price_cents", cents)
                put("captured_at_millis", now - ageDays * 24L * 60L * 60L * 1000L)
            })
        }
    }

    companion object {
        const val DB_NAME = "boodschappen_duitsland.db"
        const val DB_VERSION = 2
    }
}
