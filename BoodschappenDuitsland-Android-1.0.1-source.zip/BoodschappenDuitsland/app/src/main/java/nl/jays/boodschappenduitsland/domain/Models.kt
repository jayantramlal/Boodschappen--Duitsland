package nl.jays.boodschappenduitsland.domain

enum class Country(val flag: String, val label: String) {
    NL("🇳🇱", "Nederland"),
    DE("🇩🇪", "Duitsland")
}

enum class CountryFilter { ALL, NL, DE }

enum class ShoppingStrategy { MAX_SAVINGS, ONE_STORE }

data class Store(
    val id: Long,
    val name: String,
    val country: Country,
    val enabled: Boolean = true
)

data class Product(
    val id: Long,
    val ean: String?,
    val name: String,
    val brand: String,
    val sizeValue: Double,
    val sizeUnit: String,
    val category: String
) {
    val displaySize: String
        get() = if (sizeValue % 1.0 == 0.0) "${sizeValue.toInt()} $sizeUnit" else "$sizeValue $sizeUnit"
}

data class PriceEntry(
    val id: Long,
    val productId: Long,
    val storeId: Long,
    val regularPriceCents: Int,
    val offerPriceCents: Int?,
    val offerUntilMillis: Long?,
    val updatedAtMillis: Long
)

data class ShoppingListItem(
    val productId: Long,
    val quantity: Int,
    val checked: Boolean
)

data class PriceHistoryPoint(
    val productId: Long,
    val storeId: Long,
    val priceCents: Int,
    val capturedAtMillis: Long
)

data class AppSnapshot(
    val stores: List<Store>,
    val products: List<Product>,
    val prices: List<PriceEntry>,
    val shoppingList: List<ShoppingListItem>,
    val history: List<PriceHistoryPoint>
)

data class ProductPrice(
    val product: Product,
    val store: Store,
    val entry: PriceEntry,
    val effectivePriceCents: Int,
    val isOffer: Boolean,
    val unitPriceCents: Int?,
    val unitLabel: String?
)

data class StorePlan(
    val store: Store,
    val totalCents: Long,
    val coveredItems: Int,
    val totalItems: Int
)
