package nl.jays.boodschappenduitsland.domain

import java.math.RoundingMode

object PriceRules {
    /** Hard safety limit for a single grocery price: € 99.999,99. */
    const val MAX_PRICE_CENTS = 9_999_999
    const val MAX_QUANTITY = 99
    const val MAX_OFFER_DAYS = 365

    fun isValidRegularPrice(cents: Int): Boolean = cents in 1..MAX_PRICE_CENTS

    fun validOfferCents(regularCents: Int, offerCents: Int?): Int? {
        if (offerCents == null) return null
        return offerCents.takeIf {
            it in 1..MAX_PRICE_CENTS && it < regularCents
        }
    }

    fun isValidOffer(regularCents: Int, offerCents: Int): Boolean =
        validOfferCents(regularCents, offerCents) != null

    fun normalizeOfferDays(days: Int?): Int =
        (days ?: 7).coerceIn(1, MAX_OFFER_DAYS)

    fun parseEuroToCents(value: String): Int? {
        if (value.isBlank()) return null

        val normalized = value
            .trim()
            .replace("€", "")
            .replace(" ", "")
            .replace(',', '.')

        val decimal = normalized.toBigDecimalOrNull() ?: return null
        if (decimal.signum() <= 0) return null

        val cents = runCatching {
            decimal
                .movePointRight(2)
                .setScale(0, RoundingMode.HALF_UP)
                .longValueExact()
        }.getOrNull() ?: return null

        if (cents !in 1L..MAX_PRICE_CENTS.toLong()) return null
        return cents.toInt()
    }
}
