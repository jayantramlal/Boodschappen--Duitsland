package nl.jays.boodschappenduitsland.data

import nl.jays.boodschappenduitsland.domain.Country

/**
 * Contract for future live supermarket/drugstore integrations.
 * Each provider must map its source data into this neutral model so the comparison engine
 * never contains store-specific scraping/API logic.
 */
interface PriceSource {
    val sourceId: String
    val country: Country
    suspend fun lookupByEan(ean: String): List<RemotePrice>
}

data class RemotePrice(
    val ean: String,
    val storeName: String,
    val regularPriceCents: Int,
    val offerPriceCents: Int? = null,
    val offerUntilMillis: Long? = null,
    val sourceTimestampMillis: Long = System.currentTimeMillis()
)
