package nl.jays.boodschappenduitsland.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val Green = Color(0xFF168A3A)
private val GreenDark = Color(0xFF0D6E2B)
private val Mint = Color(0xFFE7F6EA)
private val Ink = Color(0xFF10231A)
private val Warm = Color(0xFFFFFBF5)

private val LightColors = lightColorScheme(
    primary = Green,
    onPrimary = Color.White,
    primaryContainer = Mint,
    onPrimaryContainer = Ink,
    secondary = Color(0xFF3E6B50),
    background = Warm,
    surface = Color.White,
    onSurface = Ink,
    outline = Color(0xFF718078)
)

private val DarkColors = darkColorScheme(
    primary = Color(0xFF5ED47D),
    onPrimary = Color(0xFF003914),
    primaryContainer = GreenDark,
    onPrimaryContainer = Color(0xFFD8F8DF),
    secondary = Color(0xFFA5D5B2),
    background = Color(0xFF0B1410),
    surface = Color(0xFF111D17),
    onSurface = Color(0xFFE5F0E8),
    outline = Color(0xFF8A9B90)
)

@Composable
fun BoodschappenTheme(darkMode: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkMode) DarkColors else LightColors,
        content = content
    )
}
