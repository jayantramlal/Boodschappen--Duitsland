# Projectstatus 1.0.1

Deze versie is de herstelde Android-baseline na de strenge interne APK-keuring van 1.0.0-dev.

## Hersteld in 1.0.1
- Releasepad gebruikt package `nl.jays.boodschappenduitsland` zonder `.dev` suffix.
- Releasebuild is expliciet niet-debuggable en gebruikt een permanente release-key via GitHub Secrets.
- Scanner-callbacks zijn direct in de broncode typeveilig gemaakt; geen build-time patch meer nodig.
- Prijshistorie gebruikt exact dezelfde aanbieding-validatie als de actuele prijsengine.
- Negatieve, te hoge en ongeldige aanbiedingsprijzen worden geweigerd.
- Geldbedragen hebben een harde bovengrens; conversie naar centen kan niet meer via Int-overflow ontsporen.
- Lijsttotalen worden met `Long` berekend om overflow bij extreme totalen te voorkomen.
- Database is naar versie 2 gebracht met expliciete migratie 1 -> 2 en veilige stop bij onbekende migraties/downgrades.
- Eigen JSON back-up/export en import/herstel toegevoegd via Android Storage Access Framework.
- Android cloudback-up en device-transfer zijn beperkt tot de appdatabase en instellingen geactiveerd.
- Prijshistorie wordt per winkel getoond; lijnen van verschillende winkels worden niet meer door elkaar verbonden.
- Dubbele terugknop op het scanresultaatscherm verwijderd.
- Barcodeverwerking heeft foutafhandeling zodat databasefouten niet ongevangen uit de coroutine vallen.

## Nog steeds bewust niet als live gepresenteerd
Live supermarktprijzen. Daarvoor moet per winkel een toegestane en betrouwbare gegevensbron/API worden aangesloten. De `PriceSource`-laag blijft hiervoor voorbereid.

## Release-opmerking
Gebruik vanaf de eerste definitieve release altijd dezelfde release-keystore. Verlies van die sleutel betekent dat toekomstige APK's niet als update over bestaande release-installaties kunnen worden geplaatst.
