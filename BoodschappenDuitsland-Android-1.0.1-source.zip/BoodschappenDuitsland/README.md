# Boodschappen Duitsland — Android 1.0.1

Native Android-app in Kotlin + Jetpack Compose voor prijsvergelijking tussen Nederlandse en Duitse supermarkten/drogisterijen.

## Kernfuncties
- Nederland en Duitsland in één prijsvergelijking; de laagste geldige prijs wint.
- Optionele NL/DE-filters.
- Normale prijs + geldige aanbiedingsprijs + einddatum.
- Eenheidsprijs per liter/kg/stuk waar mogelijk.
- Boodschappenlijst met aantallen en afvinken.
- Strategie `Maximale besparing` of `Alles bij één winkel`.
- Barcode-scanner via Google Code Scanner.
- Onbekende barcode wordt lokaal aangemaakt en kan daarna worden ingevuld.
- Producten, winkels en prijzen handmatig beheren.
- Prijshistorie per winkel.
- Licht/donker thema.
- Lokale SQLite-opslag.
- Handmatige JSON back-up/export + herstel/import.
- Android cloudback-up en device-transfer voor database + instellingen.
- Unit tests voor prijs- en invoerregels.

## Dataveiligheid
Databaseversie 2 bevat een expliciete migratie vanaf versie 1. Onbekende toekomstige migratiepaden worden niet stilzwijgend uitgevoerd. Back-ups worden vóór import volledig gevalideerd en de databasevervanging gebeurt transactioneel.

## Prijsveiligheid
- Normale prijs: € 0,01 t/m € 99.999,99.
- Aanbieding moet positief én lager dan de normale prijs zijn.
- Prijshistorie gebruikt dezelfde aanbieding-validatie als de actuele prijsengine.
- Lijsttotalen gebruiken 64-bit berekeningen.

## Package en signing
Development: `nl.jays.boodschappenduitsland.dev`

Release: `nl.jays.boodschappenduitsland`

Development builds gebruiken alleen de meegeleverde debug-key. Definitieve releases moeten altijd met dezelfde privé release-keystore worden ondertekend. De release-key hoort nooit in Git te staan; gebruik GitHub Actions Secrets.

## Build stack
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- compileSdk 37 / targetSdk 36 / minSdk 23
- Jetpack Compose BOM 2026.08.00
- Google Code Scanner 16.1.0
