package nl.jays.boodschappenduitsland.domain

import kotlin.math.roundToInt

object PriceEngine {
    fun usable(entry: PriceEntry, nowMillis: Long = System.currentTimeMillis()): Boolean {
        if (entry.regularPriceCents <= 0) return false
        val maxAge = when {
            entry.source.startsWith("CATALOG:") -> 24L * 60 * 60 * 1000
            entry.source == "AH_LIVE_BONUS" -> 12L * 60 * 60 * 1000
            else -> return true // Handmatige prijzen zijn indicatief en blijven handmatig beheerd.
        }
        return entry.updatedAtMillis <= nowMillis && nowMillis - entry.updatedAtMillis <= maxAge
    }

    fun effectivePrice(entry: PriceEntry, nowMillis: Long = System.currentTimeMillis()): Pair<Int, Boolean> {
        val validOffer = PriceRules.validOfferCents(entry.regularPriceCents, entry.offerPriceCents)
        val activeOffer = validOffer != null &&
            entry.offerUntilMillis != null &&
            entry.offerUntilMillis >= nowMillis
        return if (activeOffer) validOffer!! to true else entry.regularPriceCents to false
    }

    fun priceForProduct(
        product: Product,
        entry: PriceEntry,
        store: Store,
        nowMillis: Long = System.currentTimeMillis()
    ): ProductPrice {
        val (effective, isOffer) = effectivePrice(entry, nowMillis)
        val unit = unitPrice(product, effective)
        return ProductPrice(
            product = product,
            store = store,
            entry = entry,
            effectivePriceCents = effective,
            isOffer = isOffer,
            unitPriceCents = unit.first,
            unitLabel = unit.second
        )
    }

    fun bestPrice(
        product: Product,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): ProductPrice? {
        val storesById = stores.associateBy { it.id }
        return prices.asSequence()
            .filter { it.productId == product.id && usable(it, nowMillis) }
            .mapNotNull { entry ->
                val store = storesById[entry.storeId] ?: return@mapNotNull null
                if (!store.enabled) return@mapNotNull null
                if (filter == CountryFilter.NL && store.country != Country.NL) return@mapNotNull null
                if (filter == CountryFilter.DE && store.country != Country.DE) return@mapNotNull null
                priceForProduct(product, entry, store, nowMillis)
            }
            .minByOrNull { it.effectivePriceCents }
    }

    fun rankedPrices(
        product: Product,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): List<ProductPrice> {
        val storesById = stores.associateBy { it.id }
        return prices.asSequence()
            .filter { it.productId == product.id && usable(it, nowMillis) }
            .mapNotNull { entry ->
                val store = storesById[entry.storeId] ?: return@mapNotNull null
                if (!store.enabled) return@mapNotNull null
                if (filter == CountryFilter.NL && store.country != Country.NL) return@mapNotNull null
                if (filter == CountryFilter.DE && store.country != Country.DE) return@mapNotNull null
                priceForProduct(product, entry, store, nowMillis)
            }
            .sortedBy { it.effectivePriceCents }
            .toList()
    }

    fun listTotal(
        items: List<ShoppingListItem>,
        products: List<Product>,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): Long {
        val productsById = products.associateBy { it.id }
        return items.sumOf { item ->
            val product = productsById[item.productId] ?: return@sumOf 0L
            val best = bestPrice(product, prices, stores, filter, nowMillis)
            (best?.effectivePriceCents ?: 0).toLong() * item.quantity.toLong()
        }
    }

    fun mostExpensiveComparableTotal(
        items: List<ShoppingListItem>,
        products: List<Product>,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): Long {
        val productsById = products.associateBy { it.id }
        val storesById = stores.associateBy { it.id }
        return items.sumOf { item ->
            val product = productsById[item.productId] ?: return@sumOf 0L
            val max = prices.asSequence()
                .filter { it.productId == product.id && usable(it, nowMillis) }
                .mapNotNull { entry ->
                    val store = storesById[entry.storeId] ?: return@mapNotNull null
                    if (!store.enabled) return@mapNotNull null
                    if (filter == CountryFilter.NL && store.country != Country.NL) return@mapNotNull null
                    if (filter == CountryFilter.DE && store.country != Country.DE) return@mapNotNull null
                    effectivePrice(entry, nowMillis).first
                }
                .maxOrNull() ?: 0
            max.toLong() * item.quantity.toLong()
        }
    }

    fun bestSingleStorePlan(
        items: List<ShoppingListItem>,
        products: List<Product>,
        prices: List<PriceEntry>,
        stores: List<Store>,
        filter: CountryFilter = CountryFilter.ALL,
        nowMillis: Long = System.currentTimeMillis()
    ): StorePlan? {
        if (items.isEmpty()) return null
        val knownProductIds = products.map { it.id }.toSet()
        val productIds = items.map { it.productId }.filter { it in knownProductIds }.toSet()
        if (productIds.isEmpty()) return null
        val qty = items.associate { it.productId to it.quantity }
        val allowedStores = stores.filter { store ->
            store.enabled && when (filter) {
                CountryFilter.ALL -> true
                CountryFilter.NL -> store.country == Country.NL
                CountryFilter.DE -> store.country == Country.DE
            }
        }
        val plans = allowedStores.map { store ->
            val byProduct = prices.filter { it.storeId == store.id && it.productId in productIds && usable(it, nowMillis) }.associateBy { it.productId }
            val covered = productIds.count { byProduct.containsKey(it) }
            val total = productIds.sumOf { pid ->
                val entry = byProduct[pid] ?: return@sumOf 0L
                effectivePrice(entry, nowMillis).first.toLong() * (qty[pid] ?: 1).toLong()
            }
            StorePlan(store, total, covered, productIds.size)
        }
        return plans.sortedWith(compareByDescending<StorePlan> { it.coveredItems }.thenBy { it.totalCents }).firstOrNull()
    }

    private fun unitPrice(product: Product, cents: Int): Pair<Int?, String?> {
        if (product.sizeValue <= 0.0) return null to null
        return when (product.sizeUnit.lowercase()) {
            "ml" -> ((cents / product.sizeValue) * 1000.0).roundToInt() to "per liter"
            "l", "liter" -> (cents / product.sizeValue).roundToInt() to "per liter"
            "g" -> ((cents / product.sizeValue) * 1000.0).roundToInt() to "per kg"
            "kg" -> (cents / product.sizeValue).roundToInt() to "per kg"
            "st", "stuks" -> (cents / product.sizeValue).roundToInt() to "per stuk"
            else -> null to null
        }
    }
}

fun Int.asEuro(): String {
    val sign = if (this < 0) "-" else ""
    val abs = kotlin.math.abs(this)
    return "$sign€ ${abs / 100},${(abs % 100).toString().padStart(2, '0')}"
}

fun Long.asEuro(): String {
    val sign = if (this < 0L) "-" else ""
    val abs = kotlin.math.abs(this)
    return "$sign€ ${abs / 100},${(abs % 100).toString().padStart(2, '0')}"
}
