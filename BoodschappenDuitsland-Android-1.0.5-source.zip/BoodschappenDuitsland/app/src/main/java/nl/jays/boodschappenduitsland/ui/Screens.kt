@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package nl.jays.boodschappenduitsland.ui

import android.widget.Toast
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import nl.jays.boodschappenduitsland.BuildConfig
import nl.jays.boodschappenduitsland.domain.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private enum class Screen { HOME, LIST, PRICES, OFFERS, STORES, SETTINGS, SCAN_RESULT, STORE_BASKET, STORE_CATALOG, COMPARE }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(viewModel: AppViewModel) {
    val state by viewModel.state.collectAsState()
    var screen by remember { mutableStateOf(Screen.HOME) }
    val backStack = remember { mutableStateListOf<Screen>() }
    val navigate: (Screen) -> Unit = { destination ->
        if (screen != destination) { backStack.add(screen); screen = destination }
    }
    val goBack: () -> Unit = {
        if (backStack.isNotEmpty()) screen = backStack.removeAt(backStack.lastIndex)
    }
    var selectedStoreId by remember { mutableStateOf<Long?>(null) }
    var addStoreRequested by remember { mutableStateOf(false) }
    BackHandler(enabled = screen != Screen.HOME) { goBack() }
    val context = LocalContext.current
    val launchScanner: () -> Unit = {
        runCatching {
            val options = GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_EAN_13,
                    Barcode.FORMAT_EAN_8,
                    Barcode.FORMAT_UPC_A,
                    Barcode.FORMAT_UPC_E,
                    Barcode.FORMAT_CODE_128
                )
                .build()

            GmsBarcodeScanning
                .getClient(context.applicationContext, options)
                .startScan()
                .addOnSuccessListener { barcode ->
                    val raw = barcode.rawValue
                    if (!raw.isNullOrBlank()) {
                        viewModel.onBarcodeScanned(raw)
                        navigate(Screen.SCAN_RESULT)
                    }
                }
                .addOnFailureListener { error ->
                    Toast.makeText(
                        context,
                        error.message ?: "Scannen mislukt",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }.onFailure { error ->
            Toast.makeText(
                context,
                error.message ?: "Scanner kan niet worden gestart",
                Toast.LENGTH_LONG
            ).show()
        }
        Unit
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let(viewModel::exportBackup)
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let(viewModel::importBackup)
    }

    val importCatalogLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let(viewModel::importSupermarketCatalog)
    }

    BoodschappenTheme(state.darkMode) {
        Scaffold(
            bottomBar = {
                if (screen != Screen.SCAN_RESULT) {
                    AppBottomBar(
                        current = screen,
                        onHome = { navigate(Screen.HOME) },
                        onList = { navigate(Screen.LIST) },
                        onScan = { launchScanner() },
                        onStores = { navigate(Screen.STORES) },
                        onSettings = { navigate(Screen.SETTINGS) }
                    )
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        state = state,
                        onFilter = viewModel::setCountryFilter,
                        onDarkMode = viewModel::setDarkMode,
                        onScan = { launchScanner() },
                        onList = { navigate(Screen.LIST) },
                        onPrices = { navigate(Screen.PRICES) },
                        onOffers = { navigate(Screen.OFFERS) },
                        onStores = { navigate(Screen.STORES) },
                        onStore = { selectedStoreId = it; navigate(Screen.STORE_CATALOG) },
                        onProduct = { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) }
                    )
                    Screen.LIST -> ShoppingListScreen(state, viewModel) { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) }
                    Screen.PRICES -> PricesScreen(state, viewModel) { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) }
                    Screen.OFFERS -> OffersScreen(state, viewModel)
                    Screen.STORES -> StoresScreen(state, viewModel,
                        onStore = { selectedStoreId = it; navigate(Screen.STORE_BASKET) },
                        onOffers = { navigate(Screen.OFFERS) },
                        addRequested = addStoreRequested,
                        onAddRequestConsumed = { addStoreRequested = false })
                    Screen.STORE_BASKET -> state.stores.firstOrNull { it.id == selectedStoreId }?.let { store ->
                        StoreBasketScreen(state, store, onBack = goBack,
                            onProduct = { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) })
                    }
                    Screen.STORE_CATALOG -> state.stores.firstOrNull { it.id == selectedStoreId }?.let { store ->
                        StoreCatalogScreen(state, store, onBack = goBack,
                            onProduct = { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) })
                    }
                    Screen.COMPARE -> CompareBasketScreen(state, onBack = goBack,
                        onStore = { selectedStoreId = it; navigate(Screen.STORE_BASKET) },
                        onProducts = { navigate(Screen.PRICES) })
                    Screen.SETTINGS -> SettingsScreen(
                        state = state,
                        viewModel = viewModel,
                        onStores = { navigate(Screen.STORES) },
                        onAddStore = { addStoreRequested = true; navigate(Screen.STORES) },
                        onCompare = { navigate(Screen.COMPARE) },
                        onExportBackup = {
                            exportBackupLauncher.launch("Boodschappen-Duitsland-backup.json")
                        },
                        onImportBackup = {
                            importBackupLauncher.launch(arrayOf("application/json", "text/plain"))
                        },
                        onImportCatalog = {
                            importCatalogLauncher.launch(arrayOf("application/json", "text/plain"))
                        }
                    )
                    Screen.SCAN_RESULT -> ScanResultScreen(
                        state = state,
                        viewModel = viewModel,
                        onBack = { goBack() },
                        onScanNext = { launchScanner() }
                    )
                }

                state.message?.let { message ->
                    Snackbar(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                        action = { TextButton(onClick = viewModel::consumeMessage) { Text("OK") } }
                    ) { Text(message) }
                }
            }
        }
    }
}

@Composable
private fun AppBottomBar(current: Screen, onHome: () -> Unit, onList: () -> Unit, onScan: () -> Unit, onStores: () -> Unit, onSettings: () -> Unit) {
    NavigationBar(containerColor = MaterialTheme.colorScheme.surface, tonalElevation = 0.dp) {
        NavigationBarItem(selected = current == Screen.HOME, onClick = onHome, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
        NavigationBarItem(selected = current == Screen.LIST, onClick = onList, icon = { Icon(Icons.Default.List, null) }, label = { Text("Lijst") })
        NavigationBarItem(selected = false, onClick = onScan, icon = { Icon(Icons.Default.QrCodeScanner, null) }, label = { Text("Scan") })
        NavigationBarItem(selected = current == Screen.STORES || current == Screen.STORE_CATALOG,
            onClick = onStores, icon = { Icon(Icons.Default.Storefront, null) }, label = { Text("Winkels") })
        NavigationBarItem(selected = current == Screen.SETTINGS || current == Screen.COMPARE,
            onClick = onSettings, icon = { Icon(Icons.Default.PersonOutline, null) }, label = { Text("Instellingen") })
    }
}

@Composable
private fun AppHeader(title: String, subtitle: String? = null, trailing: @Composable (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
            Icon(Icons.Default.ShoppingCart, null, modifier = Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 25.sp)
            subtitle?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
        }
        trailing?.invoke()
    }
}

@Composable
private fun HomeScreen(
    state: UiState,
    onFilter: (CountryFilter) -> Unit,
    onDarkMode: (Boolean) -> Unit,
    onScan: () -> Unit,
    onList: () -> Unit,
    onPrices: () -> Unit,
    onOffers: () -> Unit,
    onStores: () -> Unit,
    onStore: (Long) -> Unit,
    onProduct: (Long) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var searchStores by remember { mutableStateOf(false) }
    val products = state.products.filter {
        query.isBlank() || listOf(it.name, it.brand, it.category).any { field -> field.contains(query, ignoreCase = true) }
    }
    val stores = state.stores.filter {
        it.enabled && (query.isBlank() || it.name.contains(query, ignoreCase = true)) &&
            (state.countryFilter == CountryFilter.ALL ||
                state.countryFilter == CountryFilter.NL && it.country == Country.NL ||
                state.countryFilter == CountryFilter.DE && it.country == Country.DE)
    }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item { BrandHeader() }
        item {
            Row(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 14.dp)
                    .background(MaterialTheme.colorScheme.surface, RoundedCornerShape(16.dp)).padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                HomeMode("Producten", Icons.Default.QrCodeScanner, !searchStores, Modifier.weight(1f)) {
                    searchStores = false; query = ""
                }
                HomeMode("Winkels", Icons.Default.Storefront, searchStores, Modifier.weight(1f)) {
                    searchStores = true; query = ""
                }
            }
        }
        item {
            Column(Modifier.padding(start = 18.dp, end = 18.dp, top = 8.dp)) {
                Text(if (searchStores) "Zoek winkels" else "Zoek producten", fontSize = 27.sp, fontWeight = FontWeight.Bold)
                Text(
                    if (searchStores) "Bekijk het beschikbare assortiment per winkel" else "Vind producten en vergelijk geselecteerde winkels",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 15.sp
                )
                Spacer(Modifier.height(16.dp))
                OutlinedTextField(
                    value = query, onValueChange = { query = it }, modifier = Modifier.fillMaxWidth(),
                    placeholder = { Text(if (searchStores) "Zoek een winkel" else "Zoek een product") },
                    leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
                    trailingIcon = { if (query.isNotBlank()) IconButton(onClick = { query = "" }) { Icon(Icons.Default.Close, "Wis zoektekst") } },
                    shape = RoundedCornerShape(14.dp)
                )
            }
        }
        item { Spacer(Modifier.height(20.dp)); CountryFilterBar(state.countryFilter, onFilter) }
        item {
            Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 20.dp, bottom = 8.dp),
                verticalAlignment = Alignment.CenterVertically) {
                Text(if (searchStores) "Geselecteerde winkels" else "Producten", fontSize = 19.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                TextButton(onClick = if (searchStores) onStores else onPrices) {
                    Text("Alles bekijken", color = AccentBlue); Icon(Icons.Default.ChevronRight, null, tint = AccentBlue)
                }
            }
        }
        if (searchStores) {
            if (stores.isEmpty()) item { EmptySearchCard("Geen geselecteerde winkels gevonden.") }
            items(stores.take(8), key = { "store-${it.id}" }) { store ->
                HomeStoreCard(store) { onStore(store.id) }
            }
        } else {
            if (products.isEmpty()) item { EmptySearchCard("Nog geen producten beschikbaar. Importeer een winkelbestand of scan een product.") }
            items(products.take(8), key = { "product-${it.id}" }) { product ->
                val best = PriceEngine.bestPrice(product, state.prices, state.stores, state.countryFilter)
                HomeProductCard(product, best) { onProduct(product.id) }
            }
        }
        item {
            Button(
                onClick = onList, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp).height(54.dp),
                shape = RoundedCornerShape(13.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentYellow, contentColor = Color(0xFF101923))
            ) {
                Icon(Icons.Default.FormatListBulleted, null)
                Spacer(Modifier.width(12.dp))
                Text("Bekijk mijn lijst", fontWeight = FontWeight.Bold, fontSize = 16.sp, modifier = Modifier.weight(1f))
                Icon(Icons.Default.ChevronRight, null)
            }
        }
    }
}

@Composable
private fun BrandHeader() {
    Row(Modifier.fillMaxWidth().padding(start = 18.dp, end = 18.dp, top = 22.dp, bottom = 12.dp),
        verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.size(56.dp), contentAlignment = Alignment.Center) {
            Icon(Icons.Default.ShoppingCart, null, modifier = Modifier.size(38.dp), tint = Color.White)
            Text("🇩🇪", modifier = Modifier.align(Alignment.TopEnd), fontSize = 17.sp)
        }
        Spacer(Modifier.width(10.dp))
        Column {
            Text("Boodschappen Duitsland", fontSize = 22.sp, fontWeight = FontWeight.Bold, maxLines = 1,
                overflow = TextOverflow.Ellipsis)
            Text("Slimmer boodschappen doen", color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 14.sp)
        }
    }
}

@Composable
private fun HomeMode(label: String, icon: androidx.compose.ui.graphics.vector.ImageVector, selected: Boolean,
                     modifier: Modifier, onClick: () -> Unit) {
    Surface(modifier = modifier.clickable(onClick = onClick), shape = RoundedCornerShape(12.dp),
        color = if (selected) AccentBlue else MaterialTheme.colorScheme.surface) {
        Row(Modifier.height(48.dp), horizontalArrangement = Arrangement.Center, verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, modifier = Modifier.size(19.dp), tint = if (selected) Color.White else MaterialTheme.colorScheme.onSurfaceVariant)
            Spacer(Modifier.width(9.dp))
            Text(label, fontWeight = if (selected) FontWeight.Bold else FontWeight.Normal,
                color = if (selected) Color.White else MaterialTheme.colorScheme.onSurface)
        }
    }
}

@Composable
private fun EmptySearchCard(message: String) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp)) {
        Text(message, Modifier.padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun HomeProductCard(product: Product, best: ProductPrice?, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 5.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))) {
        Row(Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(76.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.LocalGroceryStore, null, modifier = Modifier.size(34.dp), tint = AccentBlue)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(product.name, fontSize = 18.sp, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
                Text(listOf(product.brand, product.displaySize).filter { it.isNotBlank() }.joinToString(" · "),
                    color = MaterialTheme.colorScheme.onSurfaceVariant, maxLines = 2)
                best?.let { Text("Vanaf ${it.effectivePriceCents.asEuro()} · indicatief", color = AccentBlue,
                    style = MaterialTheme.typography.labelMedium) }
            }
            Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun HomeStoreCard(store: Store, onClick: () -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 6.dp).clickable(onClick = onClick),
        shape = RoundedCornerShape(15.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.55f))) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Surface(shape = RoundedCornerShape(12.dp), color = MaterialTheme.colorScheme.primaryContainer,
                modifier = Modifier.size(width = 94.dp, height = 106.dp)) {
                Box(contentAlignment = Alignment.Center) {
                    Icon(Icons.Default.Storefront, null, modifier = Modifier.size(45.dp), tint = AccentBlue)
                }
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text("${store.country.flag} ${store.name}", fontWeight = FontWeight.Bold, fontSize = 18.sp, maxLines = 2)
                Text("Assortiment en prijzen indien beschikbaar", color = MaterialTheme.colorScheme.onSurfaceVariant,
                    style = MaterialTheme.typography.bodySmall)
                OutlinedButton(onClick = onClick, contentPadding = PaddingValues(horizontal = 12.dp, vertical = 2.dp)) {
                    Text("Bekijk assortiment", fontSize = 12.sp)
                    Icon(Icons.Default.ChevronRight, null, modifier = Modifier.size(18.dp))
                }
            }
        }
    }
}

@Composable
private fun CountryFilterBar(filter: CountryFilter, onFilter: (CountryFilter) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        val options = listOf(CountryFilter.ALL to "🌍 Alles", CountryFilter.NL to "🇳🇱 Nederland", CountryFilter.DE to "🇩🇪 Duitsland")
        options.forEachIndexed { index, (value, label) ->
            SegmentedButton(
                selected = filter == value,
                onClick = { onFilter(value) },
                shape = SegmentedButtonDefaults.itemShape(index, options.size),
                label = { Text(label, maxLines = 1) }
            )
        }
    }
}

@Composable
private fun HomeAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.bodySmall)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun ProductQuickCard(product: Product, best: ProductPrice?, onClick: () -> Unit) {
    Card(Modifier.width(190.dp).clickable(onClick = onClick)) {
        Column(Modifier.padding(14.dp)) {
            Text(product.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(product.brand, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(product.displaySize, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(10.dp))
            if (best != null) {
                Text("${best.store.country.flag} ${best.store.name}", fontWeight = FontWeight.SemiBold)
                Text(best.effectivePriceCents.asEuro(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                if (best.isOffer) Text("AANBIEDING", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                best.unitPriceCents?.let { Text("${it.asEuro()} ${best.unitLabel}", style = MaterialTheme.typography.labelSmall) }
            } else Text("Geen prijs beschikbaar", color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun ShoppingListScreen(state: UiState, viewModel: AppViewModel, onProduct: (Long) -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    val plan = PriceEngine.bestSingleStorePlan(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)
    val productsById = state.products.associateBy { it.id }
    val total = PriceEngine.listTotal(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)
    val expensive = PriceEngine.mostExpensiveComparableTotal(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { AppHeader("Boodschappenlijst", "Controleer inhoud en prijzen per winkel") }
        item { Text("Prijzen in deze versie zijn lokaal of voorbeeldgegevens; geen bevestigde actuele kassaprijzen.", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error) }
        item { CountryFilterBar(state.countryFilter, viewModel::setCountryFilter) }
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = state.strategy == ShoppingStrategy.MAX_SAVINGS,
                    onClick = { viewModel.setStrategy(ShoppingStrategy.MAX_SAVINGS) },
                    label = { Text("Maximale besparing") },
                    leadingIcon = { Icon(Icons.Default.Savings, null) }
                )
                FilterChip(
                    selected = state.strategy == ShoppingStrategy.ONE_STORE,
                    onClick = { viewModel.setStrategy(ShoppingStrategy.ONE_STORE) },
                    label = { Text("Alles bij één winkel") },
                    leadingIcon = { Icon(Icons.Default.Store, null) }
                )
            }
        }
        if (state.strategy == ShoppingStrategy.ONE_STORE && plan != null) {
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Beste keuze op basis van lokale gegevens", fontWeight = FontWeight.Bold)
                        Text("${plan.store.country.flag} ${plan.store.name} — ${plan.totalCents.asEuro()}")
                        if (plan.coveredItems < plan.totalItems) Text("Let op: ${plan.totalItems - plan.coveredItems} product(en) ontbreken bij deze winkel.", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
        items(state.shoppingList, key = { it.productId }) { item ->
            val product = productsById[item.productId] ?: return@items
            val best = if (state.strategy == ShoppingStrategy.ONE_STORE && plan != null) {
                state.prices.firstOrNull { it.productId == product.id && it.storeId == plan.store.id && PriceEngine.usable(it) }?.let { PriceEngine.priceForProduct(product, it, plan.store) }
            } else PriceEngine.bestPrice(product, state.prices, state.stores, state.countryFilter)
            ShoppingRow(item, product, best, viewModel, onProduct)
        }
        item {
            OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Product toevoegen")
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Bekend deeltotaal"); Text(total.asEuro(), fontWeight = FontWeight.Bold, fontSize = 24.sp) }
                    Column(horizontalAlignment = Alignment.End) { Text("Indicatief verschil"); Text((expensive - total).coerceAtLeast(0).asEuro(), fontWeight = FontWeight.Bold, fontSize = 24.sp) }
                }
            }
        }
        item {
            TextButton(onClick = viewModel::clearChecked, modifier = Modifier.fillMaxWidth().padding(8.dp)) { Text("Afgevinkte producten verwijderen") }
        }
    }

    if (showAdd) ProductPickerDialog(state, onDismiss = { showAdd = false }, onPick = { viewModel.addToList(it); showAdd = false })
}

@Composable
private fun ShoppingRow(item: ShoppingListItem, product: Product, best: ProductPrice?, viewModel: AppViewModel, onProduct: (Long) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = item.checked, onCheckedChange = { viewModel.setListChecked(product.id, it) })
            Column(Modifier.weight(1f).clickable { onProduct(product.id) }) {
                Text(product.name, fontWeight = FontWeight.Bold, textDecoration = if (item.checked) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
                Text("${product.brand} · ${product.displaySize}", style = MaterialTheme.typography.bodySmall)
                best?.let { Text("${it.store.country.flag} ${it.store.name} · ${it.effectivePriceCents.asEuro()}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
                    ?: Text("Geen prijs bij gekozen strategie", color = MaterialTheme.colorScheme.error)
            }
            IconButton(onClick = { viewModel.setListQuantity(product.id, item.quantity - 1) }) { Icon(Icons.Default.RemoveCircleOutline, "Minder") }
            Text("${item.quantity}x", fontWeight = FontWeight.Bold)
            IconButton(onClick = { viewModel.setListQuantity(product.id, item.quantity + 1) }) { Icon(Icons.Default.AddCircleOutline, "Meer") }
        }
    }
}

@Composable
private fun ProductPickerDialog(state: UiState, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    val inList = state.shoppingList.map { it.productId }.toSet()
    val options = state.products.filter { it.id !in inList && (query.isBlank() || (it.name + it.brand).contains(query, true)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Sluiten") } },
        title = { Text("Product toevoegen") },
        text = {
            Column {
                OutlinedTextField(query, { query = it }, label = { Text("Zoeken") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(options, key = { it.id }) { product ->
                        ListItem(
                            headlineContent = { Text(product.name) },
                            supportingContent = { Text("${product.brand} · ${product.displaySize}") },
                            trailingContent = { Icon(Icons.Default.Add, null) },
                            modifier = Modifier.clickable { onPick(product.id) }
                        )
                    }
                }
            }
        }
    )
}

@Composable
private fun PricesScreen(state: UiState, viewModel: AppViewModel, onOpenProduct: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showNewProduct by remember { mutableStateOf(false) }
    var editingPrice by remember { mutableStateOf<PriceEditTarget?>(null) }
    val products = state.products.filter { query.isBlank() || (it.name + " " + it.brand).contains(query, true) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { AppHeader("Prijzen", "Normale prijs, aanbieding en prijs per eenheid") }
        item { CountryFilterBar(state.countryFilter, viewModel::setCountryFilter) }
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(query, { query = it }, Modifier.weight(1f), label = { Text("Zoek product") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { showNewProduct = true }) { Icon(Icons.Default.Add, "Product toevoegen") }
            }
        }
        items(products, key = { it.id }) { product ->
            val ranked = PriceEngine.rankedPrices(product, state.prices, state.stores, state.countryFilter)
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold)
                            Text("${product.brand} · ${product.displaySize}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { onOpenProduct(product.id) }) { Text("Details") }
                    }
                    if (ranked.isEmpty()) Text("Nog geen prijzen ingevoerd", color = MaterialTheme.colorScheme.error)
                    ranked.take(4).forEachIndexed { index, price ->
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (index == 0) "🏆" else "", Modifier.width(28.dp))
                            Text("${price.store.country.flag} ${price.store.name}", Modifier.weight(1f))
                            Column(horizontalAlignment = Alignment.End) {
                                Text(price.effectivePriceCents.asEuro(), fontWeight = FontWeight.Bold, color = if (index == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                                price.unitPriceCents?.let { Text("${it.asEuro()} ${price.unitLabel}", style = MaterialTheme.typography.labelSmall) }
                            }
                            IconButton(onClick = { editingPrice = PriceEditTarget(product, price.store, price.entry) }) { Icon(Icons.Default.Edit, "Bewerk") }
                        }
                    }
                    val storesWithNoPrice = state.stores.filter { it.enabled && ranked.none { p -> p.store.id == it.id } }
                    if (storesWithNoPrice.isNotEmpty()) {
                        TextButton(onClick = { editingPrice = PriceEditTarget(product, storesWithNoPrice.first(), null) }) { Text("Prijs toevoegen bij ${storesWithNoPrice.first().name}") }
                    }
                }
            }
        }
    }

    editingPrice?.let { PriceEditDialog(it, onDismiss = { editingPrice = null }) { regular, offer, days ->
        viewModel.upsertPrice(it.product.id, it.store.id, regular, offer, days)
        editingPrice = null
    } }
    if (showNewProduct) NewProductDialog(onDismiss = { showNewProduct = false }) { name, brand, ean, size, unit, category ->
        viewModel.addProduct(name, brand, ean, size, unit, category)
        showNewProduct = false
    }
}

private data class PriceEditTarget(val product: Product, val store: Store, val entry: PriceEntry?)

@Composable
private fun PriceEditDialog(target: PriceEditTarget, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var regular by remember(target) { mutableStateOf(target.entry?.regularPriceCents?.let { centsToInput(it) } ?: "") }
    var offer by remember(target) { mutableStateOf(target.entry?.offerPriceCents?.let { centsToInput(it) } ?: "") }
    var days by remember(target) { mutableStateOf(if (target.entry?.offerPriceCents != null) "7" else "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${target.product.name} · ${target.store.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(regular, { regular = it }, label = { Text("Normale prijs (€)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(offer, { offer = it }, label = { Text("Aanbiedingsprijs (€), optioneel") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(days, { days = it }, label = { Text("Aanbieding geldig aantal dagen") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = { Button(onClick = { onSave(regular, offer, days) }, enabled = regular.isNotBlank()) { Text("Opslaan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

@Composable
private fun NewProductDialog(onDismiss: () -> Unit, onSave: (String, String, String?, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var ean by remember { mutableStateOf("") }
    var size by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("st") }
    var category by remember { mutableStateOf("Overig") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nieuw product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Productnaam") }, singleLine = true)
                OutlinedTextField(brand, { brand = it }, label = { Text("Merk") }, singleLine = true)
                OutlinedTextField(ean, { ean = it }, label = { Text("EAN/barcode (optioneel)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(size, { size = it }, Modifier.weight(1f), label = { Text("Inhoud") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(unit, { unit = it }, Modifier.weight(1f), label = { Text("Eenheid") }, singleLine = true)
                }
                OutlinedTextField(category, { category = it }, label = { Text("Categorie") }, singleLine = true)
            }
        },
        confirmButton = { Button(onClick = { onSave(name, brand, ean.ifBlank { null }, size, unit, category) }, enabled = name.isNotBlank()) { Text("Toevoegen") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

private data class OfferUiItem(
    val product: Product,
    val store: Store,
    val entry: PriceEntry,
    val effectiveCents: Int
)

@Composable
private fun OffersScreen(state: UiState, viewModel: AppViewModel) {
    val context = LocalContext.current
    val productsById = state.products.associateBy { it.id }
    val storesById = state.stores.associateBy { it.id }
    val offers = state.prices.mapNotNull { entry ->
        val (effective, isOffer) = PriceEngine.effectivePrice(entry)
        if (!isOffer || !PriceEngine.usable(entry)) return@mapNotNull null
        val product = productsById[entry.productId] ?: return@mapNotNull null
        val store = storesById[entry.storeId] ?: return@mapNotNull null
        if (!store.enabled) return@mapNotNull null
        OfferUiItem(product, store, entry, effective)
    }
    val grouped = offers
        .groupBy { it.store }
        .toList()
        .sortedWith(compareBy<Pair<Store, List<OfferUiItem>>>({ it.first.country.name }, { it.first.name.lowercase(Locale.getDefault()) }))

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { SectionTitle("Folders", "Officiële pagina's van geselecteerde winkels") }
        items(state.stores.filter { it.enabled }) { store ->
            officialFolder(store)?.let { link ->
                ListItem(headlineContent = { Text("${store.country.flag} ${store.name}") },
                    supportingContent = { Text("Open folder of aanbiedingen bij de winkel") },
                    leadingContent = { Icon(Icons.Default.MenuBook, null) },
                    modifier = Modifier.clickable {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
                            .onFailure { Toast.makeText(context, "Folder openen mislukt", Toast.LENGTH_SHORT).show() }
                    })
            }
        }
        item {
            AppHeader("Aanbiedingen", "Per winkel, met actuele Bonus-refresh") {
                if (state.offersRefreshing) {
                    CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                } else {
                    IconButton(onClick = viewModel::refreshOffers) {
                        Icon(Icons.Default.Refresh, "Aanbiedingen vernieuwen")
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Vernieuwen", fontWeight = FontWeight.Bold)
                    Text(
                        "Vernieuwen haalt Albert Heijn Bonus op. Voor andere winkels open je de officiële folder of importeer je gecontroleerde gegevens.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    state.lastOffersRefreshMillis?.let {
                        Text("Laatst succesvol vernieuwd: ${formatDateTime(it)}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        if (offers.isEmpty()) {
            item { Text("Geen actieve aanbiedingen.", Modifier.padding(16.dp)) }
        }
        grouped.forEach { (store, storeOffers) ->
            item(key = "store-${store.id}") {
                SectionTitle("${store.country.flag} ${store.name} · ${storeOffers.size} aanbiedingen")
            }
            items(
                items = storeOffers.sortedWith(compareBy<OfferUiItem>({ it.product.category }, { it.product.name })),
                key = { "offer-${it.entry.id}" }
            ) { item ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalOffer, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(item.product.name, fontWeight = FontWeight.Bold)
                            val detail = buildString {
                                if (item.product.brand.isNotBlank()) append(item.product.brand)
                                if (item.product.sizeValue > 0 && item.product.sizeUnit.isNotBlank()) {
                                    if (isNotEmpty()) append(" · ")
                                    append(item.product.displaySize)
                                }
                            }
                            if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.bodySmall)
                            item.entry.offerLabel?.takeIf { it.isNotBlank() }?.let {
                                Text(it, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("Normaal ${item.entry.regularPriceCents.asEuro()}", style = MaterialTheme.typography.bodySmall)
                            item.entry.offerUntilMillis?.let { Text("Geldig t/m ${formatDate(it)}", style = MaterialTheme.typography.labelSmall) }
                        }
                        Text(item.effectiveCents.asEuro(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        IconButton(onClick = { viewModel.addToList(item.product.id) }) {
                            Icon(Icons.Default.PlaylistAdd, "Aan boodschappenlijst toevoegen")
                        }
                    }
                }
            }
        }
    }
}

private fun officialFolder(store: Store): String? {
    val name = store.name.lowercase(Locale.ROOT)
    return when {
        name.contains("jumbo") -> "https://www.jumbo.com/aanbiedingen/nu"
        name.contains("albert heijn") -> "https://www.ah.nl/bonus"
        name.contains("dirk") -> "https://www.dirk.nl/folder"
        name.contains("plus") -> "https://www.plus.nl/aanbiedingen"
        name.contains("kruidvat") -> "https://www.kruidvat.nl/folders"
        name.contains("schroff") -> "https://edeka-schroff.de/"
        name.contains("kaufland") -> "https://filiale.kaufland.de/angebote/uebersicht.html"
        name.contains("rewe") -> "https://www.rewe.de/angebote/"
        name.contains("aldi") -> "https://www.aldi-sued.de/angebote"
        name == "dm" -> "https://www.dm.de/angebote/"
        name.contains("lidl") && store.country == Country.NL -> "https://www.lidl.nl/"
        name.contains("lidl") -> "https://www.lidl.de/"
        else -> null
    }
}

@Composable
private fun StoresScreen(state: UiState, viewModel: AppViewModel, onStore: (Long) -> Unit, onOffers: () -> Unit,
                         addRequested: Boolean, onAddRequestConsumed: () -> Unit) {
    var addStore by remember { mutableStateOf(false) }
    LaunchedEffect(addRequested) {
        if (addRequested) { addStore = true; onAddRequestConsumed() }
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { AppHeader("Winkels", "Tik op een winkel voor je lijst en een deeltotaal") }
        item {
            FilledTonalButton(onClick = onOffers, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Icon(Icons.Default.LocalOffer, null); Spacer(Modifier.width(8.dp)); Text("Folders en aanbiedingen")
            }
        }
        item {
            FilledTonalButton(onClick = { addStore = true }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Icon(Icons.Default.AddBusiness, null); Spacer(Modifier.width(8.dp)); Text("Winkel toevoegen")
            }
        }
        item { SectionTitle("Nederland") }
        items(state.stores.filter { it.country == Country.NL }, key = { it.id }) { store -> StoreRow(store, viewModel, onStore) }
        item { SectionTitle("Duitsland") }
        items(state.stores.filter { it.country == Country.DE }, key = { it.id }) { store -> StoreRow(store, viewModel, onStore) }
    }
    if (addStore) AddStoreDialog(onDismiss = { addStore = false }) { name, country -> viewModel.addStore(name, country); addStore = false }
}

@Composable
private fun StoreRow(store: Store, viewModel: AppViewModel, onStore: (Long) -> Unit) {
    ListItem(
        headlineContent = { Text(store.name, fontWeight = FontWeight.SemiBold) },
        supportingContent = { Text("${store.country.flag} ${store.country.label} · Bekijk boodschappenlijst") },
        leadingContent = { Icon(Icons.Default.Storefront, null) },
        trailingContent = { Switch(checked = store.enabled, onCheckedChange = { viewModel.setStoreEnabled(store.id, it) }) },
        modifier = Modifier.clickable { onStore(store.id) }
    )
    HorizontalDivider()
}

@Composable
private fun StoreBasketScreen(state: UiState, store: Store, onBack: () -> Unit, onProduct: (Long) -> Unit) {
    val productsById = state.products.associateBy { it.id }
    val pricesByProduct = state.prices.filter { it.storeId == store.id && PriceEngine.usable(it) }.associateBy { it.productId }
    var subtotal = 0L
    var missing = 0
    state.shoppingList.forEach { item ->
        val entry = pricesByProduct[item.productId]
        if (entry == null || productsById[item.productId] == null) missing++
        else subtotal += PriceEngine.effectivePrice(entry).first.toLong() * item.quantity
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Terug") }
                AppHeader("${store.country.flag} ${store.name}", "Boodschappenlijst voor deze winkel")
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (missing == 0 && state.shoppingList.isNotEmpty()) "Indicatief winkelbedrag" else "Bekend deeltotaal", fontWeight = FontWeight.Bold)
                    Text(subtotal.asEuro(), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    if (missing > 0) Text("$missing product(en) zonder prijs. Geen volledig winkelbedrag beschikbaar.", color = MaterialTheme.colorScheme.error)
                    Text("Voorbeeld- en handmatig ingevoerde prijzen zijn geen bevestigde actuele kassaprijzen.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(state.shoppingList, key = { it.productId }) { item ->
            val product = productsById[item.productId] ?: return@items
            val entry = pricesByProduct[item.productId]
            ListItem(headlineContent = { Text("${item.quantity}× ${product.name}") },
                supportingContent = { Text(product.displaySize) },
                trailingContent = { Text(entry?.let { (PriceEngine.effectivePrice(it).first.toLong() * item.quantity).asEuro() } ?: "Prijs onbekend") },
                modifier = Modifier.clickable { onProduct(product.id) })
            HorizontalDivider()
        }
    }
}

private data class StoreComparison(
    val store: Store, val knownTotal: Long, val covered: Int, val count: Int
) {
    val complete: Boolean get() = count > 0 && covered == count
}

@Composable
private fun CompareBasketScreen(state: UiState, onBack: () -> Unit,
                                onStore: (Long) -> Unit, onProducts: () -> Unit) {
    val comparisons = state.stores.filter { it.enabled }.map { store ->
        var total = 0L
        var covered = 0
        state.shoppingList.forEach { item ->
            val entry = state.prices.firstOrNull {
                it.storeId == store.id && it.productId == item.productId && PriceEngine.usable(it)
            }
            if (entry != null) {
                total += PriceEngine.effectivePrice(entry).first.toLong() * item.quantity
                covered++
            }
        }
        StoreComparison(store, total, covered, state.shoppingList.size)
    }.sortedWith(compareByDescending<StoreComparison> { it.complete }
        .thenByDescending { it.covered }.thenBy { it.knownTotal })

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 22.dp)) {
        item { BrandHeader() }
        item {
            Column(Modifier.padding(horizontal = 18.dp, vertical = 12.dp)) {
                Text("Vergelijk je boodschappenlijst", fontSize = 25.sp, fontWeight = FontWeight.Bold)
                Text("${state.shoppingList.size} producten · ${comparisons.size} geselecteerde winkels",
                    color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        if (state.shoppingList.isEmpty()) item { EmptySearchCard("Je boodschappenlijst is nog leeg. Voeg producten toe via de lijst, scanner of aanbiedingen.") }
        items(comparisons, key = { it.store.id }) { plan ->
            val rank = if (plan.complete) comparisons.filter { it.complete }.indexOf(plan) + 1 else null
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)
                .clickable { onStore(plan.store.id) }, shape = RoundedCornerShape(15.dp),
                border = androidx.compose.foundation.BorderStroke(if (rank == 1) 2.dp else 1.dp,
                    if (rank == 1) AccentBlue else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(width = 86.dp, height = 95.dp)
                        .background(MaterialTheme.colorScheme.primaryContainer, RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center) {
                        Icon(Icons.Default.Storefront, null, modifier = Modifier.size(40.dp), tint = AccentBlue)
                        if (rank != null) Surface(Modifier.align(Alignment.TopStart).size(26.dp),
                            shape = RoundedCornerShape(50), color = if (rank == 1) AccentYellow else MaterialTheme.colorScheme.outline) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("$rank", color = Color(0xFF101923), fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text("${plan.store.country.flag} ${plan.store.name}", fontSize = 18.sp,
                            fontWeight = FontWeight.Bold, maxLines = 2)
                        Text(if (plan.complete) "Totaal voor ${plan.count} producten" else
                            "${plan.covered}/${plan.count} producten met prijs", color = MaterialTheme.colorScheme.onSurfaceVariant,
                            style = MaterialTheme.typography.bodySmall)
                        Spacer(Modifier.height(6.dp))
                        Text(if (plan.complete) plan.knownTotal.asEuro() else "Bekend deel: ${plan.knownTotal.asEuro()}",
                            fontSize = if (plan.complete) 23.sp else 17.sp, fontWeight = FontWeight.Bold)
                    }
                    Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
                }
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp),
                verticalAlignment = Alignment.Top) {
                Icon(Icons.Default.Info, null, tint = MaterialTheme.colorScheme.onSurfaceVariant,
                    modifier = Modifier.size(18.dp))
                Spacer(Modifier.width(9.dp))
                Text("Bedragen zijn indicatief. Handmatige en online prijzen kunnen van de kassa afwijken; ontbrekende producten tellen niet mee in het bekende deel.",
                    color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall)
            }
        }
        item {
            SettingsTile("Bekijk vergelijking per product", "Inhoud en beschikbare winkelprijzen",
                Icons.Default.BarChart, onProducts)
        }
        item {
            Button(onClick = onBack, modifier = Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 14.dp).height(54.dp),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = AccentYellow, contentColor = Color(0xFF101923))) {
                Icon(Icons.Default.ArrowBack, null)
                Spacer(Modifier.width(12.dp))
                Text("Terug naar instellingen", fontWeight = FontWeight.Bold)
            }
        }
    }
}

@Composable
private fun StoreCatalogScreen(state: UiState, store: Store, onBack: () -> Unit, onProduct: (Long) -> Unit) {
    val productMap = state.products.associateBy { it.id }
    val products = state.prices.filter { it.storeId == store.id && PriceEngine.usable(it) }
        .mapNotNull { entry -> productMap[entry.productId]?.let { it to entry } }
        .sortedBy { it.first.name }
    var query by remember(store.id) { mutableStateOf("") }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Row(Modifier.fillMaxWidth(), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Terug") }
                AppHeader("${store.country.flag} ${store.name}", "Beschikbaar assortiment in de app")
            }
        }
        item {
            OutlinedTextField(query, { query = it }, modifier = Modifier.fillMaxWidth().padding(16.dp),
                leadingIcon = { Icon(Icons.Default.Search, null) }, singleLine = true,
                placeholder = { Text("Zoek in assortiment") })
        }
        if (products.isEmpty()) item { EmptySearchCard("Voor deze winkel is nog geen productbestand met prijzen geïmporteerd.") }
        items(products.filter { it.first.name.contains(query, ignoreCase = true) || it.first.brand.contains(query, ignoreCase = true) },
            key = { it.first.id }) { (product, entry) ->
            ListItem(headlineContent = { Text(product.name) }, supportingContent = { Text(product.displaySize) },
                trailingContent = { Text(PriceEngine.effectivePrice(entry).first.asEuro()) },
                modifier = Modifier.clickable { onProduct(product.id) })
            HorizontalDivider()
        }
    }
}

@Composable
private fun AddStoreDialog(onDismiss: () -> Unit, onSave: (String, Country) -> Unit) {
    var name by remember { mutableStateOf("") }
    var country by remember { mutableStateOf(Country.DE) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Winkel toevoegen") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Winkelnaam") }, singleLine = true)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = country == Country.NL, onClick = { country = Country.NL }, label = { Text("🇳🇱 Nederland") })
                    FilterChip(selected = country == Country.DE, onClick = { country = Country.DE }, label = { Text("🇩🇪 Duitsland") })
                }
            }
        },
        confirmButton = { Button(onClick = { onSave(name, country) }, enabled = name.isNotBlank()) { Text("Toevoegen") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

@Composable
private fun SettingsScreen(
    state: UiState,
    viewModel: AppViewModel,
    onStores: () -> Unit,
    onAddStore: () -> Unit,
    onCompare: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onImportCatalog: () -> Unit
) {
    var confirmReset by remember { mutableStateOf(false) }
    var confirmImport by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item { BrandHeader() }
        item { Text("Instellingen", Modifier.padding(start = 18.dp, top = 12.dp, bottom = 14.dp), fontSize = 27.sp, fontWeight = FontWeight.Bold) }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), shape = RoundedCornerShape(17.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("Winkels en vergelijken", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Beheer je winkels en vergelijk je lijst", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(12.dp))
                    SettingsTile("Actieve winkels", "Kies welke winkels meetellen", Icons.Default.Storefront, onStores)
                    SettingsTile("Winkel toevoegen", "Voeg een winkel toe", Icons.Default.Add, onAddStore)
                    Spacer(Modifier.height(10.dp))
                    Button(onClick = onCompare, modifier = Modifier.fillMaxWidth().heightIn(min = 56.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AccentYellow, contentColor = Color(0xFF111923))) {
                        Icon(Icons.Default.ShoppingBasket, null)
                        Spacer(Modifier.width(10.dp))
                        Text("Vergelijk boodschappenlijst", fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f), maxLines = 1,
                            overflow = TextOverflow.Ellipsis)
                        Icon(Icons.Default.ChevronRight, null)
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), shape = RoundedCornerShape(17.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("Weergave", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Pas de app aan naar jouw voorkeuren", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    Row(Modifier.fillMaxWidth().background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp)).padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically) {
                        SettingsIcon(Icons.Default.DarkMode)
                        Spacer(Modifier.width(12.dp))
                        Column(Modifier.weight(1f)) {
                            Text("Donkere modus", fontWeight = FontWeight.Bold)
                            Text("Rustige, donkere weergave", color = MaterialTheme.colorScheme.onSurfaceVariant,
                                style = MaterialTheme.typography.bodySmall)
                        }
                        Switch(checked = state.darkMode, onCheckedChange = viewModel::setDarkMode)
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp), shape = RoundedCornerShape(17.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))) {
                Column(Modifier.padding(12.dp)) {
                    Text("Gegevens", fontSize = 19.sp, fontWeight = FontWeight.Bold)
                    Text("Beheer gegevens en back-ups", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(10.dp))
                    SettingsTile("Back-up maken", "Sla je lijst en instellingen veilig op", Icons.Default.CloudUpload, onExportBackup)
                    SettingsTile("Back-up terugzetten", "Herstel eerder bewaarde gegevens", Icons.Default.Restore) { confirmImport = true }
                    SettingsTile("Winkelbestand importeren", "Producten en prijzen per winkel", Icons.Default.FileOpen, onImportCatalog)
                    SettingsTile("Lokale gegevens wissen", "Alleen na bevestiging", Icons.Default.DeleteOutline) { confirmReset = true }
                }
            }
        }
        item {
            Text("Versie ${BuildConfig.VERSION_NAME} · prijzen kunnen per filiaal verschillen",
                Modifier.fillMaxWidth().padding(18.dp), color = MaterialTheme.colorScheme.onSurfaceVariant,
                style = MaterialTheme.typography.bodySmall)
        }
    }

    if (confirmImport) {
        AlertDialog(
            onDismissRequest = { confirmImport = false },
            title = { Text("Back-up terugzetten?") },
            text = { Text("De huidige lokale gegevens worden vervangen door de gegevens uit het gekozen back-upbestand. Maak zo nodig eerst een nieuwe back-up.") },
            confirmButton = {
                Button(onClick = {
                    confirmImport = false
                    onImportBackup()
                }) { Text("Bestand kiezen") }
            },
            dismissButton = { TextButton(onClick = { confirmImport = false }) { Text("Annuleren") } }
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Gegevens wissen?") },
            text = { Text("Producten, prijzen en lijst worden verwijderd. De twaalf winkels blijven beschikbaar. Maak eerst een back-up als je dit wilt bewaren.") },
            confirmButton = {
                Button(onClick = {
                    confirmReset = false
                    viewModel.resetDemoData()
                }) { Text("Wissen") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Annuleren") } }
        )
    }
}

@Composable
private fun SettingsIcon(icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Surface(shape = RoundedCornerShape(50), color = MaterialTheme.colorScheme.primaryContainer,
        modifier = Modifier.size(44.dp)) {
        Box(contentAlignment = Alignment.Center) {
            Icon(icon, null, tint = AccentBlue, modifier = Modifier.size(24.dp))
        }
    }
}

@Composable
private fun SettingsTile(title: String, subtitle: String,
                         icon: androidx.compose.ui.graphics.vector.ImageVector, onClick: () -> Unit) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp)
        .background(MaterialTheme.colorScheme.surfaceVariant, RoundedCornerShape(12.dp))
        .clickable(onClick = onClick).padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
        SettingsIcon(icon)
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(subtitle, color = MaterialTheme.colorScheme.onSurfaceVariant, style = MaterialTheme.typography.bodySmall,
                maxLines = 2)
        }
        Icon(Icons.Default.ChevronRight, null, tint = MaterialTheme.colorScheme.onSurfaceVariant)
    }
}

@Composable
private fun ScanResultScreen(state: UiState, viewModel: AppViewModel, onBack: () -> Unit, onScanNext: () -> Unit) {
    val product = state.products.firstOrNull { it.id == state.selectedProductId }
    if (product == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { if (state.loading) CircularProgressIndicator() else Text("Geen product geselecteerd") }
        return
    }
    val ranked = PriceEngine.rankedPrices(product, state.prices, state.stores, state.countryFilter)
    val best = ranked.firstOrNull()
    val second = ranked.getOrNull(1)
    val diffPct = if (best != null && second != null && second.effectivePriceCents > 0) ((second.effectivePriceCents - best.effectivePriceCents) * 100 / second.effectivePriceCents) else 0
    var editProduct by remember(product.id) { mutableStateOf(product.name == "Onbekend product") }
    var editingPrice by remember { mutableStateOf<PriceEditTarget?>(null) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Terug") }
                Text("Scanresultaat", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onScanNext) { Icon(Icons.Default.QrCodeScanner, "Scan volgende") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                            Text(product.brand)
                            Text("${product.displaySize}${product.ean?.let { " · EAN $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { editProduct = true }) { Icon(Icons.Default.Edit, "Product bewerken") }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = if (best != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (best != null) Icons.Default.EmojiEvents else Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        if (best != null) {
                            Text("Beste keuze: ${best.store.name}", fontWeight = FontWeight.Bold)
                            Text(best.effectivePriceCents.asEuro(), fontWeight = FontWeight.Bold, fontSize = 28.sp)
                            if (second != null) Text("$diffPct% goedkoper dan het volgende alternatief", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text("Nog geen prijsgegevens", fontWeight = FontWeight.Bold)
                            Text("Voeg hieronder een prijs toe.")
                        }
                    }
                    SuggestionChip(onClick = {}, label = { Text(if (best != null) "KOPEN" else "AANVULLEN") })
                }
            }
        }
        item { SectionTitle("Prijzen", "Goedkoopste bovenaan, landen door elkaar") }
        items(ranked, key = { it.store.id }) { price ->
            ListItem(
                headlineContent = { Text("${price.store.country.flag} ${price.store.name}", fontWeight = FontWeight.SemiBold) },
                supportingContent = {
                    Column {
                        Text(if (price.isOffer) "Aanbieding · normaal ${price.entry.regularPriceCents.asEuro()}" else "Normale prijs")
                        price.unitPriceCents?.let { Text("${it.asEuro()} ${price.unitLabel}") }
                    }
                },
                trailingContent = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(price.effectivePriceCents.asEuro(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        IconButton(onClick = { editingPrice = PriceEditTarget(product, price.store, price.entry) }) { Icon(Icons.Default.Edit, "Bewerk") }
                    }
                }
            )
            HorizontalDivider()
        }
        item {
            val missingStores = state.stores.filter { it.enabled && ranked.none { p -> p.store.id == it.id } }
            if (missingStores.isNotEmpty()) {
                TextButton(onClick = { editingPrice = PriceEditTarget(product, missingStores.first(), null) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Prijs toevoegen bij ${missingStores.first().name}")
                }
            }
        }
        item { SectionTitle("Prijsverloop", "Historie per winkel — winkels worden niet door elkaar verbonden") }
        val historyByStore = state.history
            .filter { it.productId == product.id }
            .groupBy { it.storeId }
            .toList()
            .sortedBy { (storeId, _) -> state.stores.firstOrNull { it.id == storeId }?.name ?: "" }
        if (historyByStore.isEmpty()) {
            item { Text("Nog geen prijshistorie beschikbaar.", Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }
        } else {
            items(historyByStore, key = { it.first }) { (storeId, points) ->
                val store = state.stores.firstOrNull { it.id == storeId }
                Text(
                    text = store?.let { "${it.country.flag} ${it.name}" } ?: "Winkel $storeId",
                    modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 4.dp),
                    fontWeight = FontWeight.SemiBold
                )
                PriceHistoryChart(points)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { viewModel.addToList(product.id) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PlaylistAdd, null); Spacer(Modifier.width(6.dp)); Text("Aan lijst") }
                Button(onClick = onScanNext, modifier = Modifier.weight(1f)) { Icon(Icons.Default.QrCodeScanner, null); Spacer(Modifier.width(6.dp)); Text("Scan volgende") }
            }
        }
    }

    if (editProduct) EditProductDialog(product, onDismiss = { editProduct = false }) { updated -> viewModel.updateProduct(updated); editProduct = false }
    editingPrice?.let { target -> PriceEditDialog(target, onDismiss = { editingPrice = null }) { regular, offer, days ->
        viewModel.upsertPrice(target.product.id, target.store.id, regular, offer, days); editingPrice = null
    } }
}

@Composable
private fun EditProductDialog(product: Product, onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember(product) { mutableStateOf(product.name) }
    var brand by remember(product) { mutableStateOf(product.brand) }
    var size by remember(product) { mutableStateOf(product.sizeValue.toString()) }
    var unit by remember(product) { mutableStateOf(product.sizeUnit) }
    var category by remember(product) { mutableStateOf(product.category) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Productgegevens") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                product.ean?.let { Text("EAN: $it", style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(name, { name = it }, label = { Text("Naam") }, singleLine = true)
                OutlinedTextField(brand, { brand = it }, label = { Text("Merk") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(size, { size = it }, Modifier.weight(1f), label = { Text("Inhoud") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    OutlinedTextField(unit, { unit = it }, Modifier.weight(1f), label = { Text("Eenheid") }, singleLine = true)
                }
                OutlinedTextField(category, { category = it }, label = { Text("Categorie") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(product.copy(name = name.trim(), brand = brand.trim(), sizeValue = size.replace(',', '.').toDoubleOrNull() ?: product.sizeValue, sizeUnit = unit.trim(), category = category.trim()))
            }, enabled = name.isNotBlank()) { Text("Opslaan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

@Composable
private fun PriceHistoryChart(points: List<PriceHistoryPoint>) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        if (points.size < 2) {
            Text("Nog te weinig historie. Elke prijswijziging wordt vanaf nu opgeslagen.", Modifier.padding(16.dp))
            return@Card
        }
        val sorted = points.sortedBy { it.capturedAtMillis }.takeLast(24)
        val minPrice = sorted.minOf { it.priceCents }
        val maxPrice = max(sorted.maxOf { it.priceCents }, minPrice + 1)
        val primary = MaterialTheme.colorScheme.primary
        Column(Modifier.padding(14.dp)) {
            Text("${minPrice.asEuro()} – ${maxPrice.asEuro()}", style = MaterialTheme.typography.bodySmall)
            Canvas(Modifier.fillMaxWidth().height(140.dp).padding(vertical = 8.dp)) {
                val w = size.width
                val h = size.height
                val step = if (sorted.size <= 1) w else w / (sorted.size - 1)
                var previous: Offset? = null
                sorted.forEachIndexed { index, point ->
                    val normalized = (point.priceCents - minPrice).toFloat() / (maxPrice - minPrice).toFloat()
                    val current = Offset(index * step, h - normalized * h)
                    previous?.let { drawLine(primary, it, current, strokeWidth = 5f, cap = StrokeCap.Round) }
                    drawCircle(primary, radius = 6f, center = current)
                    previous = current
                }
            }
        }
    }
}

private fun centsToInput(cents: Int) = "${cents / 100},${(cents % 100).toString().padStart(2, '0')}"
private fun formatDate(millis: Long) = SimpleDateFormat("dd-MM-yyyy", Locale("nl", "NL")).format(Date(millis))
private fun formatDateTime(millis: Long) = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("nl", "NL")).format(Date(millis))
