package nl.jays.boodschappenduitsland.ui

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

val AccentBlue = Color(0xFF278CFF)
val AccentYellow = Color(0xFFFFD62F)
private val Navy = Color(0xFF0D1723)
private val CardNavy = Color(0xFF192534)
private val Muted = Color(0xFFA6B7CC)

private val LightColors = lightColorScheme(
    primary = Color(0xFF176ECD),
    onPrimary = Color.White,
    primaryContainer = Color(0xFFDEEDFF),
    onPrimaryContainer = Color(0xFF0D2238),
    secondary = Color(0xFF395E88),
    background = Color(0xFFF7F9FC),
    surface = Color.White,
    onSurface = Color(0xFF142333),
    outline = Color(0xFF71869D)
)

private val DarkColors = darkColorScheme(
    primary = AccentBlue,
    onPrimary = Color.White,
    primaryContainer = Color(0xFF193856),
    onPrimaryContainer = Color(0xFFE3F0FF),
    secondary = AccentYellow,
    onSecondary = Color(0xFF141B23),
    background = Navy,
    surface = CardNavy,
    surfaceVariant = Color(0xFF1E2B3B),
    onSurface = Color(0xFFF5F8FF),
    onSurfaceVariant = Muted,
    outline = Color(0xFF3A5068)
)

@Composable
fun BoodschappenTheme(darkMode: Boolean, content: @Composable () -> Unit) {
    MaterialTheme(
        colorScheme = if (darkMode) DarkColors else LightColors,
        content = content
    )
}
