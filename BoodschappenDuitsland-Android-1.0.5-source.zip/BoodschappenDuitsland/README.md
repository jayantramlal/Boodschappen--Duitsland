# Boodschappen Duitsland — Android 1.0.5

## Visuele update 1.0.5

Het beginscherm, de instellingen en de boodschappenlijstvergelijking volgen de
donkere blauwgele ontwerpvoorbeelden. De UI gebruikt rustige kaarten, grote
zoekvelden, een blauw geselecteerde modus en een gele hoofdactie. Het
winkelassortiment toont alleen daadwerkelijk lokaal beschikbare producten;
zonder geïmporteerd bestand verschijnt een duidelijke lege toestand. De
vergelijking rangschikt uitsluitend winkels met een prijs voor elk lijstproduct.
Product- en winkelfoto's uit de voorbeelden zijn niet als assets beschikbaar;
de app gebruikt voorlopig herkenbare iconen. Volledige live filiaalprijsfeeds
blijven afzonderlijk nodig.

## Status van deze wijziging

- Donkere modus is standaard actief; beide Android-systeembalken zijn zwart.
- Home biedt zoeken naar producten of winkels. De onderste balk blijft Home, Lijst, Scan, Winkels, Instellingen.
- Android Terug volgt de schermgeschiedenis; vanuit Home sluit de app.
- Tik op een lijstproduct of winkel om details respectievelijk een winkellijst te zien. Een onvolledige winkel toont expliciet een deeltotaal.
- Instellingen biedt winkels beheren en boodschappenlijst vergelijken.
- De aanbiedingenpagina toont officiële folder-/aanbiedingslinks van aangevinkte winkels en kan bekende aanbiedingen toevoegen aan de lijst.
- Op een nieuwe installatie zijn twaalf gevraagde winkels beschikbaar, zonder fictieve producten en prijzen. Bestaande databases blijven bewaard en migreren van versie 4 naar 5.
- De bestaande catalogusimport en Albert Heijn Bonus-refresh van versie 1.0.3 blijven aanwezig. Geïmporteerde catalogusprijzen verdwijnen na 24 uur uit de vergelijking; AH Bonus-prijzen na 12 uur.

**Grenzen:** Folderlinks openen de officiële winkelpagina buiten de app. Een product dat alleen als afbeelding of tekst in een folder staat, kan nog niet automatisch op de juiste EAN aan de lijst worden gekoppeld. Er zijn nog geen volledige live filiaalprijsfeeds voor alle winkels. Lokaal ingevoerde prijzen en oudere voorbeelddata van bestaande installaties zijn indicatief. Deze broncode is niet als release-APK gebouwd of op een toestel getest; beschouw dit niet als volledig afgerond.

Native Android-app in Kotlin + Jetpack Compose voor prijsvergelijking tussen Nederlandse en Duitse supermarkten/drogisterijen.

## Kernfuncties
- Nederland en Duitsland in één prijsvergelijking; de laagste geldige prijs wint.
- Optionele NL/DE-filters.
- Normale prijs + geldige aanbiedingsprijs + einddatum.
- Eenheidsprijs per liter/kg/stuk waar mogelijk.
- Boodschappenlijst met aantallen en afvinken.
- Strategie `Maximale besparing` of `Alles bij één winkel`.
- Barcode-scanner via Google Code Scanner.
- Onbekende barcode wordt lokaal aangemaakt en kan daarna worden ingevuld.
- Producten, winkels en prijzen handmatig beheren.
- Prijshistorie per winkel.
- Licht/donker thema.
- Lokale SQLite-opslag.
- Handmatige JSON back-up/export + herstel/import.
- Android cloudback-up en device-transfer voor database + instellingen.
- Unit tests voor prijs- en invoerregels.

## Dataveiligheid
Databaseversie 2 bevat een expliciete migratie vanaf versie 1. Onbekende toekomstige migratiepaden worden niet stilzwijgend uitgevoerd. Back-ups worden vóór import volledig gevalideerd en de databasevervanging gebeurt transactioneel.

## Prijsveiligheid
- Normale prijs: € 0,01 t/m € 99.999,99.
- Aanbieding moet positief én lager dan de normale prijs zijn.
- Prijshistorie gebruikt dezelfde aanbieding-validatie als de actuele prijsengine.
- Lijsttotalen gebruiken 64-bit berekeningen.

## Package en signing
Development: `nl.jays.boodschappenduitsland.dev`

Release: `nl.jays.boodschappenduitsland`

Development builds gebruiken alleen de meegeleverde debug-key. Definitieve releases moeten altijd met dezelfde privé release-keystore worden ondertekend. De release-key hoort nooit in Git te staan; gebruik GitHub Actions Secrets.

## Build stack
- Android Gradle Plugin 9.4.0
- Gradle 9.6.0
- compileSdk 37 / targetSdk 36 / minSdk 23
- Jetpack Compose BOM 2026.08.00
- Google Code Scanner 16.1.0
