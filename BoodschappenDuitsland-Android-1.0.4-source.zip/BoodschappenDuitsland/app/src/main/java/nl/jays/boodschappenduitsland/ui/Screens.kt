@file:OptIn(androidx.compose.material3.ExperimentalMaterial3Api::class)

package nl.jays.boodschappenduitsland.ui

import android.widget.Toast
import android.content.Intent
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.mlkit.vision.barcode.common.Barcode
import com.google.mlkit.vision.codescanner.GmsBarcodeScannerOptions
import com.google.mlkit.vision.codescanner.GmsBarcodeScanning
import nl.jays.boodschappenduitsland.BuildConfig
import nl.jays.boodschappenduitsland.domain.*
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import kotlin.math.max

private enum class Screen { HOME, LIST, PRICES, OFFERS, STORES, SETTINGS, SCAN_RESULT, STORE_BASKET }

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AppRoot(viewModel: AppViewModel) {
    val state by viewModel.state.collectAsState()
    var screen by remember { mutableStateOf(Screen.HOME) }
    val backStack = remember { mutableStateListOf<Screen>() }
    val navigate: (Screen) -> Unit = { destination ->
        if (screen != destination) { backStack.add(screen); screen = destination }
    }
    val goBack: () -> Unit = {
        if (backStack.isNotEmpty()) screen = backStack.removeAt(backStack.lastIndex)
    }
    var selectedStoreId by remember { mutableStateOf<Long?>(null) }
    BackHandler(enabled = screen != Screen.HOME) { goBack() }
    val context = LocalContext.current
    val launchScanner: () -> Unit = {
        runCatching {
            val options = GmsBarcodeScannerOptions.Builder()
                .setBarcodeFormats(
                    Barcode.FORMAT_EAN_13,
                    Barcode.FORMAT_EAN_8,
                    Barcode.FORMAT_UPC_A,
                    Barcode.FORMAT_UPC_E,
                    Barcode.FORMAT_CODE_128
                )
                .build()

            GmsBarcodeScanning
                .getClient(context.applicationContext, options)
                .startScan()
                .addOnSuccessListener { barcode ->
                    val raw = barcode.rawValue
                    if (!raw.isNullOrBlank()) {
                        viewModel.onBarcodeScanned(raw)
                        navigate(Screen.SCAN_RESULT)
                    }
                }
                .addOnFailureListener { error ->
                    Toast.makeText(
                        context,
                        error.message ?: "Scannen mislukt",
                        Toast.LENGTH_LONG
                    ).show()
                }
        }.onFailure { error ->
            Toast.makeText(
                context,
                error.message ?: "Scanner kan niet worden gestart",
                Toast.LENGTH_LONG
            ).show()
        }
        Unit
    }

    val exportBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.CreateDocument("application/json")
    ) { uri ->
        uri?.let(viewModel::exportBackup)
    }

    val importBackupLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let(viewModel::importBackup)
    }

    val importCatalogLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.OpenDocument()
    ) { uri ->
        uri?.let(viewModel::importSupermarketCatalog)
    }

    BoodschappenTheme(state.darkMode) {
        Scaffold(
            bottomBar = {
                if (screen != Screen.SCAN_RESULT) {
                    AppBottomBar(
                        current = screen,
                        onHome = { navigate(Screen.HOME) },
                        onList = { navigate(Screen.LIST) },
                        onScan = { launchScanner() },
                        onStores = { navigate(Screen.STORES) },
                        onSettings = { navigate(Screen.SETTINGS) }
                    )
                }
            }
        ) { padding ->
            Box(Modifier.padding(padding).fillMaxSize()) {
                when (screen) {
                    Screen.HOME -> HomeScreen(
                        state = state,
                        onFilter = viewModel::setCountryFilter,
                        onDarkMode = viewModel::setDarkMode,
                        onScan = { launchScanner() },
                        onList = { navigate(Screen.LIST) },
                        onPrices = { navigate(Screen.PRICES) },
                        onOffers = { navigate(Screen.OFFERS) },
                        onStores = { navigate(Screen.STORES) },
                        onProduct = { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) }
                    )
                    Screen.LIST -> ShoppingListScreen(state, viewModel) { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) }
                    Screen.PRICES -> PricesScreen(state, viewModel) { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) }
                    Screen.OFFERS -> OffersScreen(state, viewModel)
                    Screen.STORES -> StoresScreen(state, viewModel,
                        onStore = { selectedStoreId = it; navigate(Screen.STORE_BASKET) },
                        onOffers = { navigate(Screen.OFFERS) })
                    Screen.STORE_BASKET -> state.stores.firstOrNull { it.id == selectedStoreId }?.let { store ->
                        StoreBasketScreen(state, store, onBack = goBack,
                            onProduct = { viewModel.selectProduct(it); navigate(Screen.SCAN_RESULT) })
                    }
                    Screen.SETTINGS -> SettingsScreen(
                        state = state,
                        viewModel = viewModel,
                        onStores = { navigate(Screen.STORES) },
                        onCompare = { navigate(Screen.STORES) },
                        onExportBackup = {
                            exportBackupLauncher.launch("Boodschappen-Duitsland-backup.json")
                        },
                        onImportBackup = {
                            importBackupLauncher.launch(arrayOf("application/json", "text/plain"))
                        },
                        onImportCatalog = {
                            importCatalogLauncher.launch(arrayOf("application/json", "text/plain"))
                        }
                    )
                    Screen.SCAN_RESULT -> ScanResultScreen(
                        state = state,
                        viewModel = viewModel,
                        onBack = { goBack() },
                        onScanNext = { launchScanner() }
                    )
                }

                state.message?.let { message ->
                    Snackbar(
                        modifier = Modifier.align(Alignment.BottomCenter).padding(16.dp),
                        action = { TextButton(onClick = viewModel::consumeMessage) { Text("OK") } }
                    ) { Text(message) }
                }
            }
        }
    }
}

@Composable
private fun AppBottomBar(current: Screen, onHome: () -> Unit, onList: () -> Unit, onScan: () -> Unit, onStores: () -> Unit, onSettings: () -> Unit) {
    NavigationBar {
        NavigationBarItem(selected = current == Screen.HOME, onClick = onHome, icon = { Icon(Icons.Default.Home, null) }, label = { Text("Home") })
        NavigationBarItem(selected = current == Screen.LIST, onClick = onList, icon = { Icon(Icons.Default.List, null) }, label = { Text("Lijst") })
        NavigationBarItem(selected = false, onClick = onScan, icon = { Icon(Icons.Default.QrCodeScanner, null) }, label = { Text("Scan") })
        NavigationBarItem(selected = current == Screen.STORES, onClick = onStores, icon = { Icon(Icons.Default.Store, null) }, label = { Text("Winkels") })
        NavigationBarItem(selected = current == Screen.SETTINGS, onClick = onSettings, icon = { Icon(Icons.Default.Settings, null) }, label = { Text("Instellingen") })
    }
}

@Composable
private fun AppHeader(title: String, subtitle: String? = null, trailing: @Composable (() -> Unit)? = null) {
    Row(Modifier.fillMaxWidth().padding(horizontal = 18.dp, vertical = 12.dp), verticalAlignment = Alignment.CenterVertically) {
        Surface(shape = RoundedCornerShape(16.dp), color = MaterialTheme.colorScheme.primaryContainer) {
            Icon(Icons.Default.ShoppingCart, null, modifier = Modifier.padding(10.dp), tint = MaterialTheme.colorScheme.primary)
        }
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(title, fontWeight = FontWeight.Bold, fontSize = 25.sp)
            subtitle?.let { Text(it, color = MaterialTheme.colorScheme.onSurfaceVariant, fontSize = 13.sp) }
        }
        trailing?.invoke()
    }
}

@Composable
private fun HomeScreen(
    state: UiState,
    onFilter: (CountryFilter) -> Unit,
    onDarkMode: (Boolean) -> Unit,
    onScan: () -> Unit,
    onList: () -> Unit,
    onPrices: () -> Unit,
    onOffers: () -> Unit,
    onStores: () -> Unit,
    onProduct: (Long) -> Unit
) {
    var query by remember { mutableStateOf("") }
    var searchStores by remember { mutableStateOf(false) }
    val visibleProducts = remember(state.products, query) {
        if (query.isBlank()) state.products else state.products.filter {
            (it.name + " " + it.brand + " " + it.category).contains(query, ignoreCase = true)
        }
    }
    val listTotal = PriceEngine.listTotal(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)
    val expensive = PriceEngine.mostExpensiveComparableTotal(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)
    val savings = (expensive - listTotal).coerceAtLeast(0)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        contentPadding = PaddingValues(bottom = 20.dp)
    ) {
        item {
            AppHeader("Boodschappen Duitsland", "Stap voor stap je boodschappen plannen")
        }
        item {
            Card(
                Modifier.padding(horizontal = 16.dp).fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(Modifier.padding(16.dp)) {
                    Text("Slimmer boodschappen over de grens", fontWeight = FontWeight.Bold, fontSize = 20.sp)
                    Text("Vergelijk alleen prijzen die je zelf hebt gecontroleerd. Live filiaalprijzen zijn nog niet voor alle winkels beschikbaar.", color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(Modifier.height(8.dp))
                    AssistChip(onClick = {}, label = { Text("Lokale/demo prijsdata — live bronnen volgen per winkel") }, leadingIcon = { Icon(Icons.Default.Info, null) })
                }
            }
        }
        item { Spacer(Modifier.height(12.dp)); CountryFilterBar(state.countryFilter, onFilter) }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(selected = !searchStores, onClick = { searchStores = false; query = "" }, label = { Text("Producten") })
                FilterChip(selected = searchStores, onClick = { searchStores = true; query = "" }, label = { Text("Winkels") })
            }
        }
        item {
            OutlinedTextField(
                value = query,
                onValueChange = { query = it },
                modifier = Modifier.fillMaxWidth().padding(16.dp),
                singleLine = true,
                leadingIcon = { Icon(Icons.Default.Search, null) },
                trailingIcon = { if (!searchStores) IconButton(onClick = onScan) { Icon(Icons.Default.QrCodeScanner, "Scan") } },
                label = { Text(if (searchStores) "Zoek een winkel" else "Zoek een product") }
            )
        }
        if (searchStores) {
            items(state.stores.filter { it.name.contains(query, ignoreCase = true) && it.enabled }) { store ->
                ListItem(headlineContent = { Text(store.name) }, supportingContent = { Text(store.country.label) },
                    modifier = Modifier.clickable(onClick = onStores))
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Boodschappenlijst", "Plan en houd bij", Icons.Default.Checklist, Modifier.weight(1f), onList)
                HomeAction("Scanner", "Scan een product", Icons.Default.QrCodeScanner, Modifier.weight(1f), onScan)
            }
            Spacer(Modifier.height(10.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                HomeAction("Prijzen", "Vergelijk winkels", Icons.Default.Euro, Modifier.weight(1f), onPrices)
                HomeAction("Aanbiedingen", "Actuele acties", Icons.Default.Percent, Modifier.weight(1f), onOffers)
            }
        }
        item {
            Spacer(Modifier.height(14.dp))
            Row(Modifier.fillMaxWidth().padding(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                StatCard("Besparing lijst", savings.asEuro(), Icons.Default.Savings, Modifier.weight(1f))
                StatCard("Actieve winkels", state.stores.count { it.enabled }.toString(), Icons.Default.Storefront, Modifier.weight(1f))
            }
        }
        if (!searchStores) item { SectionTitle("Producten", "Prijzen uit de lokale gegevens") }
        if (!searchStores) item {
            LazyRow(contentPadding = PaddingValues(horizontal = 16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                items(visibleProducts.take(8), key = { it.id }) { product ->
                    val best = PriceEngine.bestPrice(product, state.prices, state.stores, state.countryFilter)
                    ProductQuickCard(product, best) { onProduct(product.id) }
                }
            }
        }
        item {
            Spacer(Modifier.height(16.dp))
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.DirectionsCar, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        Text("Volgende Duitsland-rit", fontWeight = FontWeight.Bold)
                        Text("Je lijst staat klaar. Gebruik de scanner in de winkel.", style = MaterialTheme.typography.bodySmall)
                    }
                    Button(onClick = onList) { Text("Lijst openen") }
                }
            }
        }
    }
}

@Composable
private fun CountryFilterBar(filter: CountryFilter, onFilter: (CountryFilter) -> Unit) {
    SingleChoiceSegmentedButtonRow(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        val options = listOf(CountryFilter.ALL to "🌍 Alles", CountryFilter.NL to "🇳🇱 Nederland", CountryFilter.DE to "🇩🇪 Duitsland")
        options.forEachIndexed { index, (value, label) ->
            SegmentedButton(
                selected = filter == value,
                onClick = { onFilter(value) },
                shape = SegmentedButtonDefaults.itemShape(index, options.size),
                label = { Text(label, maxLines = 1) }
            )
        }
    }
}

@Composable
private fun HomeAction(title: String, subtitle: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier, onClick: () -> Unit) {
    Card(modifier.clickable(onClick = onClick)) {
        Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.width(10.dp))
            Column {
                Text(title, fontWeight = FontWeight.SemiBold)
                Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }
}

@Composable
private fun StatCard(title: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, modifier: Modifier) {
    Card(modifier) {
        Column(Modifier.padding(14.dp)) {
            Icon(icon, null, tint = MaterialTheme.colorScheme.primary)
            Spacer(Modifier.height(8.dp))
            Text(title, style = MaterialTheme.typography.bodySmall)
            Text(value, fontWeight = FontWeight.Bold, fontSize = 22.sp)
        }
    }
}

@Composable
private fun SectionTitle(title: String, subtitle: String? = null) {
    Column(Modifier.padding(start = 16.dp, end = 16.dp, top = 20.dp, bottom = 8.dp)) {
        Text(title, fontWeight = FontWeight.Bold, fontSize = 20.sp)
        subtitle?.let { Text(it, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
    }
}

@Composable
private fun ProductQuickCard(product: Product, best: ProductPrice?, onClick: () -> Unit) {
    Card(Modifier.width(190.dp).clickable(onClick = onClick)) {
        Column(Modifier.padding(14.dp)) {
            Text(product.name, fontWeight = FontWeight.Bold, maxLines = 1, overflow = TextOverflow.Ellipsis)
            Text(product.brand, style = MaterialTheme.typography.bodySmall, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(product.displaySize, style = MaterialTheme.typography.labelSmall)
            Spacer(Modifier.height(10.dp))
            if (best != null) {
                Text("${best.store.country.flag} ${best.store.name}", fontWeight = FontWeight.SemiBold)
                Text(best.effectivePriceCents.asEuro(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 22.sp)
                if (best.isOffer) Text("AANBIEDING", color = MaterialTheme.colorScheme.primary, style = MaterialTheme.typography.labelSmall)
                best.unitPriceCents?.let { Text("${it.asEuro()} ${best.unitLabel}", style = MaterialTheme.typography.labelSmall) }
            } else Text("Geen prijs beschikbaar", color = MaterialTheme.colorScheme.error)
        }
    }
}

@Composable
private fun ShoppingListScreen(state: UiState, viewModel: AppViewModel, onProduct: (Long) -> Unit) {
    var showAdd by remember { mutableStateOf(false) }
    val plan = PriceEngine.bestSingleStorePlan(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)
    val productsById = state.products.associateBy { it.id }
    val total = PriceEngine.listTotal(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)
    val expensive = PriceEngine.mostExpensiveComparableTotal(state.shoppingList, state.products, state.prices, state.stores, state.countryFilter)

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { AppHeader("Boodschappenlijst", "Controleer inhoud en prijzen per winkel") }
        item { Text("Prijzen in deze versie zijn lokaal of voorbeeldgegevens; geen bevestigde actuele kassaprijzen.", Modifier.padding(horizontal = 16.dp), color = MaterialTheme.colorScheme.error) }
        item { CountryFilterBar(state.countryFilter, viewModel::setCountryFilter) }
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                FilterChip(
                    selected = state.strategy == ShoppingStrategy.MAX_SAVINGS,
                    onClick = { viewModel.setStrategy(ShoppingStrategy.MAX_SAVINGS) },
                    label = { Text("Maximale besparing") },
                    leadingIcon = { Icon(Icons.Default.Savings, null) }
                )
                FilterChip(
                    selected = state.strategy == ShoppingStrategy.ONE_STORE,
                    onClick = { viewModel.setStrategy(ShoppingStrategy.ONE_STORE) },
                    label = { Text("Alles bij één winkel") },
                    leadingIcon = { Icon(Icons.Default.Store, null) }
                )
            }
        }
        if (state.strategy == ShoppingStrategy.ONE_STORE && plan != null) {
            item {
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                    Column(Modifier.padding(14.dp)) {
                        Text("Beste keuze op basis van lokale gegevens", fontWeight = FontWeight.Bold)
                        Text("${plan.store.country.flag} ${plan.store.name} — ${plan.totalCents.asEuro()}")
                        if (plan.coveredItems < plan.totalItems) Text("Let op: ${plan.totalItems - plan.coveredItems} product(en) ontbreken bij deze winkel.", color = MaterialTheme.colorScheme.error)
                    }
                }
            }
        }
        items(state.shoppingList, key = { it.productId }) { item ->
            val product = productsById[item.productId] ?: return@items
            val best = if (state.strategy == ShoppingStrategy.ONE_STORE && plan != null) {
                state.prices.firstOrNull { it.productId == product.id && it.storeId == plan.store.id && PriceEngine.usable(it) }?.let { PriceEngine.priceForProduct(product, it, plan.store) }
            } else PriceEngine.bestPrice(product, state.prices, state.stores, state.countryFilter)
            ShoppingRow(item, product, best, viewModel, onProduct)
        }
        item {
            OutlinedButton(onClick = { showAdd = true }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Product toevoegen")
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp), colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)) {
                Row(Modifier.padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                    Column { Text("Bekend deeltotaal"); Text(total.asEuro(), fontWeight = FontWeight.Bold, fontSize = 24.sp) }
                    Column(horizontalAlignment = Alignment.End) { Text("Indicatief verschil"); Text((expensive - total).coerceAtLeast(0).asEuro(), fontWeight = FontWeight.Bold, fontSize = 24.sp) }
                }
            }
        }
        item {
            TextButton(onClick = viewModel::clearChecked, modifier = Modifier.fillMaxWidth().padding(8.dp)) { Text("Afgevinkte producten verwijderen") }
        }
    }

    if (showAdd) ProductPickerDialog(state, onDismiss = { showAdd = false }, onPick = { viewModel.addToList(it); showAdd = false })
}

@Composable
private fun ShoppingRow(item: ShoppingListItem, product: Product, best: ProductPrice?, viewModel: AppViewModel, onProduct: (Long) -> Unit) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Checkbox(checked = item.checked, onCheckedChange = { viewModel.setListChecked(product.id, it) })
            Column(Modifier.weight(1f).clickable { onProduct(product.id) }) {
                Text(product.name, fontWeight = FontWeight.Bold, textDecoration = if (item.checked) androidx.compose.ui.text.style.TextDecoration.LineThrough else null)
                Text("${product.brand} · ${product.displaySize}", style = MaterialTheme.typography.bodySmall)
                best?.let { Text("${it.store.country.flag} ${it.store.name} · ${it.effectivePriceCents.asEuro()}", color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold) }
                    ?: Text("Geen prijs bij gekozen strategie", color = MaterialTheme.colorScheme.error)
            }
            IconButton(onClick = { viewModel.setListQuantity(product.id, item.quantity - 1) }) { Icon(Icons.Default.RemoveCircleOutline, "Minder") }
            Text("${item.quantity}x", fontWeight = FontWeight.Bold)
            IconButton(onClick = { viewModel.setListQuantity(product.id, item.quantity + 1) }) { Icon(Icons.Default.AddCircleOutline, "Meer") }
        }
    }
}

@Composable
private fun ProductPickerDialog(state: UiState, onDismiss: () -> Unit, onPick: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    val inList = state.shoppingList.map { it.productId }.toSet()
    val options = state.products.filter { it.id !in inList && (query.isBlank() || (it.name + it.brand).contains(query, true)) }
    AlertDialog(
        onDismissRequest = onDismiss,
        confirmButton = {},
        dismissButton = { TextButton(onClick = onDismiss) { Text("Sluiten") } },
        title = { Text("Product toevoegen") },
        text = {
            Column {
                OutlinedTextField(query, { query = it }, label = { Text("Zoeken") }, singleLine = true)
                Spacer(Modifier.height(8.dp))
                LazyColumn(Modifier.heightIn(max = 380.dp)) {
                    items(options, key = { it.id }) { product ->
                        ListItem(
                            headlineContent = { Text(product.name) },
                            supportingContent = { Text("${product.brand} · ${product.displaySize}") },
                            trailingContent = { Icon(Icons.Default.Add, null) },
                            modifier = Modifier.clickable { onPick(product.id) }
                        )
                    }
                }
            }
        }
    )
}

@Composable
private fun PricesScreen(state: UiState, viewModel: AppViewModel, onOpenProduct: (Long) -> Unit) {
    var query by remember { mutableStateOf("") }
    var showNewProduct by remember { mutableStateOf(false) }
    var editingPrice by remember { mutableStateOf<PriceEditTarget?>(null) }
    val products = state.products.filter { query.isBlank() || (it.name + " " + it.brand).contains(query, true) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { AppHeader("Prijzen", "Normale prijs, aanbieding en prijs per eenheid") }
        item { CountryFilterBar(state.countryFilter, viewModel::setCountryFilter) }
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                OutlinedTextField(query, { query = it }, Modifier.weight(1f), label = { Text("Zoek product") }, singleLine = true, leadingIcon = { Icon(Icons.Default.Search, null) })
                Spacer(Modifier.width(8.dp))
                FilledIconButton(onClick = { showNewProduct = true }) { Icon(Icons.Default.Add, "Product toevoegen") }
            }
        }
        items(products, key = { it.id }) { product ->
            val ranked = PriceEngine.rankedPrices(product, state.prices, state.stores, state.countryFilter)
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 6.dp)) {
                Column(Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold)
                            Text("${product.brand} · ${product.displaySize}", style = MaterialTheme.typography.bodySmall)
                        }
                        TextButton(onClick = { onOpenProduct(product.id) }) { Text("Details") }
                    }
                    if (ranked.isEmpty()) Text("Nog geen prijzen ingevoerd", color = MaterialTheme.colorScheme.error)
                    ranked.take(4).forEachIndexed { index, price ->
                        HorizontalDivider()
                        Row(Modifier.fillMaxWidth().padding(vertical = 8.dp), verticalAlignment = Alignment.CenterVertically) {
                            Text(if (index == 0) "🏆" else "", Modifier.width(28.dp))
                            Text("${price.store.country.flag} ${price.store.name}", Modifier.weight(1f))
                            Column(horizontalAlignment = Alignment.End) {
                                Text(price.effectivePriceCents.asEuro(), fontWeight = FontWeight.Bold, color = if (index == 0) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.onSurface)
                                price.unitPriceCents?.let { Text("${it.asEuro()} ${price.unitLabel}", style = MaterialTheme.typography.labelSmall) }
                            }
                            IconButton(onClick = { editingPrice = PriceEditTarget(product, price.store, price.entry) }) { Icon(Icons.Default.Edit, "Bewerk") }
                        }
                    }
                    val storesWithNoPrice = state.stores.filter { it.enabled && ranked.none { p -> p.store.id == it.id } }
                    if (storesWithNoPrice.isNotEmpty()) {
                        TextButton(onClick = { editingPrice = PriceEditTarget(product, storesWithNoPrice.first(), null) }) { Text("Prijs toevoegen bij ${storesWithNoPrice.first().name}") }
                    }
                }
            }
        }
    }

    editingPrice?.let { PriceEditDialog(it, onDismiss = { editingPrice = null }) { regular, offer, days ->
        viewModel.upsertPrice(it.product.id, it.store.id, regular, offer, days)
        editingPrice = null
    } }
    if (showNewProduct) NewProductDialog(onDismiss = { showNewProduct = false }) { name, brand, ean, size, unit, category ->
        viewModel.addProduct(name, brand, ean, size, unit, category)
        showNewProduct = false
    }
}

private data class PriceEditTarget(val product: Product, val store: Store, val entry: PriceEntry?)

@Composable
private fun PriceEditDialog(target: PriceEditTarget, onDismiss: () -> Unit, onSave: (String, String, String) -> Unit) {
    var regular by remember(target) { mutableStateOf(target.entry?.regularPriceCents?.let { centsToInput(it) } ?: "") }
    var offer by remember(target) { mutableStateOf(target.entry?.offerPriceCents?.let { centsToInput(it) } ?: "") }
    var days by remember(target) { mutableStateOf(if (target.entry?.offerPriceCents != null) "7" else "") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("${target.product.name} · ${target.store.name}") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(regular, { regular = it }, label = { Text("Normale prijs (€)") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(offer, { offer = it }, label = { Text("Aanbiedingsprijs (€), optioneel") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                OutlinedTextField(days, { days = it }, label = { Text("Aanbieding geldig aantal dagen") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number), singleLine = true)
            }
        },
        confirmButton = { Button(onClick = { onSave(regular, offer, days) }, enabled = regular.isNotBlank()) { Text("Opslaan") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

@Composable
private fun NewProductDialog(onDismiss: () -> Unit, onSave: (String, String, String?, String, String, String) -> Unit) {
    var name by remember { mutableStateOf("") }
    var brand by remember { mutableStateOf("") }
    var ean by remember { mutableStateOf("") }
    var size by remember { mutableStateOf("1") }
    var unit by remember { mutableStateOf("st") }
    var category by remember { mutableStateOf("Overig") }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Nieuw product") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(7.dp)) {
                OutlinedTextField(name, { name = it }, label = { Text("Productnaam") }, singleLine = true)
                OutlinedTextField(brand, { brand = it }, label = { Text("Merk") }, singleLine = true)
                OutlinedTextField(ean, { ean = it }, label = { Text("EAN/barcode (optioneel)") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(size, { size = it }, Modifier.weight(1f), label = { Text("Inhoud") }, singleLine = true, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal))
                    OutlinedTextField(unit, { unit = it }, Modifier.weight(1f), label = { Text("Eenheid") }, singleLine = true)
                }
                OutlinedTextField(category, { category = it }, label = { Text("Categorie") }, singleLine = true)
            }
        },
        confirmButton = { Button(onClick = { onSave(name, brand, ean.ifBlank { null }, size, unit, category) }, enabled = name.isNotBlank()) { Text("Toevoegen") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

private data class OfferUiItem(
    val product: Product,
    val store: Store,
    val entry: PriceEntry,
    val effectiveCents: Int
)

@Composable
private fun OffersScreen(state: UiState, viewModel: AppViewModel) {
    val context = LocalContext.current
    val productsById = state.products.associateBy { it.id }
    val storesById = state.stores.associateBy { it.id }
    val offers = state.prices.mapNotNull { entry ->
        val (effective, isOffer) = PriceEngine.effectivePrice(entry)
        if (!isOffer || !PriceEngine.usable(entry)) return@mapNotNull null
        val product = productsById[entry.productId] ?: return@mapNotNull null
        val store = storesById[entry.storeId] ?: return@mapNotNull null
        if (!store.enabled) return@mapNotNull null
        OfferUiItem(product, store, entry, effective)
    }
    val grouped = offers
        .groupBy { it.store }
        .toList()
        .sortedWith(compareBy<Pair<Store, List<OfferUiItem>>>({ it.first.country.name }, { it.first.name.lowercase(Locale.getDefault()) }))

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { SectionTitle("Folders", "Officiële pagina's van geselecteerde winkels") }
        items(state.stores.filter { it.enabled }) { store ->
            officialFolder(store)?.let { link ->
                ListItem(headlineContent = { Text("${store.country.flag} ${store.name}") },
                    supportingContent = { Text("Open folder of aanbiedingen bij de winkel") },
                    leadingContent = { Icon(Icons.Default.MenuBook, null) },
                    modifier = Modifier.clickable {
                        runCatching { context.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(link))) }
                            .onFailure { Toast.makeText(context, "Folder openen mislukt", Toast.LENGTH_SHORT).show() }
                    })
            }
        }
        item {
            AppHeader("Aanbiedingen", "Per winkel, met actuele Bonus-refresh") {
                if (state.offersRefreshing) {
                    CircularProgressIndicator(Modifier.size(28.dp), strokeWidth = 3.dp)
                } else {
                    IconButton(onClick = viewModel::refreshOffers) {
                        Icon(Icons.Default.Refresh, "Aanbiedingen vernieuwen")
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 4.dp)) {
                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Text("Vernieuwen", fontWeight = FontWeight.Bold)
                    Text(
                        "Vernieuwen haalt Albert Heijn Bonus op. Voor andere winkels open je de officiële folder of importeer je gecontroleerde gegevens.",
                        style = MaterialTheme.typography.bodySmall
                    )
                    state.lastOffersRefreshMillis?.let {
                        Text("Laatst succesvol vernieuwd: ${formatDateTime(it)}", style = MaterialTheme.typography.labelSmall)
                    }
                }
            }
        }
        if (offers.isEmpty()) {
            item { Text("Geen actieve aanbiedingen.", Modifier.padding(16.dp)) }
        }
        grouped.forEach { (store, storeOffers) ->
            item(key = "store-${store.id}") {
                SectionTitle("${store.country.flag} ${store.name} · ${storeOffers.size} aanbiedingen")
            }
            items(
                items = storeOffers.sortedWith(compareBy<OfferUiItem>({ it.product.category }, { it.product.name })),
                key = { "offer-${it.entry.id}" }
            ) { item ->
                Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp, vertical = 5.dp)) {
                    Row(Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.LocalOffer, null, tint = MaterialTheme.colorScheme.primary)
                        Spacer(Modifier.width(10.dp))
                        Column(Modifier.weight(1f), verticalArrangement = Arrangement.spacedBy(2.dp)) {
                            Text(item.product.name, fontWeight = FontWeight.Bold)
                            val detail = buildString {
                                if (item.product.brand.isNotBlank()) append(item.product.brand)
                                if (item.product.sizeValue > 0 && item.product.sizeUnit.isNotBlank()) {
                                    if (isNotEmpty()) append(" · ")
                                    append(item.product.displaySize)
                                }
                            }
                            if (detail.isNotBlank()) Text(detail, style = MaterialTheme.typography.bodySmall)
                            item.entry.offerLabel?.takeIf { it.isNotBlank() }?.let {
                                Text(it, color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.SemiBold, style = MaterialTheme.typography.bodySmall)
                            }
                            Text("Normaal ${item.entry.regularPriceCents.asEuro()}", style = MaterialTheme.typography.bodySmall)
                            item.entry.offerUntilMillis?.let { Text("Geldig t/m ${formatDate(it)}", style = MaterialTheme.typography.labelSmall) }
                        }
                        Text(item.effectiveCents.asEuro(), color = MaterialTheme.colorScheme.primary, fontWeight = FontWeight.Bold, fontSize = 20.sp)
                        IconButton(onClick = { viewModel.addToList(item.product.id) }) {
                            Icon(Icons.Default.PlaylistAdd, "Aan boodschappenlijst toevoegen")
                        }
                    }
                }
            }
        }
    }
}

private fun officialFolder(store: Store): String? {
    val name = store.name.lowercase(Locale.ROOT)
    return when {
        name.contains("jumbo") -> "https://www.jumbo.com/aanbiedingen/nu"
        name.contains("albert heijn") -> "https://www.ah.nl/bonus"
        name.contains("dirk") -> "https://www.dirk.nl/folder"
        name.contains("plus") -> "https://www.plus.nl/aanbiedingen"
        name.contains("kruidvat") -> "https://www.kruidvat.nl/folders"
        name.contains("schroff") -> "https://edeka-schroff.de/"
        name.contains("kaufland") -> "https://filiale.kaufland.de/angebote/uebersicht.html"
        name.contains("rewe") -> "https://www.rewe.de/angebote/"
        name.contains("aldi") -> "https://www.aldi-sued.de/angebote"
        name == "dm" -> "https://www.dm.de/angebote/"
        name.contains("lidl") && store.country == Country.NL -> "https://www.lidl.nl/"
        name.contains("lidl") -> "https://www.lidl.de/"
        else -> null
    }
}

@Composable
private fun StoresScreen(state: UiState, viewModel: AppViewModel, onStore: (Long) -> Unit, onOffers: () -> Unit) {
    var addStore by remember { mutableStateOf(false) }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { AppHeader("Winkels", "Tik op een winkel voor je lijst en een deeltotaal") }
        item {
            FilledTonalButton(onClick = onOffers, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Icon(Icons.Default.LocalOffer, null); Spacer(Modifier.width(8.dp)); Text("Folders en aanbiedingen")
            }
        }
        item {
            FilledTonalButton(onClick = { addStore = true }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Icon(Icons.Default.AddBusiness, null); Spacer(Modifier.width(8.dp)); Text("Winkel toevoegen")
            }
        }
        item { SectionTitle("Nederland") }
        items(state.stores.filter { it.country == Country.NL }, key = { it.id }) { store -> StoreRow(store, viewModel, onStore) }
        item { SectionTitle("Duitsland") }
        items(state.stores.filter { it.country == Country.DE }, key = { it.id }) { store -> StoreRow(store, viewModel, onStore) }
    }
    if (addStore) AddStoreDialog(onDismiss = { addStore = false }) { name, country -> viewModel.addStore(name, country); addStore = false }
}

@Composable
private fun StoreRow(store: Store, viewModel: AppViewModel, onStore: (Long) -> Unit) {
    ListItem(
        headlineContent = { Text(store.name, fontWeight = FontWeight.SemiBold) },
        supportingContent = { Text("${store.country.flag} ${store.country.label} · Bekijk boodschappenlijst") },
        leadingContent = { Icon(Icons.Default.Storefront, null) },
        trailingContent = { Switch(checked = store.enabled, onCheckedChange = { viewModel.setStoreEnabled(store.id, it) }) },
        modifier = Modifier.clickable { onStore(store.id) }
    )
    HorizontalDivider()
}

@Composable
private fun StoreBasketScreen(state: UiState, store: Store, onBack: () -> Unit, onProduct: (Long) -> Unit) {
    val productsById = state.products.associateBy { it.id }
    val pricesByProduct = state.prices.filter { it.storeId == store.id && PriceEngine.usable(it) }.associateBy { it.productId }
    var subtotal = 0L
    var missing = 0
    state.shoppingList.forEach { item ->
        val entry = pricesByProduct[item.productId]
        if (entry == null || productsById[item.productId] == null) missing++
        else subtotal += PriceEngine.effectivePrice(entry).first.toLong() * item.quantity
    }
    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 24.dp)) {
        item {
            Row(verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Terug") }
                AppHeader("${store.country.flag} ${store.name}", "Boodschappenlijst voor deze winkel")
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Text(if (missing == 0 && state.shoppingList.isNotEmpty()) "Indicatief winkelbedrag" else "Bekend deeltotaal", fontWeight = FontWeight.Bold)
                    Text(subtotal.asEuro(), fontSize = 26.sp, fontWeight = FontWeight.Bold)
                    if (missing > 0) Text("$missing product(en) zonder prijs. Geen volledig winkelbedrag beschikbaar.", color = MaterialTheme.colorScheme.error)
                    Text("Voorbeeld- en handmatig ingevoerde prijzen zijn geen bevestigde actuele kassaprijzen.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        items(state.shoppingList, key = { it.productId }) { item ->
            val product = productsById[item.productId] ?: return@items
            val entry = pricesByProduct[item.productId]
            ListItem(headlineContent = { Text("${item.quantity}× ${product.name}") },
                supportingContent = { Text(product.displaySize) },
                trailingContent = { Text(entry?.let { (PriceEngine.effectivePrice(it).first.toLong() * item.quantity).asEuro() } ?: "Prijs onbekend") },
                modifier = Modifier.clickable { onProduct(product.id) })
            HorizontalDivider()
        }
    }
}

@Composable
private fun AddStoreDialog(onDismiss: () -> Unit, onSave: (String, Country) -> Unit) {
    var name by remember { mutableStateOf("") }
    var country by remember { mutableStateOf(Country.DE) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Winkel toevoegen") },
        text = {
            Column {
                OutlinedTextField(name, { name = it }, label = { Text("Winkelnaam") }, singleLine = true)
                Spacer(Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(selected = country == Country.NL, onClick = { country = Country.NL }, label = { Text("🇳🇱 Nederland") })
                    FilterChip(selected = country == Country.DE, onClick = { country = Country.DE }, label = { Text("🇩🇪 Duitsland") })
                }
            }
        },
        confirmButton = { Button(onClick = { onSave(name, country) }, enabled = name.isNotBlank()) { Text("Toevoegen") } },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

@Composable
private fun SettingsScreen(
    state: UiState,
    viewModel: AppViewModel,
    onStores: () -> Unit,
    onCompare: () -> Unit,
    onExportBackup: () -> Unit,
    onImportBackup: () -> Unit,
    onImportCatalog: () -> Unit
) {
    var confirmReset by remember { mutableStateOf(false) }
    var confirmImport by remember { mutableStateOf(false) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 16.dp)) {
        item { AppHeader("Instellingen", "Gedrag, thema en gegevens") }
        item {
            ListItem(headlineContent = { Text("Winkels beheren") },
                supportingContent = { Text("Winkels toevoegen en aan- of uitzetten") },
                leadingContent = { Icon(Icons.Default.Storefront, null) },
                modifier = Modifier.clickable(onClick = onStores))
            FilledTonalButton(onClick = onCompare, modifier = Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Icon(Icons.Default.ShoppingBasket, null); Spacer(Modifier.width(8.dp)); Text("Boodschappenlijst vergelijken")
            }
        }
        item {
            ListItem(
                headlineContent = { Text("Donkere modus") },
                supportingContent = { Text("Schakel direct tussen licht en donker") },
                leadingContent = { Icon(Icons.Default.DarkMode, null) },
                trailingContent = { Switch(state.darkMode, onCheckedChange = viewModel::setDarkMode) }
            )
            HorizontalDivider()
        }
        item {
            ListItem(
                headlineContent = { Text("Versie") },
                supportingContent = { Text("${BuildConfig.VERSION_NAME} · ${BuildConfig.VERSION_CODE}") },
                leadingContent = { Icon(Icons.Default.Android, null) }
            )
            HorizontalDivider()
        }
        item {
            Card(Modifier.fillMaxWidth().padding(16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Back-up & herstel", fontWeight = FontWeight.Bold)
                    Text(
                        "Bewaar producten, prijzen, prijshistorie, boodschappenlijst, winkels en thema in één JSON-back-up. " +
                            "Gebruik dit ook om gegevens van een testversie naar de definitieve release over te zetten."
                    )
                    Button(onClick = onExportBackup, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.SaveAlt, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Back-up maken")
                    }
                    OutlinedButton(onClick = { confirmImport = true }, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.Restore, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Back-up terugzetten")
                    }
                }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text("Supermarktbestanden", fontWeight = FontWeight.Bold)
                    Text("Importeer per supermarkt een apart JSON-bestand. Bestaande producten en gebruikersgegevens worden gematcht en behouden; prijzen en aanbiedingen van die winkel worden toegevoegd of bijgewerkt.")
                    Button(onClick = onImportCatalog, modifier = Modifier.fillMaxWidth()) {
                        Icon(Icons.Default.FileOpen, null)
                        Spacer(Modifier.width(8.dp))
                        Text("Supermarktbestand importeren")
                    }
                    Text("Live vernieuwen ondersteunt nu Albert Heijn Bonus. Andere winkels kunnen daarna als aparte bron worden toegevoegd.", style = MaterialTheme.typography.bodySmall)
                }
            }
        }
        item {
            OutlinedButton(onClick = { confirmReset = true }, modifier = Modifier.fillMaxWidth().padding(16.dp)) {
                Icon(Icons.Default.RestartAlt, null)
                Spacer(Modifier.width(8.dp))
                Text("Lokale gegevens wissen")
            }
        }
    }

    if (confirmImport) {
        AlertDialog(
            onDismissRequest = { confirmImport = false },
            title = { Text("Back-up terugzetten?") },
            text = { Text("De huidige lokale gegevens worden vervangen door de gegevens uit het gekozen back-upbestand. Maak zo nodig eerst een nieuwe back-up.") },
            confirmButton = {
                Button(onClick = {
                    confirmImport = false
                    onImportBackup()
                }) { Text("Bestand kiezen") }
            },
            dismissButton = { TextButton(onClick = { confirmImport = false }) { Text("Annuleren") } }
        )
    }

    if (confirmReset) {
        AlertDialog(
            onDismissRequest = { confirmReset = false },
            title = { Text("Gegevens wissen?") },
            text = { Text("Producten, prijzen en lijst worden verwijderd. De twaalf winkels blijven beschikbaar. Maak eerst een back-up als je dit wilt bewaren.") },
            confirmButton = {
                Button(onClick = {
                    confirmReset = false
                    viewModel.resetDemoData()
                }) { Text("Herstellen") }
            },
            dismissButton = { TextButton(onClick = { confirmReset = false }) { Text("Annuleren") } }
        )
    }
}

@Composable
private fun ScanResultScreen(state: UiState, viewModel: AppViewModel, onBack: () -> Unit, onScanNext: () -> Unit) {
    val product = state.products.firstOrNull { it.id == state.selectedProductId }
    if (product == null) {
        Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) { if (state.loading) CircularProgressIndicator() else Text("Geen product geselecteerd") }
        return
    }
    val ranked = PriceEngine.rankedPrices(product, state.prices, state.stores, state.countryFilter)
    val best = ranked.firstOrNull()
    val second = ranked.getOrNull(1)
    val diffPct = if (best != null && second != null && second.effectivePriceCents > 0) ((second.effectivePriceCents - best.effectivePriceCents) * 100 / second.effectivePriceCents) else 0
    var editProduct by remember(product.id) { mutableStateOf(product.name == "Onbekend product") }
    var editingPrice by remember { mutableStateOf<PriceEditTarget?>(null) }

    LazyColumn(Modifier.fillMaxSize(), contentPadding = PaddingValues(bottom = 20.dp)) {
        item {
            Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                IconButton(onClick = onBack) { Icon(Icons.Default.ArrowBack, "Terug") }
                Text("Scanresultaat", fontSize = 24.sp, fontWeight = FontWeight.Bold, modifier = Modifier.weight(1f))
                IconButton(onClick = onScanNext) { Icon(Icons.Default.QrCodeScanner, "Scan volgende") }
            }
        }
        item {
            Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
                Column(Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Column(Modifier.weight(1f)) {
                            Text(product.name, fontWeight = FontWeight.Bold, fontSize = 21.sp)
                            Text(product.brand)
                            Text("${product.displaySize}${product.ean?.let { " · EAN $it" } ?: ""}", style = MaterialTheme.typography.bodySmall)
                        }
                        IconButton(onClick = { editProduct = true }) { Icon(Icons.Default.Edit, "Product bewerken") }
                    }
                }
            }
        }
        item {
            Spacer(Modifier.height(12.dp))
            Card(
                Modifier.fillMaxWidth().padding(horizontal = 16.dp),
                colors = CardDefaults.cardColors(containerColor = if (best != null) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.errorContainer)
            ) {
                Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(if (best != null) Icons.Default.EmojiEvents else Icons.Default.Warning, null, tint = MaterialTheme.colorScheme.primary)
                    Spacer(Modifier.width(12.dp))
                    Column(Modifier.weight(1f)) {
                        if (best != null) {
                            Text("Beste keuze: ${best.store.name}", fontWeight = FontWeight.Bold)
                            Text(best.effectivePriceCents.asEuro(), fontWeight = FontWeight.Bold, fontSize = 28.sp)
                            if (second != null) Text("$diffPct% goedkoper dan het volgende alternatief", style = MaterialTheme.typography.bodySmall)
                        } else {
                            Text("Nog geen prijsgegevens", fontWeight = FontWeight.Bold)
                            Text("Voeg hieronder een prijs toe.")
                        }
                    }
                    SuggestionChip(onClick = {}, label = { Text(if (best != null) "KOPEN" else "AANVULLEN") })
                }
            }
        }
        item { SectionTitle("Prijzen", "Goedkoopste bovenaan, landen door elkaar") }
        items(ranked, key = { it.store.id }) { price ->
            ListItem(
                headlineContent = { Text("${price.store.country.flag} ${price.store.name}", fontWeight = FontWeight.SemiBold) },
                supportingContent = {
                    Column {
                        Text(if (price.isOffer) "Aanbieding · normaal ${price.entry.regularPriceCents.asEuro()}" else "Normale prijs")
                        price.unitPriceCents?.let { Text("${it.asEuro()} ${price.unitLabel}") }
                    }
                },
                trailingContent = {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(price.effectivePriceCents.asEuro(), fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.primary)
                        IconButton(onClick = { editingPrice = PriceEditTarget(product, price.store, price.entry) }) { Icon(Icons.Default.Edit, "Bewerk") }
                    }
                }
            )
            HorizontalDivider()
        }
        item {
            val missingStores = state.stores.filter { it.enabled && ranked.none { p -> p.store.id == it.id } }
            if (missingStores.isNotEmpty()) {
                TextButton(onClick = { editingPrice = PriceEditTarget(product, missingStores.first(), null) }, modifier = Modifier.fillMaxWidth()) {
                    Icon(Icons.Default.Add, null); Spacer(Modifier.width(6.dp)); Text("Prijs toevoegen bij ${missingStores.first().name}")
                }
            }
        }
        item { SectionTitle("Prijsverloop", "Historie per winkel — winkels worden niet door elkaar verbonden") }
        val historyByStore = state.history
            .filter { it.productId == product.id }
            .groupBy { it.storeId }
            .toList()
            .sortedBy { (storeId, _) -> state.stores.firstOrNull { it.id == storeId }?.name ?: "" }
        if (historyByStore.isEmpty()) {
            item { Text("Nog geen prijshistorie beschikbaar.", Modifier.padding(horizontal = 16.dp, vertical = 8.dp)) }
        } else {
            items(historyByStore, key = { it.first }) { (storeId, points) ->
                val store = state.stores.firstOrNull { it.id == storeId }
                Text(
                    text = store?.let { "${it.country.flag} ${it.name}" } ?: "Winkel $storeId",
                    modifier = Modifier.padding(start = 18.dp, end = 18.dp, top = 10.dp, bottom = 4.dp),
                    fontWeight = FontWeight.SemiBold
                )
                PriceHistoryChart(points)
            }
        }
        item {
            Row(Modifier.fillMaxWidth().padding(16.dp), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedButton(onClick = { viewModel.addToList(product.id) }, modifier = Modifier.weight(1f)) { Icon(Icons.Default.PlaylistAdd, null); Spacer(Modifier.width(6.dp)); Text("Aan lijst") }
                Button(onClick = onScanNext, modifier = Modifier.weight(1f)) { Icon(Icons.Default.QrCodeScanner, null); Spacer(Modifier.width(6.dp)); Text("Scan volgende") }
            }
        }
    }

    if (editProduct) EditProductDialog(product, onDismiss = { editProduct = false }) { updated -> viewModel.updateProduct(updated); editProduct = false }
    editingPrice?.let { target -> PriceEditDialog(target, onDismiss = { editingPrice = null }) { regular, offer, days ->
        viewModel.upsertPrice(target.product.id, target.store.id, regular, offer, days); editingPrice = null
    } }
}

@Composable
private fun EditProductDialog(product: Product, onDismiss: () -> Unit, onSave: (Product) -> Unit) {
    var name by remember(product) { mutableStateOf(product.name) }
    var brand by remember(product) { mutableStateOf(product.brand) }
    var size by remember(product) { mutableStateOf(product.sizeValue.toString()) }
    var unit by remember(product) { mutableStateOf(product.sizeUnit) }
    var category by remember(product) { mutableStateOf(product.category) }
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Productgegevens") },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                product.ean?.let { Text("EAN: $it", style = MaterialTheme.typography.bodySmall) }
                OutlinedTextField(name, { name = it }, label = { Text("Naam") }, singleLine = true)
                OutlinedTextField(brand, { brand = it }, label = { Text("Merk") }, singleLine = true)
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(size, { size = it }, Modifier.weight(1f), label = { Text("Inhoud") }, keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Decimal), singleLine = true)
                    OutlinedTextField(unit, { unit = it }, Modifier.weight(1f), label = { Text("Eenheid") }, singleLine = true)
                }
                OutlinedTextField(category, { category = it }, label = { Text("Categorie") }, singleLine = true)
            }
        },
        confirmButton = {
            Button(onClick = {
                onSave(product.copy(name = name.trim(), brand = brand.trim(), sizeValue = size.replace(',', '.').toDoubleOrNull() ?: product.sizeValue, sizeUnit = unit.trim(), category = category.trim()))
            }, enabled = name.isNotBlank()) { Text("Opslaan") }
        },
        dismissButton = { TextButton(onClick = onDismiss) { Text("Annuleren") } }
    )
}

@Composable
private fun PriceHistoryChart(points: List<PriceHistoryPoint>) {
    Card(Modifier.fillMaxWidth().padding(horizontal = 16.dp)) {
        if (points.size < 2) {
            Text("Nog te weinig historie. Elke prijswijziging wordt vanaf nu opgeslagen.", Modifier.padding(16.dp))
            return@Card
        }
        val sorted = points.sortedBy { it.capturedAtMillis }.takeLast(24)
        val minPrice = sorted.minOf { it.priceCents }
        val maxPrice = max(sorted.maxOf { it.priceCents }, minPrice + 1)
        val primary = MaterialTheme.colorScheme.primary
        Column(Modifier.padding(14.dp)) {
            Text("${minPrice.asEuro()} – ${maxPrice.asEuro()}", style = MaterialTheme.typography.bodySmall)
            Canvas(Modifier.fillMaxWidth().height(140.dp).padding(vertical = 8.dp)) {
                val w = size.width
                val h = size.height
                val step = if (sorted.size <= 1) w else w / (sorted.size - 1)
                var previous: Offset? = null
                sorted.forEachIndexed { index, point ->
                    val normalized = (point.priceCents - minPrice).toFloat() / (maxPrice - minPrice).toFloat()
                    val current = Offset(index * step, h - normalized * h)
                    previous?.let { drawLine(primary, it, current, strokeWidth = 5f, cap = StrokeCap.Round) }
                    drawCircle(primary, radius = 6f, center = current)
                    previous = current
                }
            }
        }
    }
}

private fun centsToInput(cents: Int) = "${cents / 100},${(cents % 100).toString().padStart(2, '0')}"
private fun formatDate(millis: Long) = SimpleDateFormat("dd-MM-yyyy", Locale("nl", "NL")).format(Date(millis))
private fun formatDateTime(millis: Long) = SimpleDateFormat("dd-MM-yyyy HH:mm", Locale("nl", "NL")).format(Date(millis))
